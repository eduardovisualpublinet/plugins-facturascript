# informes
Añade informes adicionales de resultados, tesorería y desgloses de compras y ventas a FacturaScripts.
- https://facturascripts.com/plugins/informes

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **Informes**.

## Links
- [Curso de FacturaScripts](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
- [Programa de contabilidad gratis para autónomos](https://facturascripts.com/software-contabilidad)
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Programa para hacer presupuestos gratis](https://facturascripts.com/programa-de-presupuestos)
- [Cómo hacer un balance de sumas y saldos](https://facturascripts.com/publicaciones/como-hacer-un-balance-de-sumas-y-saldos)
- [Cómo hacer un balance de situación](https://facturascripts.com/publicaciones/como-hacer-un-balance-de-situacion)
- [Cómo hacer un balance de pérdidas y ganancias](https://facturascripts.com/publicaciones/como-hacer-un-balance-de-perdidas-y-ganancias)
- [Cómo hacer un balance de ingresos y gastos](https://facturascripts.com/publicaciones/como-hacer-un-balance-de-ingresos-y-gastos)