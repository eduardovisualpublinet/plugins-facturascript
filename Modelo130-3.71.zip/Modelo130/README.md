# Modelo130
Modelo 130 de la AEAT para la realización de los pagos a cuenta fracciones del IRPF por parte de los autónomos.
- https://facturascripts.com/plugins/modelo130

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **Modelo130**.

## Links
- [Crear informe de autoliquidación trimestral](https://facturascripts.com/publicaciones/crear-informe-de-autoliquidacion-trimestral-modelo-130)
- [Configurar correctamente las cuentas deducibles del plugin](https://facturascripts.com/publicaciones/configurar-correctamente-las-cuentas-deducibles-del-plugin)
- [Cómo rellenar el Modelo 130 con ejemplos](https://tuspapelesautonomos.es/modelo-130-como-se-calcula-descubrelo-facil-con-ejemplos/)
- [Gastos que te puedes deducir siendo autónomo](https://tuspapelesautonomos.es/18-gastos-que-te-puedes-deducir-siendo-autonomo/)