# Anticipos
Plugin que permite crear cobros a cuenta de Proyectos, Proveedores, Clientes y sus documentos de Compra y Venta.
- https://facturascripts.com/plugins/anticipos

## Issues / Feedback
- https://facturascripts.com/contacto

## Links
- [Curso de FacturaScripts 2021](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
- [Programa de contabilidad gratis para autónomos](https://facturascripts.com/software-contabilidad)
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Programa para hacer presupuestos gratis](https://facturascripts.com/programa-de-presupuestos)