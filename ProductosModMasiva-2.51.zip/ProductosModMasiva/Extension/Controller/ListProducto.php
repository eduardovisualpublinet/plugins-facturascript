<?php

namespace FacturaScripts\Plugins\ProductosModMasiva\Extension\Controller;

use Closure;
use FacturaScripts\Core\Model\Producto;
use FacturaScripts\Dinamic\Lib\AssetManager;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;

/**
 * Summary of ListProducto
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2025
 */
class ListProducto
{
   public function createViews(): Closure
   {
      return function () {
         AssetManager::add('js', FS_ROUTE . '/Plugins/ProductosModMasiva/Assets/JS/ProductosModMasivaMain.js');
      };
   }

   public function validarCampoPresente()
   {
      return function ($campo) {
         if (!isset($campo) || empty($campo) || null === $campo) {
            return false;
         }
         return true;
      };
   }

   public function execPreviousAction(): Closure
   {
      return function ($action) {

         if ($action !== 'ProductosModMasiva') {
            return;
         }

         $data = $this->request()->all();

         if (!array_key_exists('confirm', $data)) {
            Tools::log()->error('you-must-confirm-the-operation');
            return;
         }

         $valor = !empty($data['marcar']) ? 1 : 0;

         $validCampos = ['ventasinstock', 'nostock', 'bloqueado', 'publico', 'secompra', 'sevende'];
         if (!in_array($data['ModMasivaProdTipo'], $validCampos)) {
            Tools::log()->error('you-must-select-the-type-and-method');
            return;
         }
         $campo = $data['ModMasivaProdTipo'];

         // Mapeo de filtros para "DataBaseWhere"
         $filterMappings = [
            'ProductosModMasivaquery' => ['referencia|descripcion|observaciones', 'XLIKE'],
            'ProductosModMasivafiltercodfabricante' => ['codfabricante', '='],
            'ProductosModMasivafiltercodfamilia' => ['codfamilia', '='],
            'ProductosModMasivafilterexcepcioniva' => ['excepcioniva', '='],
            'ProductosModMasivafiltertipo' => ['tipo', '='],
            'ProductosModMasivafiltercodimpuesto' => ['codimpuesto', '='],
            'ProductosModMasivafiltermin-price' => ['precio', '<='],
            'ProductosModMasivafiltermax-price' => ['precio', '>='],
            'ProductosModMasivafiltermin-stock' => ['stockfis', '<='],
            'ProductosModMasivafiltermax-stock' => ['stockfis', '>='],
            'ProductosModMasivafilternostock' => ['nostock', '='],
            'ProductosModMasivafilterventasinstock' => ['ventasinstock', '='],
            'ProductosModMasivafiltersecompra' => ['secompra', '='],
            'ProductosModMasivafiltersevende' => ['sevende', '='],
            'ProductosModMasivafilterpublico' => ['publico', '='],
         ];
         // Crear los objetos DataBaseWhere usando el mapeo
         $where = array_filter(array_map(function ($key, $params) use ($data) {
            if ($this->validarCampoPresente($data[$key] ?? null)) {
               return new DataBaseWhere($params[0], $data[$key], $params[1]);
            }
            return null;
         }, array_keys($filterMappings), $filterMappings));

         // Aplicar filtros especiales de status
         if (!empty($data['ProductosModMasivafilterstatus'])) {
            $statusFilter = $data['ProductosModMasivafilterstatus'];
            switch ($statusFilter) {
               case '0': // Solo activos
                  $where[] = new DataBaseWhere('bloqueado', 0);
                  break;
               case '1': // Bloqueados
                  $where[] = new DataBaseWhere('bloqueado', 1);
                  break;
               case '2': // Públicos
                  $where[] = new DataBaseWhere('publico', 1);
                  break;
               case '3': // Todos, no se filtra nada
                  break;
            }
         }

         $productos = (new Producto())->all(array_filter($where), [], 0, 0);

         $cantUpdated = 0;
         $cantNoUpdated = 0;

         foreach ($productos as $prd) {
            $producto = new Producto();
            $producto->load($prd->idproducto);

            if ($campo == 'nostock' && $valor) {
               $producto->ventasinstock = 1;
            }

            if ($campo === 'ventasinstock' && $producto->nostock) {
               // No se permite cambiar ventasinstock = false si el producto tiene nostock activado (comportamiento del core)
               $cantNoUpdated++;
               continue;
            }

            $producto->{$campo} = $valor;
            $producto->save();
            $cantUpdated++;
         }

         if ($cantNoUpdated > 0) {
            Tools::log()->warning('updated-unsuccessfully-prod', ['%cantNoUpdated%' => $cantNoUpdated]);
         }

         if ($cantUpdated > 0) {
            Tools::log()->info('updated-successfully', ['%cantUpdated%' => $cantUpdated]);
         }
      };
   }

   public function loadData(): Closure
   {
      return function ($viewName, $view) {

         if ($viewName === 'ListProducto') {
            $this->addButton($viewName, [
               'action' => 'ProductosModMasiva',
               'color' => 'default',
               'icon' => 'fa-solid fa-edit',
               'label' => 'change',
               'type' => 'modal'
            ]);
            $this->views[$viewName]->model->AplicarA = $view->count;
         }
      };
   }
}
