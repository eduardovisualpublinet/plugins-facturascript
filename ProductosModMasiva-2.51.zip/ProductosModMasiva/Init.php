<?php
namespace FacturaScripts\Plugins\ProductosModMasiva;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;

/**
 * Summary of Init
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2025
 */
class Init extends InitClass
{
    public function init(): void
    {
        // se ejecuta cada vez que carga FacturaScripts (si este plugin está activado).
        $this->loadExtension(new Extension\Controller\ListProducto());
    }

    public function update(): void
    {
        // se ejecuta cada vez que se instala o actualiza el plugin.
    }


    public function uninstall(): void
    {
        // código de desinstalación aquí
    }
}