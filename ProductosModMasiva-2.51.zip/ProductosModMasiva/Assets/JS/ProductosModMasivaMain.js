$(document).ready(function () {
  $("#modalProductosModMasiva").on("shown.bs.modal", function () {
    $("#ModMasivaProdTipo").focus();

    // Mapeo de filtros de "select" y "input" con sus equivalentes de "ProductosModMasiva"
    const selectMappings = [
      {
        from: "filterstatus",
        to: "ProductosModMasivafilterstatus",
        type: "select",
      },
      {
        from: "filtercodfabricante",
        to: "ProductosModMasivafiltercodfabricante",
        type: "select",
      },
      {
        from: "filtercodfamilia",
        to: "ProductosModMasivafiltercodfamilia",
        type: "select",
      },
      {
        from: "filterexcepcioniva",
        to: "ProductosModMasivafilterexcepcioniva",
        type: "select",
      },
      {
        from: "filtercodimpuesto",
        to: "ProductosModMasivafiltercodimpuesto",
        type: "select",
      },
      {
        from: "filtertipo",
        to: "ProductosModMasivafiltertipo",
        type: "select",
      },
      {
        from: "filtermin-price",
        to: "ProductosModMasivafiltermin-price",
        type: "input",
      },
      {
        from: "filtermax-price",
        to: "ProductosModMasivafiltermax-price",
        type: "input",
      },
      {
        from: "filtermin-stock",
        to: "ProductosModMasivafiltermin-stock",
        type: "input",
      },
      {
        from: "filtermax-stock",
        to: "ProductosModMasivafiltermax-stock",
        type: "input",
      },
      { from: "query", to: "ProductosModMasivaquery", type: "input" },
    ];

    // Rellenar los campos de ProductosModMasiva a partir de los select e inputs
    selectMappings.forEach(({ from, to, type }) => {
      const value =
        type === "select"
          ? $(`select[name="${from}"] option:selected`).val()
          : $(`input[name="${from}"]`).val();
      $(`input[name="${to}"]`).val(value);
    });

    // Mapeo de campos que se llenan con un "1" si están checkeados
    const checkboxMappings = [
      "filternostock",
      "filterventasinstock",
      "filtersecompra",
      "filtersevende",
      "filterpublico",
    ];

    // Rellenar los campos de ProductosModMasiva para los checkboxes
    checkboxMappings.forEach((name) => {
      if ($(`input[name="${name}"]`).prop("checked")) {
        $(`input[name="ProductosModMasiva${name}"]`).val(1);
      }
    });
  });
});
