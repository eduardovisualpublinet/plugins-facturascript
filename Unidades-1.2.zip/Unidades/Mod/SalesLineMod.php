<?php
/**
 * Copyright (C) 2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Unidades\Mod;

use FacturaScripts\Core\Contract\SalesLineModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Tools;


/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SalesLineMod implements SalesLineModInterface
{
    public function apply(SalesDocument &$model, array &$lines, array $formData): void
    {
    }

    public function applyToLine(array $formData, SalesDocumentLine &$line, string $id): void
    {
        $line->unidades = $formData['unidades_' . $id] ?? null;
    }

    public function assets(): void
    {
    }

    public function getFastLine(SalesDocument $model, array $formData): ?SalesDocumentLine
    {
        return null;
    }

    public function map(array $lines, SalesDocument $model): array
    {
        return [];
    }

    public function newFields(): array
    {
        return ['unidades'];
    }

    public function newModalFields(): array
    {
        return [];
    }

    public function newTitles(): array
    {
        return ['unidades'];
    }

    public function renderField(string $idlinea, SalesDocumentLine $line, SalesDocument $model, string $field): ?string
    {
        if ($field === 'unidades') {
            return $this->unidadesColumn($idlinea, $line, $model);
        }

        return null;
    }

    public function renderTitle(SalesDocument $model, string $field): ?string
    {
        if ($field === 'unidades') {
            return $this->unidadesTitle();
        }

        return null;
    }

    protected function unidadesColumn(string $idlinea, SalesDocumentLine $line, SalesDocument $model): string
    {
        $variant = $line->getVariante();
        $value = $line->exists() ? $line->unidades : $variant->unidades;
        $attributes = $model->editable ?
            'name="unidades_' . $idlinea . '" maxlength="100"' :
            'disabled=""';
        return '<div class="col-sm col-lg-1 order-3">'
            . '<div class="d-lg-none mt-3 small">' . Tools::trans('units') . '</div>'
            . '<input type="text" ' . $attributes . ' value="' . $value . '" class="form-control form-control-sm border-0"/>'
            . '</div>';
    }

    protected function unidadesTitle(): string
    {
        return '<div class="col-lg-1 order-3">' . Tools::trans('units') . '</div>';
    }
}
