<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Unidades;

use FacturaScripts\Core\Lib\AjaxForms\PurchasesLineHTML;
use FacturaScripts\Core\Lib\AjaxForms\SalesLineHTML;
use FacturaScripts\Core\Template\InitClass;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        SalesLineHTML::addMod(new Mod\SalesLineMod());
        PurchasesLineHTML::addMod(new Mod\PurchasesLineMod());
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
    }
}
