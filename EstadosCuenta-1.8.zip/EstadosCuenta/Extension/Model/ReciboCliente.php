<?php

namespace FacturaScripts\Plugins\EstadosCuenta\Extension\Model;

class ReciboCliente 
{
    public $diferencia;
    public $certificada;
}