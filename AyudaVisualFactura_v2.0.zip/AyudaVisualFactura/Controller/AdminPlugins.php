<?php
/**
 * This file is part of AyudaVisualFactura plugin for FacturaScripts
 * Copyright (C) 2024 VisualPublinet
 */

namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Tools;

/**
 * Controlador AdminPlugins restringido.
 * Solo el usuario autorizado puede gestionar plugins.
 * El menú se oculta via CSS en Extension/View/MenuTemplate_BodyEnd.html.twig
 */
class AdminPlugins extends \FacturaScripts\Core\Controller\AdminPlugins
{
    private const ADMIN_EMAIL = 'produccion@visualpublinet.com';

    public function privateCore(&$response, $user, $permissions)
    {
        // Si no es el usuario autorizado, bloquear acciones de modificación
        if ($user->email !== self::ADMIN_EMAIL) {
            $action = $this->request->inputOrQuery('action', '');
            if (in_array($action, ['disable', 'enable', 'remove', 'upload', 'rebuild'])) {
                Tools::log()->warning('not-allowed-modify');
                return;
            }
        }

        parent::privateCore($response, $user, $permissions);
    }
}
