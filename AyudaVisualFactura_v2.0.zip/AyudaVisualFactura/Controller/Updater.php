<?php
/**
 * This file is part of AyudaVisualFactura plugin for FacturaScripts
 * Copyright (C) 2024 VisualPublinet
 */

namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Tools;

/**
 * Controlador Updater restringido.
 * Solo el usuario autorizado puede actualizar.
 * El menú se oculta via CSS en Extension/View/MenuTemplate_BodyEnd.html.twig
 */
class Updater extends \FacturaScripts\Core\Controller\Updater
{
    private const ADMIN_EMAIL = 'produccion@visualpublinet.com';

    public function privateCore(&$response, $user, $permissions)
    {
        // Si no es el usuario autorizado, bloquear todas las acciones
        if ($user->email !== self::ADMIN_EMAIL) {
            $action = $this->request->inputOrQuery('action', '');
            if (!empty($action)) {
                Tools::log()->warning('not-allowed-modify');
                return;
            }
        }

        parent::privateCore($response, $user, $permissions);
    }
}
