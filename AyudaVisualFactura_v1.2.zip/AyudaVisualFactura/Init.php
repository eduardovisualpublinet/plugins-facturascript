<?php
/**
 * This file is part of AyudaVisualFactura plugin for FacturaScripts
 * Copyright (C) 2024 VisualPublinet
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Plugins\AyudaVisualFactura;

use FacturaScripts\Core\Html;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Template\InitClass;
use Twig\TwigFunction;

final class Init extends InitClass
{
    private static ?array $config = null;

    /**
     * Obtiene la configuración del plugin
     */
    public static function getConfig(): array
    {
        if (self::$config === null) {
            $configFile = __DIR__ . '/config.php';
            self::$config = file_exists($configFile) ? require $configFile : [];
        }
        return self::$config;
    }

    /**
     * Obtiene el email del administrador autorizado
     */
    public static function getAdminEmail(): string
    {
        return self::getConfig()['admin_email'] ?? '';
    }

    /**
     * Verifica si el usuario actual es el administrador autorizado
     */
    public static function isAuthorizedAdmin(): bool
    {
        $adminEmail = self::getAdminEmail();
        if (empty($adminEmail)) {
            return false;
        }

        $user = Session::user();
        if (empty($user->email)) {
            return false;
        }

        return $user->email === $adminEmail;
    }

    /**
     * Devuelve true si los plugins deben estar deshabilitados para el usuario actual
     */
    public static function shouldDisablePlugins(): bool
    {
        return !self::isAuthorizedAdmin();
    }

    /** @var array Páginas a ocultar para usuarios no autorizados */
    private const RESTRICTED_PAGES = ['AdminPlugins', 'Updater'];

    public function init(): void
    {
        // Registrar función Twig para verificar si deshabilitar plugins
        Html::addFunction(new TwigFunction('vp_disable_plugins', function () {
            return self::shouldDisablePlugins();
        }));

        Html::addFunction(new TwigFunction('vp_is_admin', function () {
            return self::isAuthorizedAdmin();
        }));

        // Registrar función Twig para filtrar menú
        Html::addFunction(new TwigFunction('vp_filter_menu', function (array $menu) {
            return self::filterMenu($menu);
        }));
    }

    /**
     * Filtra el menú eliminando las páginas restringidas para usuarios no autorizados
     */
    public static function filterMenu(array $menu): array
    {
        if (self::isAuthorizedAdmin()) {
            return $menu;
        }

        foreach ($menu as $menuKey => $menuItem) {
            // Buscar en el menú principal
            if (in_array($menuItem->name, self::RESTRICTED_PAGES)) {
                unset($menu[$menuKey]);
                continue;
            }

            // Buscar en submenús
            if (!empty($menuItem->menu)) {
                foreach ($menuItem->menu as $subKey => $subItem) {
                    if (in_array($subItem->name, self::RESTRICTED_PAGES)) {
                        unset($menu[$menuKey]->menu[$subKey]);
                    }

                    // Buscar en sub-submenús
                    if (!empty($subItem->menu)) {
                        foreach ($subItem->menu as $subSubKey => $subSubItem) {
                            if (in_array($subSubItem->name, self::RESTRICTED_PAGES)) {
                                unset($menu[$menuKey]->menu[$subKey]->menu[$subSubKey]);
                            }
                        }
                    }
                }

                // Si el submenú quedó vacío, eliminarlo
                if (empty($menu[$menuKey]->menu)) {
                    unset($menu[$menuKey]);
                }
            }
        }

        return $menu;
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
    }
}
