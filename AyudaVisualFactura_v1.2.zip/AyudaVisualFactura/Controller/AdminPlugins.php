<?php
/**
 * This file is part of AyudaVisualFactura plugin for FacturaScripts
 * Copyright (C) 2024 VisualPublinet
 */

namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\AyudaVisualFactura\Init;

/**
 * Controlador AdminPlugins restringido.
 * Oculta las opciones de gestión de plugins para usuarios no autorizados.
 * Los controles se ocultan mediante la vista personalizada.
 */
class AdminPlugins extends \FacturaScripts\Core\Controller\AdminPlugins
{
    public function getPageData(): array
    {
        $data = parent::getPageData();

        // Ocultar del menú si no es el usuario autorizado
        if (!Init::isAuthorizedAdmin()) {
            $data['showonmenu'] = false;
        }

        return $data;
    }

    public function privateCore(&$response, $user, $permissions)
    {
        // Si no es el usuario autorizado, bloquear acciones de modificación
        if (!Init::isAuthorizedAdmin()) {
            $action = $this->request->inputOrQuery('action', '');
            if (in_array($action, ['disable', 'enable', 'remove', 'upload', 'rebuild'])) {
                Tools::log()->warning('not-allowed-modify');
                return;
            }
        }

        parent::privateCore($response, $user, $permissions);
    }
}
