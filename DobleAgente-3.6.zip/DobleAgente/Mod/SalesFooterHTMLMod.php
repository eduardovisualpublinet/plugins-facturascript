<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Mod;

use FacturaScripts\Core\Contract\SalesModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Tools;


class SalesFooterHTMLMod implements SalesModInterface
{
    public function apply(SalesDocument &$model, array $formData): void
    {
    }

    public function applyBefore(SalesDocument &$model, array $formData): void
    {
    }

    public function assets(): void
    {
    }

    public function newBtnFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return ['totalcomision2'];
    }

    public function newModalFields(): array
    {
        return [];
    }

    public function renderField(SalesDocument $model, string $field): ?string
    {
        if ($field === 'totalcomision2') {
            return $this->totalcomision2($model);
        }
        return null;
    }

    private function totalcomision2(SalesDocument $model): string
    {
        return empty($model->{'totalcomision2'}) ? '' : '<div class="col-sm">'
            . '<div class="mb-3">'
            . Tools::lang()->trans('commission2')
            . '<input type="number" name="totalcomision2" value="' . $model->totalcomision2 . '" class="form-control" disabled />'
            . '</div>'
            . '</div>';
    }
}