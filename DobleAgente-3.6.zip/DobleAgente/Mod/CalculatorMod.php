<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Mod;

use FacturaScripts\Plugins\Comisiones\Mod\CalculatorMod as parentClass;
use FacturaScripts\Core\Model\Base\BusinessDocument;
use FacturaScripts\Core\Model\Base\BusinessDocumentLine;
use FacturaScripts\Core\Model\Base\SalesDocument;

/**
 * Description of CalculatorMod
 *
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class CalculatorMod extends parentClass
{
    public function apply(BusinessDocument &$doc, array &$lines): bool
    {
        if ($doc instanceof SalesDocument) {
            // cargamos comisiones y penalizaciones aplicables
            $this->loadCommissions($doc->idempresa, $doc->codagente2, $doc->codcliente);
            $this->loadPenalties($doc->idempresa, $doc->codagente2);
        }
        return true;
    }

    public function calculate(BusinessDocument &$doc, array &$lines): bool
    {
        if (false === property_exists($doc, 'totalcomision')) {
            // si no existe el campo totalcomision, no se calcula nada
            return true;
        }
        if (property_exists($doc, 'idliquidacion') && $doc->idliquidacion) {
            // si ya hay una liquidación, no se calcula la comisión
            return true;
        }

        // calculamos el total de comisiones
        $totalCommission2 = 0.0;
        foreach ($lines as $line) {
            $totalCommission2 += $line->porcomision2 * $line->pvptotal / 100.0;
        }
        $doc->totalcomision2 = round($totalCommission2, FS_NF0);
        return true;
    }

    public function calculateLine(BusinessDocument $doc, BusinessDocumentLine &$line): bool
    {
        if (false === property_exists($line, 'porcomision')) {
            // si no hay porcomision, no hay comisiones
            return true;
        }
        if (property_exists($doc, 'idliquidacion') && $doc->idliquidacion) {
            // si ya hay una liquidación, no se calcula la comisión
            return true;
        }

        // calculamos el porcentaje de comisión
        $line->porcomision2 = $line->suplido ? 0.0 : $this->getCommission($line);
        return true;
    }

    public function clear(BusinessDocument &$doc, array &$lines): bool
    {
        return true;
    }

    public function getSubtotals(array &$subtotals, BusinessDocument $doc, array $lines): bool
    {
        return true;
    }
}