<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Mod;

use FacturaScripts\Core\Contract\SalesLineModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Tools;

class SalesLineHTMLMod implements SalesLineModInterface
{
    public function apply(SalesDocument &$model, array &$lines, array $formData): void
    {
    }

    public function applyToLine(array $formData, SalesDocumentLine &$line, string $id): void
    {
    }

    public function assets(): void
    {
    }

    public function getFastLine(SalesDocument $model, array $formData): ?SalesDocumentLine
    {
        return null;
    }

    public function map(array $lines, SalesDocument $model): array
    {
        $map = [];
        $num = 0;
        foreach ($lines as $line) {
            $num++;
            $idlinea = $line->idlinea ?? 'n' . $num;
            $map['porcomision2_' . $idlinea] = $line->porcomision2;
        }
        return $map;
    }

    public function newModalFields(): array
    {
        return ['porcomision2'];
    }

    public function newFields(): array
    {
        return [];
    }

    public function newTitles(): array
    {
        return [];
    }

    public function renderField(string $idlinea, SalesDocumentLine $line, SalesDocument $model, string $field): ?string
    {
        if ($field === 'porcomision2') {
            return $this->porcomision2($idlinea, $line, $model);
        }
        return null;
    }

    public function renderTitle(SalesDocument $model, string $field): ?string
    {
        return null;
    }

    private function porcomision2(string $idlinea, SalesDocumentLine $line, SalesDocument $model): string
    {
        if (empty($line->porcomision2)) {
            return '';
        }

        return '<div class="col-6">'
            . '<div class="mb-2">' . Tools::lang()->trans('percentage-commission2')
            . '<input type="number" name="porcomision2_' . $idlinea . '" value="' . $line->porcomision2 . '" class="form-control" disabled />'
            . '</div>'
            . '</div>';
    }
}