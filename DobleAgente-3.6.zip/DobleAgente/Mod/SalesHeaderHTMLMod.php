<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Mod;

use FacturaScripts\Core\Contract\SalesModInterface;
use FacturaScripts\Core\DataSrc\Agentes;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Tools;


/**
 * Description of SalesMod
 *
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SalesHeaderHTMLMod implements SalesModInterface
{
    public function apply(SalesDocument &$model, array $formData): void
    {
        $model->codagente2 = !empty($formData['codagente2']) ? $formData['codagente2'] : null;
    }

    public function applyBefore(SalesDocument &$model, array $formData): void
    {
    }

    public function assets(): void
    {
    }

    public function newBtnFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return [];
    }

    public function newModalFields(): array
    {
        return ['codagente2'];
    }

    public function renderField(SalesDocument $model, string $field): ?string
    {
        switch ($field) {
            case 'codagente2':
                return $this->codagente2($model);
        }

        return null;
    }

    private function codagente2(SalesDocument $model): string
    {
        $agentes = Agentes::all();
        if (count($agentes) === 0) {
            return '';
        }

        $options = ['<option value="">------</option>'];
        foreach ($agentes as $row) {
            $options[] = ($row->codagente === $model->codagente2) ?
                '<option value="' . $row->codagente . '" selected="">' . $row->nombre . '</option>' :
                '<option value="' . $row->codagente . '">' . $row->nombre . '</option>';
        }

        $attributes = $model->editable ? 'name="codagente2"' : 'disabled=""';
        return empty($model->subjectColumnValue()) ? '' : '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . '<a href="' . Agentes::get($model->codagente2)->url() . '">' . Tools::lang()->trans('agent2') . '</a>'
            . '<select ' . $attributes . ' class="form-select">' . implode('', $options) . '</select>'
            . '</div>'
            . '</div>';
    }
}