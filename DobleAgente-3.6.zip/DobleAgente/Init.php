<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente;

use FacturaScripts\Core\Lib\AjaxForms\SalesFooterHTML;
use FacturaScripts\Core\Lib\AjaxForms\SalesHeaderHTML;
use FacturaScripts\Core\Lib\AjaxForms\SalesLineHTML;
use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Dinamic\Model\LineaLiquidacionComision;

/**
 * Description of Init
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class Init extends InitClass
{
    public function init(): void
    {
        // extensiones
        $this->loadExtension(new Extension\Controller\ListFacturaCliente());
        $this->loadExtension(new Extension\Model\Base\SalesDocument());

        // mods
        Calculator::addMod(new Mod\CalculatorMod());
        SalesHeaderHTML::addMod(new Mod\SalesHeaderHTMLMod());
        SalesFooterHTML::addMod(new Mod\SalesFooterHTMLMod());
        SalesLineHTML::addMod(new Mod\SalesLineHTMLMod());
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
        $db = new DataBase();
        foreach (['albaranescli', 'facturascli', 'pedidoscli', 'presupuestoscli'] as $table) {
            if (false === $db->tableExists($table)) {
                continue;
            }

            $sql = 'UPDATE ' . $table . ' SET codagente = NULL WHERE codagente IS NOT NULL'
                . ' AND codagente NOT IN (SELECT codagente FROM agentes);';
            $db->exec($sql);
        }

        // nos aseguramos de que se cree la tabla
        new LineaLiquidacionComision();
    }
}
