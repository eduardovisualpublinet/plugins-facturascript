<?php
/**
 * Copyright (C) 2022 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Extension\Controller;

use Closure;

/**
 * Description of ListFacturaCliente
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class ListFacturaCliente
{
    protected function createViews(): Closure
    {
        return function () {
            $agents = $this->codeModel->all('agentes', 'codagente', 'nombre');
            if (count($agents) > 1) {
                $this->addFilterSelect('ListFacturaCliente', 'codagente2', 'agent2', 'codagente2', $agents);
            }
        };
    }
}
