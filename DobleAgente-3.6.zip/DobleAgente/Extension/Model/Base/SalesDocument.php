<?php
/**
 * Copyright (C) 2022 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Extension\Model\Base;

use Closure;
use FacturaScripts\Core\Lib\Calculator;

/**
 * Description of SalesDocument
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class SalesDocument
{
    public function setSubject(): Closure
    {
        return function ($subject) {
            $this->codagente2 = $subject->codagente2 ?? $this->codagente2;
        };
    }

    protected function saveBefore(): Closure
    {
        return function () {
            if ($this->codagente === $this->codagente2) {
                $this->codagente2 = null;
                $this->totalcomision2 = 0.0;
            }

            return true;
        };
    }

    protected function saveUpdateBefore(): Closure
    {
        return function () {
            if ($this->codagente2) {
                $lines = $this->getLines();
                Calculator::calculate($this, $lines, false);
            }

            return true;
        };
    }
}
