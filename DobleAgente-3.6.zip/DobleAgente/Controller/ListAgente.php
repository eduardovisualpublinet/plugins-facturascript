<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Controller;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Controller\ListAgente as ParentController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Agente;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\LiquidacionComision;
use FacturaScripts\Dinamic\Model\LineaLiquidacionComision;

/**
 * Description of ListAgente
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class ListAgente extends ParentController
{
    protected function generateSettlementsAction(): void
    {
        $codserie = $this->request->request->get('codserie', '');
        $dateFrom = $this->request->request->get('datefrom', '');
        $dateTo = $this->request->request->get('dateto', '');
        $idempresa = $this->request->request->get('idempresa');

        $generated = 0;
        $agenteModel = new Agente();
        foreach ($agenteModel->all([], [], 0, 0) as $agente) {
            $invoiceModel = new FacturaCliente();
            $notInSql = 'SELECT idfactura FROM lineasliquidacionescom WHERE codagente = ' . $this->dataBase->var2str($agente->codagente);
            $where = [
                new DataBaseWhere('idempresa', $idempresa),
                new DataBaseWhere('codserie', $codserie),
                new DataBaseWhere('codagente|codagente2', $agente->codagente),
                new DataBaseWhere('idfactura', $notInSql, 'NOT IN')
            ];

            if (!empty($dateFrom)) {
                $where[] = new DataBaseWhere('fecha', $dateFrom, '>=');
            }

            if (!empty($dateTo)) {
                $where[] = new DataBaseWhere('fecha', $dateTo, '<=');
            }

            $invoices = $invoiceModel->all($where, [], 0, 0);
            if (count($invoices)) {
                $this->newSettlement($agente->codagente, $idempresa, $codserie, $invoices);
                $generated++;
            }
        }

        Tools::log()->notice('items-added-correctly', ['%num%' => $generated]);
    }

    /**
     * @param string $codagente
     * @param int $idempresa
     * @param string $codserie
     * @param FacturaCliente[] $invoices
     */
    protected function newSettlement($codagente, $idempresa, $codserie, $invoices): void
    {
        $newSettlement = new LiquidacionComision();
        $newSettlement->codagente = $codagente;
        $newSettlement->codserie = $codserie;
        $newSettlement->idempresa = $idempresa;
        if (false === $newSettlement->save()) {
            return;
        }

        foreach ($invoices as $invoice) {
            // recalculate commissions
            $lines = $invoice->getLines();
            Calculator::calculate($invoice, $lines, false);
            $invoice->save();

            $newLine = new LineaLiquidacionComision();
            $newLine->codagente = $codagente;
            $newLine->codcliente = $invoice->codcliente;
            $newLine->codigo = $invoice->codigo;
            $newLine->fecha = $invoice->fecha;
            $newLine->idfactura = $invoice->idfactura;
            $newLine->idliquidacion = $newSettlement->idliquidacion;
            $newLine->neto = $invoice->neto;
            $newLine->pagada = $invoice->pagada;

            if ($invoice->codagente == $codagente) {
                $newLine->totalcomision = $invoice->totalcomision;
                $newLine->save();
            } elseif ($invoice->codagente2 == $codagente) {
                $newLine->totalcomision = $invoice->totalcomision2;
                $newLine->save();
            }
        }

        $newSettlement->calculateTotalCommission($newLine->idliquidacion);
    }
}
