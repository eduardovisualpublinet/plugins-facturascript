navigator.geolocation.getCurrentPosition(function(position) {
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;
    document.cookie = "coordenadas=" + lat + "," + lon;
});