<?php

namespace FacturaScripts\Plugins\RegistroHorario\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;



class EditFichajes extends EditController

{
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'Registro Horario';
        $pageData['title'] = 'Registro Horario';
        $pageData['icon'] = 'fa-solid fa-calendar-alt';
        return $pageData;
    }
    //Agregando pestañas
    protected function createViews() {
        parent::createViews();
        $this->setTabsPosition('start-bottom');
        $this->addHtmlView('Mapa', 'mapa', 'Fichajes', 'Mapa','fa-solid fa-code-branch');
    }
    protected function loadData($viewName, $view) {
        switch ($viewName) {

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }
    public function getModelClassName(): string
    {
        return 'Fichajes';
    }

}
