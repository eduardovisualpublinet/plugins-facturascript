<?php

namespace FacturaScripts\Plugins\RegistroHorario\Model\Join;

use FacturaScripts\Core\Tools;


use FacturaScripts\Plugins\RegistroHorario\Model\Fichajes as parentFichajes;


class Fichajes extends \FacturaScripts\Core\Model\Base\JoinModel
{

    public function __construct($data = [])
    {
       parent::__construct($data);
       $this->setMasterModel(new parentFichajes());
    }

    protected function getFields(): array
    {
        return [
            'idfichajes' => 'registro_horarios.idfichajes',
            'codagente' => 'agentes.codagente',
            'cifnif' => 'agentes.cifnif',
            'codagente' => 'registro_horarios.codagente',
            'fecha' => 'registro_horarios.fecha',
            'usuario' => 'registro_horarios.usuario',
            'nick' => 'registro_horarios.nick',
            'entrada' => 'registro_horarios.entrada',
            'salida' => 'registro_horarios.salida',
            'horas' => 'registro_horarios.horas',
            'tipo' => 'registro_horarios.tipo',
            'motivo' => 'registro_horarios.motivo'
        ];
    }

    protected function getSQLFrom(): string
    {
        return 'registro_horarios LEFT JOIN agentes ON agentes.codagente = registro_horarios.codagente';
    }

    protected function getTables(): array
    {
        return [ 'registro_horarios', 'agentes'];
    }
}