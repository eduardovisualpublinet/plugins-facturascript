<?php

namespace FacturaScripts\Plugins\RegistroHorario\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;

class Fichajes extends ModelClass
{
    use ModelTrait;

    public $idfichajes;
    public $fecha;
    public $entrada;
    public $salida;
    public $motivo;
    public $horas;
    public $coordenadas_entrada;
    public $coordenadas_salida;
    public $tipo;
    public $usuario;
    public $nick;
    public $codagente;

    // Solo se usarán si existen en la tabla. Si no existen, no pasa nada.
    public $lastactivity;
    public $lastip;
    public $lastbrowser;

    public static function primaryColumn(): string
    {
        return 'idfichajes';
    }

    public static function tableName(): string
    {
        return 'registro_horarios';
    }
}
