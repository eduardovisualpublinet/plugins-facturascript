<?php
namespace FacturaScripts\Plugins\RegistroHorario;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Plugins\RegistroHorario\Extension\Model\Fichajes;

class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Fichajes());

     // código a ejecutar cada vez que carga FacturaScripts (si este plugin está activado).
     // se ejecutara 1 vez al desinstalar el plugin.
    }
    
    public function update(): void
    {
    // código a ejecutar cada vez que se instala o actualiza el plugin
    }


    public function uninstall(): void
    {
        // código de desinstalación aquí
    }
}
