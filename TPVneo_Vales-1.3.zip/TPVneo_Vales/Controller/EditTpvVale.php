<?php

namespace FacturaScripts\Plugins\TPVneo_Vales\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\AssetManager;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Plugins\TPVneo_Vales\Lib\Tickets\PromocionVale;
use FacturaScripts\Plugins\TPVneo_Vales\Model\TpvVale;

class EditTpvVale extends EditController
{
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu']  = 'sales';
        $pageData['title'] = 'Vales';
        $pageData['icon']  = 'fab fa-money-check-alt';
        return $pageData;
    }

    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    public function getModelClassName(): string
    {
        return 'TpvVale';
    }

    public function execPreviousAction($action): bool
    {
        switch ($action) {
            case 'vale':
                return $this->valeAction();
            case 'prueba':
                return $this->pruebaAction();
        }
        return parent::execPreviousAction($action);
    }

    protected function valeAction(): bool
    {
        // Si el plugin Tickets no está habilitado, no intentamos imprimir
        if (!Plugins::isEnabled('Tickets')) {
            Tools::log()->warning('La impresión de vales requiere el plugin "Tickets". Actívalo para imprimir.');
            return true;
        }

        // Resolvemos la clase en runtime para no provocar autoload fatal si no existe
        $printerClass = '\\FacturaScripts\\Plugins\\Tickets\\Model\\TicketPrinter';
        if (!class_exists($printerClass)) {
            Tools::log()->warning('No se ha encontrado la clase TicketPrinter del plugin "Tickets".');
            return true;
        }

        // Cargamos la impresora (ajusta el ID si procede)
        /** @var object $printer */
        $printer = new $printerClass();
        $printer->loadFromCode(3);

        // Cargamos el vale a imprimir
        $code = (string) ($this->request->query->get('code') ?? '');
        $valor = new TpvVale();
        if (!$valor->loadFromCode($code)) {
            Tools::log()->warning('No se ha encontrado el vale a imprimir.');
            return true;
        }

        // Imprimimos
        PromocionVale::print($valor, $printer, $this->user);
        Tools::log()->notice('Vale enviado a impresión.');
        return true;
    }

    public function loadAssets()
    {
        AssetManager::addJs(FS_ROUTE . '/Plugins/TPVneo_Vales/Assets/JS/EditVales.js');
    }
}
