<?php
namespace FacturaScripts\Plugins\TPVneo_Vales\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Tools;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;;

class ListTpvVale extends ListController

{
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'sales';
        $pageData['title'] = 'Vales';
        $pageData['icon'] = 'fab fa-money-check-alt';
        return $pageData;
    }

    protected function createViews(string $viewName = 'ListTpvVale')
    {
        $this->addView($viewName, 'TpvVale' , 'Vales', 'fab fa-money-check-alt');
        $this->addOrderBy($viewName, ['idvale'], 'ID',2);
        $this->addOrderBy($viewName, ['barcode'], 'Codigo Barras');
        $this->addSearchFields($viewName, ['barcode']);
        $this->addFilterAutocomplete($viewName, 'barcode', 'Codigo Barras', 'barcode', 'vales', 'barcode', 'barcode');
        $this->addOrderBy($viewName, ['fecha_creacion'], 'Fecha Creación');
        $this->addSearchFields($viewName, ['fecha_creacion']);
        $this->addFilterPeriod($viewName, 'fecha_creacion', 'Fecha Creación', 'fecha_creacion');
        $this->addOrderBy($viewName, ['idfactura'], 'Factura Origen');
        $this->addSearchFields($viewName, ['idfactura']);
        $this->addFilterNumber($viewName, 'idfactura', 'Factura Origen', 'idfactura', '<=');
        $this->addFilterNumber($viewName, 'idfactura', 'Factura Origen3', 'idfactura', '>=');
        $this->addOrderBy($viewName, ['importe'], 'Importe');
        $this->addSearchFields($viewName, ['importe']);
        $this->addFilterNumber($viewName, 'importe', 'Importe', 'importe', '<=');
        $this->addFilterNumber($viewName, 'importe', 'Importe4', 'importe', '>=');
        $this->addOrderBy($viewName, ['saldo'], 'Saldo');
        $this->addSearchFields($viewName, ['saldo']);
        $this->addFilterNumber($viewName, 'saldo', 'Saldo', 'saldo', '<=');
        $this->addFilterNumber($viewName, 'saldo', 'Saldo5', 'saldo', '>=');
        $this->addOrderBy($viewName, ['idfactura_uso'], 'Factura Uso');
        $this->addSearchFields($viewName, ['idfactura_uso']);
        $this->addFilterNumber($viewName, 'idfactura_uso', 'Factura Uso', 'idfactura_uso', '<=');
        $this->addFilterNumber($viewName, 'idfactura_uso', 'Factura Uso6', 'idfactura_uso', '>=');
        $this->addOrderBy($viewName, ['fecha_uso'], 'Fecha Uso');
        $this->addSearchFields($viewName, ['fecha_uso']);
        $this->addOrderBy($viewName, ['activo'], 'Activo');
        $this->addSearchFields($viewName, ['activo']);
        $this->addFilterCheckbox($viewName, 'activo', 'Activo', 'activo');
    }

}