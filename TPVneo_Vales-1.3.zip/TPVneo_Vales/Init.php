<?php

namespace FacturaScripts\Plugins\TPVneo_Vales;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;

class Init extends InitClass
{
    public function init(): void
    {
       // $this->loadExtension(new Extension\Model\TpvTerminal());   
     // código a ejecutar cada vez que carga FacturaScripts (si este plugin está activado).
    }

    public function update(): void
    {
    // código a ejecutar cada vez que se instala o actualiza el plugin
    }


    public function uninstall(): void
    {
        // código de desinstalación aquí
    }
}