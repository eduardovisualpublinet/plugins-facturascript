
document.addEventListener("DOMContentLoaded", function() {
    const recargarBtn = document.querySelector('button[title="Imprimir Vale"]');

    if (recargarBtn) {
        recargarBtn.addEventListener("click", function() {
            // Realiza una solicitud a la URL en el puerto 8089
            fetch("http://localhost:8089")
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json(); // Suponiendo que el servidor responde con JSON
                })
                .then(data => {
                    console.log('Éxito:', data); // Maneja la respuesta aquí
                    // Aquí puedes actualizar tu página con los datos que obtuviste del servidor
                })
                .catch((error) => {
                    console.error('Error:', error); // Maneja errores aquí
                });
        });
    } else {
        console.error("Botón no encontrado");
    }
});