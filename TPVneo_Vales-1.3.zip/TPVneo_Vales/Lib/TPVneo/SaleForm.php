<?php

namespace FacturaScripts\Plugins\TPVneo_Vales\Lib\TPVneo;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\DataSrc\Agentes;
use FacturaScripts\Core\DataSrc\Divisas;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Translator;
use FacturaScripts\Dinamic\Lib\Accounting\InvoiceToAccounting;
use FacturaScripts\Dinamic\Lib\Email\NewMail;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\PrePago;
use FacturaScripts\Dinamic\Model\PresupuestoCliente;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\TpvCaja;
use FacturaScripts\Dinamic\Model\TpvPago;
use FacturaScripts\Dinamic\Model\TpvTerminal;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Dinamic\Model\Variante;
use FacturaScripts\Dinamic\Model\TpvVale;
use FacturaScripts\Plugins\TPVneo\Lib\TPVneo\SaleForm as ParentClass;
use FacturaScripts\Plugins\TPVneo\Lib\TPVneo\TpvTrait;

class SaleForm extends ParentClass
{
    use TpvTrait;

    public static function apply(array $formData, User $user, TpvTerminal $tpv, ?string $codagente): void
    {
        self::clearCart($tpv);
        $user->codagente = $codagente;
        self::$doc->setAuthor($user);

        $cliente = new Cliente();
        $codcliente = empty($formData['codcliente']) ? $tpv->codcliente : $formData['codcliente'];
        $cliente->load($codcliente);
        self::$doc->setSubject($cliente);

        // líneas del carrito
        $linesCart = $formData['linesCart'] ?? 100;
        for ($num = 1; $num <= $linesCart; $num++) {
            if (false === isset($formData['descripcion_' . $num])) {
                continue;
            }

            if ($formData['action'] === 'rm-line' && $formData['action-code'] == $num) {
                continue;
            }

            $newLine = empty($formData['referencia_' . $num])
                ? self::$doc->getNewLine()
                : self::$doc->getNewProductLine($formData['referencia_' . $num]);

            $newLine->orden = (int)$formData['orden_' . $num];
            $newLine->cantidad = (float)$formData['cantidad_' . $num];
            $newLine->descripcion = $formData['descripcion_' . $num];
            $newLine->idlinea = $formData['idlinea_' . $num];
            $newLine->codimpuesto = $formData['codimpuesto_' . $num];

            if ($tpv->adddiscount) {
                $newLine->dtopor = (float)$formData['dtopor_' . $num];
            }

            // si permite cambiar el precio y el nuevo precio no está vacío,
            // o si es una línea nueva y el precio no está vacío
            // calculamos el precio sin iva
            if ($tpv->changeprice && $formData['new_precio_' . $num] != ''
                || empty($formData['referencia_' . $num]) && $formData['new_precio_' . $num] != '') {
                $newLine->pvpunitario = round((100 * floatval($formData['new_precio_' . $num])) / (100 + floatval($newLine->iva)), 5);
            } else {
                $newLine->pvpunitario = (float)$formData['pvpunitario_' . $num];
            }

            self::$lines[] = $newLine;
        }

        // new line
        switch ($formData['action']) {
            case 'add-barcode':
                
                $variant = new Variante();
                $where = [new DataBaseWhere('codbarras', $formData['action-code'])];
                if (false === $variant->loadWhere($where)) {
                    // Si no hay productos, se busca en vales
                    $vales = new TpvVale();
                    $where = [new DataBaseWhere('barcode', strtoupper($formData['action-code']))];
                    if ($vales->loadWhere($where)) {
                        // Vale encontrado
                        $line = self::$doc->getNewLine();
                        $line->orden = count(self::$lines) + 1;
                        $line->descripcion = $vales->barcode.' | '.$vales->importe.'€';
                        $line->cantidad = $vales->importe;
                        $line->cantidad = 0;
                        $line->codimpuesto = null;
                        $line->iva = 0;
                        //$line->excepcioniva='ES_OTHER';
                        $line->mostrar_cantidad = 0;
                        $line->mostrar_precio = 0;
                        
                        self::$lines[] = $line;

                        // Asignar el importe del vale
                        $importeVale = $vales->importe;
                        Tools::log()->info('Agregado vale '.$vales->barcode.' con  ' . $vales->importe.' Euros');
                          
                        break;
                    } else {
                        Tools::log()->warning('El articulo o vale '.strtoupper($formData['action-code']).' no se ha encontrado');
                        break;
                    }
                    
                }

                // si ya existe el producto en el carrito
                // y el tpv tiene la opción activada de agrupar líneas
                // se suma 1 a la cantidad
                foreach (self::$lines as $line) {
                    if ($variant->referencia == $line->referencia && $tpv->grouplines) {
                        $line->cantidad += 1;
                        break 2;
                    }
                }

                // si no existe el producto en el carrito
                // o no se ha activado la opción de agrupar líneas
                // se añade una nueva línea
                $newLine = self::$doc->getNewProductLine($variant->referencia);
                $newLine->orden = count(self::$lines) + 1;
                self::$lines[] = $newLine;
                break;

            case 'add-product':
                // si ya existe el producto en el carrito
                // y el tpv tiene la opción activada de agrupar líneas
                // se suma 1 a la cantidad
                foreach (self::$lines as $line) {
                    if ($line->referencia == $formData['action-code'] && $tpv->grouplines) {
                        $line->cantidad += 1;
                        break 2;
                    }
                }

                // si no existe el producto en el carrito
                // o no se ha activado la opción de agrupar líneas
                // se añade una nueva línea
                $newLine = self::$doc->getNewProductLine($formData['action-code']);
                $newLine->orden = count(self::$lines) + 1;
                self::$lines[] = $newLine;
                break;

            case 'new-line':
                $line = self::$doc->getNewLine();
                $line->orden = count(self::$lines) + 1;
                $line->descripcion = $formData['new-desc'];
                $line->codimpuesto = $formData['new-tax'];
                self::$lines[] = $line;
                break;
            

                
        }

        self::$doc->dtopor1 = (float)$formData['dtopor_global'] ?? 0.0;
        Calculator::calculate(self::$doc, self::$lines, false);
    }
  
    public static function saveDoc(array $formData, User $user, TpvCaja $caja, ?string $codagente): bool
    {
        $tpv = $caja->getTerminal();
        static::apply($formData, $user, $tpv, $codagente);

        // restablecemos los totales antes de guardar
        self::resetDocTotal();

        // establecemos la forma de pago
        if ($formData['action'] == 'save-cart' && $formData['formasPagos'] >= 1) {
            foreach (FormasPago::all() as $pago) {
                if (!isset($formData[$pago->codpago])) {
                    continue;
                }

                self::$doc->codpago = $pago->codpago;
                break;
            }
        } else {
            self::$doc->codpago = $tpv->codpago;
        }
        if (!empty($formData['codpago'])) {
            self::$doc->codpago = $formData['codpago'];
        }

        self::$doc->idtpv = $tpv->idtpv;
        self::$doc->idcaja = $caja->idcaja;
        self::$doc->codserie = $formData['codserie'] ?? $tpv->codserie;
        self::$doc->coddivisa = $tpv->coddivisa;
        self::$doc->codalmacen = $tpv->codalmacen;
        self::$doc->observaciones = $formData['observations'] ?? '';
        self::$doc->numero2 = $formData['numero2'] ?? '';
        self::$doc->tpv_cambio = 0.0;
        self::$doc->tpv_efectivo = 0.0;
        self::$doc->tpv_venta = true;

        $dataBase = new DataBase();
        $dataBase->beginTransaction();

        if (self::$doc->save() === false) {
            $dataBase->rollback();
            return false;
        }

        // comprobamos las líneas
        foreach (self::$lines as $line) {
            // si la línea no tiene precio y no se permite vender sin precio, cancelamos la operación
            if ($tpv->not_line_price_empty && empty($line->pvpunitario)) {
                Tools::log()->warning('selling-lines-zero-price-not-allowed');
                $dataBase->rollback();
                return false;
            }

            // añadimos las líneas al documento
            $newLine = self::$doc->getNewLine($line->toArray());
            if ($newLine->save() === false) {
                $dataBase->rollback();
                return false;
            }
        }

        // calculamos los totales
        $lines = self::$doc->getLines();
        Calculator::calculate(self::$doc, $lines, false);

        // guardamos el dinero recibido en metálico y el cambio
        if (isset($formData[$tpv->codpago]) && $formData[$tpv->codpago] > 0) {
            self::$doc->tpv_efectivo = $formData[$tpv->codpago];
            self::$doc->tpv_cambio = max(self::$doc->tpv_efectivo - self::$doc->total, 0);
        }

        // guardamos documento
        if (false === self::$doc->save()) {
            Tools::log()->warning('error-saving-document');
            $dataBase->rollback();
            return false;
        }

        // si hay varias formas de pago, guardamos los recibos
        if ($formData['action'] == 'save-cart' && $formData['formasPagos'] >= 1) {

            if ($tpv->doctype === 'FacturaCliente') {

                // eliminamos los recibos anteriores
                foreach (self::$doc->getReceipts() as $recibo) {
                    $recibo->delete();
                }

                // obtenemos las formas de pago asociadas al TPV
                $tpvPago = new TpvPago();
                $where = [new DataBaseWhere('idtpv', $tpv->idtpv)];
                $tpvPagos = $tpvPago->all($where, [], 0, 0);

                // leemos todas las formas de pago
                foreach (FormasPago::all() as $pago) {
                    // si la forma de pago no existe en el array enviado de formas de pago usadas, continuamos
                    if (!isset($formData[$pago->codpago])) {
                        continue;
                    }

                    // creamos el recibo
                    $newRecibo = new ReciboCliente();
                    $newRecibo->codigofactura = self::$doc->codigo;
                    $newRecibo->idfactura = self::$doc->id();
                    $newRecibo->codcliente = self::$doc->codcliente;
                    $newRecibo->nick = self::$doc->nick;
                    $newRecibo->codpago = $pago->codpago;

                    // si la forma de pago es la del TPV, y el total recibido es mayor o igual que el total de la factura,
                    // el importe del recibo es el total de la factura
                    if ($pago->codpago === $tpv->codpago && $formData[$pago->codpago] >= self::$doc->total) {
                        $newRecibo->importe = self::$doc->total;
                    } else {
                        $newRecibo->importe = $formData[$pago->codpago];
                    }

                    // si no tiene formas de pago asociadas al TPV, marcamos el recibo como pagado
                    if (count($tpvPagos) === 0) {
                        $newRecibo->pagado = true;
                    } else {
                        // si tiene formas de pago asociadas al TPV,
                        // comprobamos si la forma de pago es la del recibo y si la forma de pago está marcada como pagada
                        foreach ($tpvPagos as $tpvPago) {
                            if ($tpvPago->codpago === $newRecibo->codpago && $tpvPago->paid) {
                                $newRecibo->pagado = true;
                                break;
                            }
                        }
                    }

                    $newRecibo->save();
                }

            } elseif (Plugins::isEnabled('PrePagos')) {

                // es un albarán, guardamos los pagos como anticipos
                // leemos todas las formas de pago
                foreach (FormasPago::all() as $pago) {
                    // si la forma de pago no existe en el array enviado de formas de pago usadas, continuamos
                    if (!isset($formData[$pago->codpago])) {
                        continue;
                    }

                    // buscamos si había un anticipo aparcado
                    $totalAnticipo = 0;
                    if (isset($formData['codpark']) && $formData['codpark'] != '') {
                        $anticipoPrevio = new PrePago();
                        $where = [
                            new DataBaseWhere('modelname', 'PresupuestoCliente'),
                            new DataBaseWhere('modelid', $formData['codpark']),
                            new DataBaseWhere('codpago', $pago->codpago),
                        ];
                        if ($anticipoPrevio->loadWhere($where)) {
                            $totalAnticipo = $anticipoPrevio->amount;

                            // asignamos el anticipo al albarán
                            $anticipoPrevio->modelname = self::$doc->modelClassName();
                            $anticipoPrevio->modelid = self::$doc->id();
                            $anticipoPrevio->save();
                        }
                    }

                    $anticipo = new PrePago();
                    $anticipo->amount = $formData[$pago->codpago] - $totalAnticipo;
                    $anticipo->codcliente = self::$doc->codcliente;
                    $anticipo->codpago = $pago->codpago;
                    $anticipo->modelname = self::$doc->modelClassName();
                    $anticipo->modelid = self::$doc->id();
                    if (false === empty($anticipo->amount)) {
                        $anticipo->save();
                    }
                }
            } 
        }

        // recargamos el documento
        self::$doc->loadFromCode(self::$doc->id());

        // ponemos la factura en emitida
        if ($formData['action'] == 'save-cart' && $tpv->doctype === 'FacturaCliente' && self::$doc->getStatus()->editable) {
            // cambiamos el estado de la factura si su estado actual es editable
            foreach (self::$doc->getAvailableStatus() as $stat) {
                if (false === $stat->editable) {
                    self::$doc->idestado = $stat->idestado;
                    self::$doc->save();
                    break;
                }
            }
        }

        // buscamos el presupuesto relacionado y lo eliminamos
        if ($formData['action'] == 'save-cart' && isset($formData['codpark']) && $formData['codpark'] != '') {
            $pr = new PresupuestoCliente();
            if ($pr->load($formData['codpark'])) {
                $pr->delete();
            }
        }

        $dataBase->commit();
        self::$doc->code = self::$doc->id();
        self::$lastDocSave = self::$doc;

        /// TPVNEO VALES - marcamos el vale como usado
        if (Plugins::isEnabled('TPVneo_Vales') && isset($formData[$tpv->codpago_vale])) {
            

                // si esta el plugin activo y la venta tiene la forma de pago es la definida en el TPV como la de los Vales
         
                // buscamos si había un vale asignado y lo marcamos como usado
                $sql_update_vale = "UPDATE tpvsneo_vales 
                SET activo = 0,
                idfactura_uso= ".self::$doc->id().",
                iduso= ".self::$doc->id().",
                idtpv_uso= ".self::$doc->idtpv.",
                idcaja_uso= ".self::$doc->idcaja.",
                nick_uso= '".self::$doc->nick."',
                fecha_uso = NOW(),
                saldo = (saldo-".$formData[$tpv->codpago_vale].")
                WHERE barcode in (select SUBSTRING(descripcion, 1, 13) AS vale_barcode 
                FROM lineasfacturascli  WHERE descripcion LIKE 'VALE%' AND idfactura=".self::$doc->id().");
                ";
                
                $dataBase_Vale = new DataBase();
                $dataBase_Vale->exec($sql_update_vale);
                // marcamos el vale como usado y asignamos documento
               //echo $sql_update_vale;
            
        }
        return true;
    }
}