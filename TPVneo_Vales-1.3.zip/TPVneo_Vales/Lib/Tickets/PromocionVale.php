<?php


namespace FacturaScripts\Plugins\TPVneo_Vales\Lib\Tickets;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Tools;

use FacturaScripts\Dinamic\Model\Agente;
use FacturaScripts\Dinamic\Model\Ticket;
use FacturaScripts\Dinamic\Model\TicketPrinter;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Dinamic\Lib\Tickets\BaseTicket;
use FacturaScripts\Core\Base\ToolBox;
use FacturaScripts\Dinamic\Model\Promotion;
use Mike42\Escpos\Printer;
use FacturaScripts\Core\Base\Translator;
use Mike42\Escpos\PrintConnectors\DummyPrintConnector;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\GdEscposImage;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;

use DateTime;


/**
 * Description of PromocionVale
 *
 */
class PromocionVale extends BaseTicket
{
    public static function print(ModelClass $model, TicketPrinter $printer, User $user, Agente $agent = null): bool
    {
        static::init();

        $ticket = new Ticket();
        $ticket->idprinter = static::$escpos->id;
        $ticket->nick = $user->nick;
        $ticket->title = 'Prueba';

        static::setHeader($model, $printer, 'hola');
        static::setBody($model, $printer);
        static::setFooter($model, $printer);
        $ticket->body = static::getBody();
        $ticket->base64 = true;
        $ticket->appversion = 1;

        if ($agent) {
            $ticket->codagente = $agent->codagente;
        }

        $ticket->save();
        return true;
    }

    protected static function setHeader(ModelClass $model, TicketPrinter $printer, string $title): void
    {

        /*
        var_dump($model);
        echo "<br><hr><br>";
        var_dump($printer);
        echo "<br><hr><br>";
        var_dump($title);
        echo "<br><hr><br>";
        echo $model->importe;
        */
        static::$escpos->setJustification(Printer::JUSTIFY_CENTER);
        $titulo = 'Vale de '.$model->importe.' Euros';

        static::$escpos->setTextSize(2, 2);

        static::$escpos->text(static::sanitize($titulo) . "\n");
        static::$escpos->setTextSize(1,1);
        static::$escpos->text("\n--------------------------------\n");
    }

    protected static function setBody(ModelClass $model, TicketPrinter $printer): void
    {
        static::$escpos->setTextSize(1,1);
        static::$escpos->text(static::sanitize('TextoTicket') . "\n");

        $numeroReferencia = '747 77 38 21';
        static::$escpos->text(static::sanitize('Numero de referencia: ' . $numeroReferencia . '.') . "\n");
        $sueldo = 50;
        static::$escpos->text(static::sanitize('Saldo: ' . $sueldo . ' €.') . "\n");
        $string = 'Validez: hasta el 11-11-2024.';
        static::$escpos->text(static::sanitize($string) . "\n");
        static::$escpos->text("\n--------------------------------\n");
        
    }

    protected static function setFooter(ModelClass $model, TicketPrinter $printer): void
    {
       // static::$escpos->setTextSize(static::$escpos->footer_font_size, static::$escpos->footer_font_size);
        static::$escpos->setTextSize(1,1);
        $mensajeFinal = 'Gracias por su compra';
        static::$escpos->setBarcodeHeight(100);
        static::$escpos->setBarcodeWidth(20);
       // $url = $model->getBarcodeImg();

        // if (empty($url)) {
        //     $url = 'no se genera url';
        // } else {
        //     $url = 'hay algo en la url';
        // }
        //$logo = EscposImage::load($url , false);
      

        static::$escpos->setJustification(Printer::JUSTIFY_CENTER);
        //static::$escpos->graphics($logo);

        static::$escpos->text("\n" . static::sanitize($mensajeFinal) . "\n");
       // static::$escpos->text("\n" . static::sanitize($url) . "\n");

        // $img = $model->loadImageFromUrl($url);

        // static::$escpos->graphics($img);
        /* Height and width */


static::$escpos->selectPrintMode();

//static::$escpos->text("Default look\n");
static::$escpos->setBarcodeHeight(100);
static::$escpos->setBarcodeWidth(30);
//static::$escpos->barcode("VALE31729843182", Printer::BARCODE_CODE39);
//static::$escpos->text($model->codebacodbarras."\nVALE31729843182\n");
static::$escpos->feed();
// Set to something sensible for the rest of the examples

$standards = array (
Printer::BARCODE_CODE128 => array (
    "title" => "Code128",
    "caption" => "Variable length- any ASCII is available",
    "example" => array (
            array (
                    "caption" => "Code set A uppercase & symbols",
                    "content" => "{A" . "012ABCD"
            ),
            array (
                    "caption" => "Code set B general text",
                    "content" => "{B" . "012ABCDabcd"
            ),
            array (
                    "caption" => "Code set C compact numbers\n Sending chr(21) chr(32) chr(43)",
                    "content" => "{C" . chr(21) . chr(32) . chr(43)
            )
    )
)
            
            );
         
//$codigobarras=$model->barcode;
    
    static::$escpos->setBarcodeTextPosition(Printer::BARCODE_TEXT_BELOW);

    static::$escpos->selectPrintMode(Printer::MODE_DOUBLE_HEIGHT | Printer::MODE_DOUBLE_WIDTH);
    //static::$escpos->text($standard ["title"] . "\n");
    //static::$escpos->selectPrintMode();
    //static::$escpos->text($standard ["caption"] . "\n\n");

    static::$escpos->setEmphasis(true);
    //static::$escpos->text($barcode ["caption"] . "\n");
    static::$escpos->setEmphasis(false);
    //static::$escpos->text("Content: " . $barcode ["content"] . "\n");
    static::$escpos->barcode("{A".$model->barcode, Printer::BARCODE_CODE128);
    //static::$escpos->barcode("{C" . chr(21) . chr(32) . chr(43), Printer::BARCODE_CODE128);
 
 


    }

}