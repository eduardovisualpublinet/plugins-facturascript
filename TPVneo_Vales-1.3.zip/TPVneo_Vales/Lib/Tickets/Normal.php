<?php

namespace FacturaScripts\Plugins\TPVneo_Vales\Lib\Tickets;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Dinamic\Model\Agente;
use FacturaScripts\Dinamic\Model\Ticket;
use FacturaScripts\Dinamic\Model\TicketPrinter;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Plugins\Tickets\Lib\Tickets\Normal as ParentClass;
use Mike42\Escpos\Printer;
use FacturaScripts\Dinamic\Model\TpvVale;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;


class Normal extends ParentClass
{
    public static function print(ModelClass $model, TicketPrinter $printer, User $user, Agente $agent = null): bool
    {
        static::init();

        $ticket = new Ticket();
        $ticket->idprinter = $printer->id;
        $ticket->nick = $user->nick;
        $ticket->title = self::$i18n->trans($model->modelClassName() . '-min') . ' ' . $model->codigo;

        static::setHeader($model, $printer, $ticket->title);
        static::setBody($model, $printer);
        //static::$escpos->cut();
        // CODIGO DE BARRAS DEL TICKET
        static::$escpos->setJustification(Printer::JUSTIFY_CENTER);
        static::$escpos->setBarcodeTextPosition(Printer::BARCODE_TEXT_BELOW);
        static::$escpos->selectPrintMode(Printer::MODE_DOUBLE_HEIGHT | Printer::MODE_DOUBLE_WIDTH);
        static::$escpos->setBarcodeHeight(100);
        static::$escpos->setBarcodeWidth(30);
        static::$escpos->barcode("{A".$model->codigo, Printer::BARCODE_CODE128);
        // FIN CODIGO DE BARRAS
        //static::$escpos->cut();
        static::setFooter($model, $printer);
        static::printVale($model, $printer, $ticket);
        $ticket->body = static::getBody();
        $ticket->base64 = true;
        $ticket->appversion = 1;

        if ($agent) {
            $ticket->codagente = $agent->codagente;
        }

        return $ticket->save();
    }

    protected static function printVale($model, $printer, $ticket): void
    {
          //Buscamos si el ticket tiene un vale asignad  
            $idfactura_creacion=$model->idfactura;

            $modelClass = '\\FacturaScripts\\Dinamic\\Model\\TpvVale';
                $doc = new $modelClass();
                $where = [
                    new DataBaseWhere('idfactura_creacion', $idfactura_creacion),
                    new DataBaseWhere('activo', true)
                ];
    
                if (true === $doc->loadWhere($where)) {
                    static::$escpos->cut();
                    static::setHeader($model, $printer, $ticket->title);
                    static::$escpos->setJustification(Printer::JUSTIFY_CENTER);
                    $titulo = 'Vale de '.number_format($doc->importe, 2).'€';
                    static::$escpos->setTextSize(2, 2);
                    static::$escpos->text(static::sanitize($titulo) . "\n\n");
                    static::$escpos->setTextSize(1,1);
                    //static::$escpos->text("\n--------------------------------\n");
                    static::$escpos->setBarcodeHeight(100);
                    static::$escpos->setBarcodeWidth(30);
                    static::$escpos->barcode("{A".$doc->barcode, Printer::BARCODE_CODE128);

                    static::$escpos->setTextSize(1,1);
                    static::$escpos->text("\n--------------------------------\n");
                    
                    static::$escpos->text(static::sanitize("Gracias por su visita") . "\n");

                }
    

    }

    protected static function printLines(TicketPrinter $printer, array $lines): void
    {
        $th = '';
        $width = $printer->linelen;

        if ($printer->print_lines_quantity) {
            $th .= sprintf("%5s", static::$i18n->trans('quantity-abb')) . ' ';
            $width -= 6;
        }

        if ($printer->print_lines_net || $printer->print_lines_total) {
            $width -= 11;
        }

        if ($printer->print_lines_reference) {
            $th .= sprintf("%-" . $width . "s", static::$i18n->trans('reference-abb'));
        } elseif ($printer->print_lines_description) {
            $th .= sprintf("%-" . $width . "s", static::$i18n->trans('description-abb'));
        }

        if ($printer->print_lines_net) {
            $th .= sprintf("%11s", static::$i18n->trans('net-abb'));
        } elseif ($printer->print_lines_total) {
            $th .= sprintf("%11s", static::$i18n->trans('total-abb'));
        }
        if (empty($th)) {
            return;
        }

        static::$escpos->text(static::sanitize($th) . "\n");
        static::$escpos->text($printer->getDashLine() . "\n");

        foreach ($lines as $line) {
            $td = '';
            if (substr($line->descripcion, 0, 4) === "VALE") {
                $td .= "**" .str_pad(substr(str_replace('.', ',', $line->descripcion), 0, $width), $width, ' ', STR_PAD_BOTH);
                $td .= "**\n";
            } else {

                if ($printer->print_lines_quantity) {
                    $td .= sprintf("%5s", $line->cantidad) . ' ';
                }

                if ($printer->print_lines_reference) {
                    $td .= sprintf("%-" . $width . "s", $line->referencia);
                } elseif ($printer->print_lines_description) {
                    $td .= sprintf("%-" . $width . "s", substr($line->descripcion, 0, $width));
                }

                if ($printer->print_lines_net) {
                    $td .= sprintf("%11s", Tools::number($line->pvptotal));
                } elseif ($printer->print_lines_total) {
                    $total = $line->pvptotal * (100 + $line->iva + $line->recargo) / 100;
                    $td .= sprintf("%11s", Tools::number($total));
                }

                $jump = false;
                if ($printer->print_lines_reference && $printer->print_lines_description) {
                    $td .= "\n" . sprintf("%-" . $printer->linelen . "s", substr($line->descripcion, 0, $printer->linelen));
                    $jump = true;
                }

                if ($printer->print_lines_price) {
                    $td .= "\n" . sprintf("%11s", Tools::lang()->trans('price-abb') . ': ' . Tools::number($line->pvpunitario));
                    $jump = true;
                }

                if ($printer->print_lines_discount && $line->dtopor > 0) {
                    $td .= $printer->print_lines_price ? ' ' : "\n";
                    $td .= sprintf("%11s", Tools::lang()->trans('discount-abb') . ': ' . $line->dtopor . '%');
                    $jump = true;
                }

                if ($printer->print_lines_net && $printer->print_lines_total) {
                    $td .= $printer->print_lines_price ? ' ' : "\n";
                    $td .= sprintf("%11s", Tools::lang()->trans('net-abb') . ': ' . Tools::number($line->pvptotal));
                    $jump = true;
                }

                if ($jump) {
                    $td .= "\n";
                }
            }

            static::$escpos->text(static::sanitize($td) . "\n");
            static::$escpos->text(static::getTrazabilidad($line, $width));
        }

        static::$escpos->text($printer->getDashLine() . "\n");
    }

    protected static function setBody(ModelClass $model, TicketPrinter $printer): void
    {
        if (false === in_array($model->modelClassName(), ['PresupuestoCliente', 'PedidoCliente', 'AlbaranCliente', 'FacturaCliente'])) {
            return;
        }

        // establecemos el tamaño de la fuente
        static::$escpos->setTextSize($printer->font_size, $printer->font_size);
        //static::$escpos->text("\n----body 2222--------------\n");
        // añadimos las líneas
        $lines = self::getLines($model);
        static::printLines($printer, $lines);

        foreach (static::getSubtotals($model, $lines) as $item) {
            $text = sprintf("%" . ($printer->linelen - 11) . "s", static::$i18n->trans('tax-base') . ' ' . $item['taxp']) . " "
                . sprintf("%10s", Tools::number($item['taxbase'])) . "\n"
                . sprintf("%" . ($printer->linelen - 11) . "s", $item['tax']) . " "
                . sprintf("%10s", Tools::number($item['taxamount']));
            static::$escpos->text(static::sanitize($text) . "\n");

            if ($item['taxsurcharge']) {
                $text = sprintf("%" . ($printer->linelen - 11) . "s", "RE " . $item['taxsurchargep']) . " "
                    . sprintf("%10s", Tools::number($item['taxsurcharge']));
                static::$escpos->text(static::sanitize($text) . "\n");
            }
        }
        static::$escpos->text($printer->getDashLine() . "\n");

        // añadimos los totales
        $text = sprintf("%" . ($printer->linelen - 11) . "s", static::$i18n->trans('total')) . " "
            . sprintf("%10s", Tools::number($model->total));

        if (property_exists($model, 'tpv_efectivo') && $model->tpv_efectivo > 0) {
            $text .= sprintf("%" . ($printer->linelen - 11) . "s", static::$i18n->trans('cash')) . " "
                . sprintf("%10s", Tools::number($model->tpv_efectivo)) . "\n";
        }
        if (property_exists($model, 'tpv_cambio') && $model->tpv_cambio > 0) {
            $text .= sprintf("%" . ($printer->linelen - 11) . "s", static::$i18n->trans('money-change')) . " "
                . sprintf("%10s", Tools::number($model->tpv_cambio)) . "\n";
        }

        static::$escpos->text(static::sanitize($text) . "\n\n");

        // añadimos las formas de pago
        if ($printer->print_payment_methods) {
            static::$escpos->text(static::sanitize(static::getPaymentMethods($model, $printer)));
        }

        // añadimos los recibos
        if ($printer->print_invoice_receipts && $model->modelClassName() === 'FacturaCliente') {
            static::$escpos->text(static::sanitize(static::getReceipts($model, $printer)));
        }
    }
}