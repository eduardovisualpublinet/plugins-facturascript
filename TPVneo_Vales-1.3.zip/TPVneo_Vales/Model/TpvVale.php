<?php
declare(strict_types=1);

namespace FacturaScripts\Plugins\TPVneo_Vales\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Session;

class TpvVale extends ModelClass
{
    use ModelTrait;

    public $idvale;
    public $nick;
    public $barcode;
    public $fecha_creacion;
    public $idfactura_creacion;
    public $idalbaran_creacion;
    public $modelo_creacion;
    public $importe;
    public $saldo;
    public $idfactura_uso;
    public $fecha_uso;
    public $activo;
    public $idorigen;
    public $iduso;
    /** @var int */
    public $idcaja_creacion;
    public $idcaja_uso;
    /** @var int */
    public $idtpv_creacion;
    public $idtpv_uso;
    public $nick_uso;

    /** Firma requerida por 2025.5 */
    public function clear(): void
    {
        parent::clear();
        $this->nick = Session::get('user')->nick ?? null;

        // Genera un código de barras por defecto
        $number = random_int(100000, 999999); // 6 dígitos
        $year = date('y');
        $this->barcode = 'VALE' . $year . $number;
    }

    public static function primaryColumn(): string
    {
        return 'idvale';
    }

    public static function tableName(): string
    {
        return 'tpvsneo_vales';
    }

    public function primaryDescriptionColumn(): string
    {
        return 'barcode';
    }
}
