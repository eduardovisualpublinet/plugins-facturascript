<?php
/**
 * This file is part of AyudaVisualFactura plugin for FacturaScripts
 * Copyright (C) 2024 VisualPublinet
 */

namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\AyudaVisualFactura\Init;

/**
 * Controlador Updater restringido.
 * Oculta las opciones de actualización para usuarios no autorizados.
 */
class Updater extends \FacturaScripts\Core\Controller\Updater
{
    public function getPageData(): array
    {
        $data = parent::getPageData();

        // Ocultar del menú si no es el usuario autorizado
        if (!Init::isAuthorizedAdmin()) {
            $data['showonmenu'] = false;
        }

        return $data;
    }

    public function privateCore(&$response, $user, $permissions)
    {
        // Si no es el usuario autorizado, bloquear todas las acciones
        if (!Init::isAuthorizedAdmin()) {
            $action = $this->request->inputOrQuery('action', '');
            if (!empty($action)) {
                Tools::log()->warning('not-allowed-modify');
                return;
            }
        }

        parent::privateCore($response, $user, $permissions);
    }
}
