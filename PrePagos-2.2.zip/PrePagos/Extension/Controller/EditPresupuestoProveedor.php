<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PrePagos\Extension\Controller;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditPresupuestoProveedor
{
    use PrePagoProvControllerTrait;
}
