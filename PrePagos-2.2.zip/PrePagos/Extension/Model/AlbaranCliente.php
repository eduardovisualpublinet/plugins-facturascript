<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PrePagos\Extension\Model;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class AlbaranCliente
{
    use PrePagoCliModelTrait;
}
