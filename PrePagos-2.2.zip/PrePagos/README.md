# PrePagos
Permite añadir anticipos a los presupuestos, pedidos y albaranes de compra y de venta.

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Documentación
- https://facturascripts.com/plugins/prepagos

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PrePagos**.