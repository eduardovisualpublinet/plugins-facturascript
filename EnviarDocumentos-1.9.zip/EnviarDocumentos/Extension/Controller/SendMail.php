<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\EnviarDocumentos\Extension\Controller;

use Closure;
use FacturaScripts\Core\Validator;
use FacturaScripts\Dinamic\Model\Cliente;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SendMail
{
    public function setEmail(): Closure
    {
        return function () {
            $className = self::MODEL_NAMESPACE . $this->request->queryOrInput('modelClassName', '');
            if (false === class_exists($className)) {
                return;
            }

            $model = new $className();
            if (false === $model->load($this->request->queryOrInput('modelCode', ''))) {
                return;
            }

            $cliente = new Cliente();
            if ($model->hasColumn('codcliente') && $cliente->load($model->codcliente)) {
                // añadimos los nuevos campos
                $addresses = explode(',', $cliente->emailto ?? '');
                foreach ($addresses as $address) {
                    if (false === empty($address) && Validator::email($address)) {
                        $this->newMail->to($address);
                    }
                }

                $cc_addresses = explode(',', $cliente->emailcc ?? '');
                foreach ($cc_addresses as $address) {
                    if (false === empty($address) && Validator::email($address)) {
                        $this->newMail->cc($address);
                    }
                }

                $bcc_addresses = explode(',', $cliente->emailbcc ?? '');
                foreach ($bcc_addresses as $address) {
                    if (false === empty($address) && Validator::email($address)) {
                        $this->newMail->bcc($address);
                    }
                }
            }
        };
    }
}