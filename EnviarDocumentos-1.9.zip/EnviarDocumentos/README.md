# EnviarDocumentos
Plugin que añade un botón email en el listado de facturas de venta. Al pulsarlo muestra un asistente para poder enviar
masivamente por email todas las facturas que todavía no se han enviado.
- https://facturascripts.com/plugins/enviardocumentos

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **EnviarDocumentos**.