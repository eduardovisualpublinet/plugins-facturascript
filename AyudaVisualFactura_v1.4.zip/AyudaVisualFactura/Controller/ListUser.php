<?php

namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Controller\ListUser as ParentController;

use FacturaScripts\Core\DataSrc\Almacenes;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\DataSrc\Users;
Use FacturaScripts\Core\Tools;

class ListUser extends ParentController
{
    protected function createViewsUsers(string $viewName = 'ListUser'): void
    {
        $this->addView($viewName, 'User', 'users', 'fas fa-users')
            ->addSearchFields(['nick', 'email'])
            ->addOrderBy(['nick'], 'nick', 1)
            ->addOrderBy(['email'], 'email');

        if ($this->user->admin) {
            $this->addOrderBy($viewName, ['level'], 'level');
        }

        $this->addOrderBy($viewName, ['creationdate'], 'creation-date');
        $this->addOrderBy($viewName, ['lastactivity'], 'last-activity');

        // filters
        if ($this->user->admin) {
            $levels = $this->codeModel->all('users', 'level', 'level');
            $this->addFilterSelect($viewName, 'level', 'level', 'level', $levels);
        }

        $languages = $this->codeModel->all('users', 'langcode', 'langcode');
        $this->addFilterSelect($viewName, 'langcode', 'language', 'langcode', $languages);

        $companies = Empresas::codeModel();
        if (count($companies) > 2) {
            $this->addFilterSelect($viewName, 'idempresa', 'company', 'idempresa', $companies);
        }

        $warehouses = Almacenes::codeModel();
        if (count($warehouses) > 2) {
            $this->addFilterSelect($viewName, 'codalmacen', 'warehouse', 'codalmacen', $warehouses);
        }

        // disable print button
        $this->setSettings($viewName, 'btnPrint', false);

        // disable new button
        $this->setSettings($viewName, 'btnNew', $this->setLimitUsers());
     
    }

    private function setLimitUsers(){
        $users = Users::codeModel();
        $userLimit = Tools::settings('planConfigurator', 'userLimit');

        if (count($users) > $userLimit)  return false;
        else return true;
    }
}

?>