<?php

namespace FacturaScripts\Plugins\PreciosMasivos\Extension\Controller;

use Closure;
use FacturaScripts\Core\Model\Producto;
use FacturaScripts\Dinamic\Lib\AssetManager;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;

/**
 * Summary of ListProducto
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2025
 */
class ListProducto
{
   public function createViews(): Closure
   {
      return function () {
         AssetManager::add('js', FS_ROUTE . '/Plugins/PreciosMasivos/Assets/JS/preciosMasivosMain.js');
      };
   }

   public function validarCampoPresente()
   {
      return function ($campo) {
         if (!isset($campo) || empty($campo) || null === $campo) {
            return false;
         }
         return true;
      };
   }

   public function execPreviousAction(): Closure
   {
      return function ($action) {
         if ($action !== 'modMasiva') {
            return;
         }

         $data = $this->request()->all();

         if (!array_key_exists('confirm', $data)) {
            Tools::log()->error('you-must-confirm-the-operation');
            return;
         }

         // Campo y tipo de actualización
         $valor = $data['value'] ?? $data['codimpuesto'] ?? '';

         if (empty($valor)) {
            Tools::log()->error('you-must-select-the-type-and-method');
            return;
         }

         $tipoMapping = [
            'cost' => 'coste',
            'cost-percentage' => 'coste',
            'margin' => 'margen',
            'margin-percentage' => 'margen',
            'precio' => 'precio',
            'precio-fixed' => 'precio',
            'precio-add' => 'precio',
            'codimpuesto' => 'codimpuesto',
         ];

         $campo = $tipoMapping[$data['ModMasivaTipo']] ?? null;

         if (!$campo) {
            Tools::log()->error('you-must-select-the-type-and-method');
            return;
         }

         $porcentaje = in_array($data['ModMasivaTipo'], ['cost-percentage', 'margin-percentage', 'precio']);
         $sumar = $data['ModMasivaTipo'] === 'precio-add';

         if (!$porcentaje && $valor < 0) {
            Tools::log()->warning('negative-values-only-for-percentages');
            return;
         }

         // Construcción de filtros
         $filterMapping = [
            'modMasivaquery' => ['referencia|descripcion|observaciones', 'XLIKE'],
            'modMasivafiltercodfabricante' => ['codfabricante', '='],
            'modMasivafiltercodfamilia' => ['codfamilia', '='],
            'modMasivafilterexcepcioniva' => ['excepcioniva', '='],
            'modMasivafiltertipo' => ['tipo', '='],
            'modMasivafiltercodimpuesto' => ['codimpuesto', '='],
            'modMasivafiltermin-price' => ['precio', '<='],
            'modMasivafiltermax-price' => ['precio', '>='],
            'modMasivafiltermin-stock' => ['stockfis', '<='],
            'modMasivafiltermax-stock' => ['stockfis', '>='],
            'modMasivafilternostock' => ['nostock', '='],
            'modMasivafilterventasinstock' => ['ventasinstock', '='],
            'modMasivafiltersecompra' => ['secompra', '='],
            'modMasivafiltersevende' => ['sevende', '='],
            'modMasivafilterpublico' => ['publico', '='],
         ];

         $where = array_filter(array_map(function ($key, $params) use ($data) {
            return $this->validarCampoPresente($data[$key] ?? null)
               ? new DataBaseWhere($params[0], $data[$key], $params[1])
               : null;
         }, array_keys($filterMapping), $filterMapping));

         if (isset($data['modMasivafilterstatus'])) {
            $statusMapping = [
               '0' => ['bloqueado', 0], // Solamente activos
               '1' => ['bloqueado', 1], // Bloqueados
               '2' => ['publico', 1],   // Públicos
            ];

            if (isset($statusMapping[$data['modMasivafilterstatus']])) {
               [$columna, $valorStatus] = $statusMapping[$data['modMasivafilterstatus']];
               $where[] = new DataBaseWhere($columna, $valorStatus);
            }
         }

         $productos = (new Producto())->all(array_filter($where), [], 0, 0);
         $cantUpdated = 0;

         foreach ($productos as $prd) {
            $producto = new Producto();
            $producto->load($prd->idproducto);

            if ($campo === 'codimpuesto') {
               $producto->{$campo} = $valor;
               $producto->save();
               $cantUpdated++;
               continue;
            }
            foreach ($producto->getVariants() as $variante) {
               if (!$variante) {
                  continue;
               }

               $variante = $this->actualizarVariante($variante, $campo, $valor, $porcentaje, $sumar);
               $variante->save();
               $cantUpdated++;
            }
         }
         Tools::log()->info('updated-successfully', ['%cantUpdated%' => $cantUpdated]);
      };
   }

   public function actualizarVariante()
   {
      return function ($variante, $campo, $valor, $porcentaje, $sumar) {
         if ($campo === 'precio') {
            $variante->margen = 0;
         }

         if ($porcentaje) {
            $aux1 = $variante->{$campo};
            $aux = ($valor * $aux1) / 100;
            $variante->{$campo} = ceil(($aux1 + $aux) * 100) / 100;
         } elseif ($sumar) {
            $variante->{$campo} = (($variante->{$campo} + $valor) * 100) / 100;
         } else {
            $variante->{$campo} = $valor;
         }

         if ($campo === 'precio' && $variante->coste > 0) {
            // Cálculo del margen
            $variante->margen = $porcentaje
               ? ceil((($variante->{$campo} - $variante->coste) / $variante->coste) * 100)
               : (($variante->{$campo} - $variante->coste) / $variante->coste) * 100;
         }

         return $variante;
      };
   }

   public function loadData(): Closure
   {
      return function ($viewName, $view) {

         if ($viewName === 'ListProducto') {
            $this->addButton($viewName, [
               'action' => 'modMasiva',
               'color' => 'warning',
               'icon' => 'fa-solid fa-calculator',
               'label' => 'prices',
               'type' => 'modal'
            ]);
            $this->views[$viewName]->model->AplicarA = $view->count;
         }
      };
   }
}
