<?php
namespace FacturaScripts\Plugins\PreciosMasivos;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Tools;

class Cron extends CronClass
{
    public function run(): void
    {
    }
}

