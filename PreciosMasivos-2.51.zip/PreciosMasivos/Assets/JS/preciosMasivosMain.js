$(document).ready(function () {
  // Inicializar inputs y columnas ocultas
  const $valueInput = $('input[name="value"]');
  const $taxesInput = $("#taxes");
  const $colValue = $("#ColValue");
  const $colTax = $("#ColTax");

  $valueInput.prop("disabled", true);
  $taxesInput.prop("disabled", true);
  $colValue.hide();
  $colTax.hide();

  // Manejo del modal al mostrarse
  $("#modalmodMasiva").on("shown.bs.modal", function () {
    $("#ModMasivaTipo").focus();

    const filters = [
      "filterstatus",
      "filtercodfabricante",
      "filtercodfamilia",
      "filtercodimpuesto",
      "filterexcepcioniva",
      "filtermin-price",
      "filtermax-price",
      "filtermin-stock",
      "filtermax-stock",
      "filtertipo",
      "query",
    ];

    // Copiar valores seleccionados en los filtros
    filters.forEach((filter) => {
      const selector = `input[name="modMasiva${filter}"]`;
      const value = $(
        `input[name="${filter}"], select[name="${filter}"]`
      ).val();
      $(selector).val(value);
    });

    // Manejar checkboxes de filtros
    const checkboxes = [
      "filternostock",
      "filterventasinstock",
      "filtersecompra",
      "filtersevende",
      "filterpublico",
    ];

    checkboxes.forEach((checkbox) => {
      $(`input[name="modMasiva${checkbox}"]`).val(
        $(`input[name="${checkbox}"]`).prop("checked") ? 1 : ""
      );
    });
  });

  // Manejo del cambio en el tipo de modificación
  $("#ModMasivaTipo").on("change", function () {
    const valueModes = [
      "cost",
      "cost-percentage",
      "margin",
      "margin-percentage",
      "precio-fixed",
      "precio-add",
      "precio",
    ];

    if (valueModes.includes(this.value)) {
      $valueInput.prop("disabled", false);
      $taxesInput.prop("disabled", true);
      $colValue.show();
      $colTax.hide();
    } else if (this.value === "codimpuesto") {
      $valueInput.prop("disabled", true);
      $taxesInput.prop("disabled", false);
      $colValue.hide();
      $colTax.show();
    } else {
      $valueInput.prop("disabled", true);
      $taxesInput.prop("disabled", true);
      $colValue.hide();
      $colTax.hide();
    }
  });
});
