<?php
namespace FacturaScripts\Plugins\PreciosMasivos;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;

/**
 * Summary of Init
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2025
 */
class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Controller\ListProducto());
    }

    public function update(): void
    {
    }


    public function uninstall(): void
    {
    }
}