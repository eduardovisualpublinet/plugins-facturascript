# StockAvanzado
Plugin que añade movimientos de stock, inventarios y transferencias entre almacenes a FacturaScripts.
- https://facturascripts.com/plugins/stockavanzado

## Soporte
https://facturascripts.com/contacto

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **StockAvanzado**.

## Enlaces de interés
- [Curso de FacturaScripts en YouTube](https://www.youtube.com/watch?v=rGopZA3ErzE&list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY).
- [Portal de ayuda de FacturaScripts](https://facturascripts.com/ayuda)
- [Gestión de almacenes](https://facturascripts.com/publicaciones/almacenes-128).
- [Ver los movimientos de stock de productos](https://facturascripts.com/publicaciones/como-ver-los-movimientos-de-stock-de-un-producto).
- [Hacer transferencias de stock entre almacenes](https://facturascripts.com/publicaciones/como-hacer-una-transferencia-de-stock-entre-almacenes).
- [Hacer inventario del almacén](https://facturascripts.com/publicaciones/como-hacer-inventario-del-almacen).