# CSVimport
Permite importar clientes, proveedores, productos, etc... desde archivos CSV.
- https://facturascripts.com/plugins/csvimport

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE LA DISTRIBUCIÓN NI PUBLICACIÓN.

## Carpeta
El nombre de la carpeta debe ser el mismo que el del plugin. En este caso, **CSVimport**.
