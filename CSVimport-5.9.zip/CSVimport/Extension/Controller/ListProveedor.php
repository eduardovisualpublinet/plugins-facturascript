<?php
/**
 * Copyright (C) 2019-2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Extension\Controller;

use Closure;
use Exception;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\CSVfile;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernandez Giménez <hola@danielfg.es>
 */
class ListProveedor
{
    public function createViews(): Closure
    {
        return function () {
            // import button
            if ($this->permissions->allowImport) {
                $this->addButton('ListProveedor', [
                    'action' => 'upload-suppliers',
                    'icon' => 'fa-solid fa-file-import',
                    'label' => 'import-suppliers',
                    'type' => 'modal'
                ]);
            }
        };
    }

    public function execPreviousAction(): Closure
    {
        return function ($action) {
            switch ($action) {
                case 'import-suppliers':
                    $this->importSuppliersAction();
                    break;

                case 'upload-suppliers':
                    $this->uploadSuppliersAction();
                    break;
            }
        };
    }

    public function importSuppliersAction(): Closure
    {
        return function () {
            // obtenemos la ruta completa del archivo
            $fileName = $this->request->get('import-filename');
            $filePath = CsvFileTools::getFilePath($fileName);
            if (empty($filePath)) {
                return true;
            }

            // se ha elegido crea nueva plantilla
            $template = $this->request->get('import-template', CsvFileTools::NEW_TEMPLATE);
            if ($template === CsvFileTools::NEW_TEMPLATE) {
                $newCsvFile = CSVfile::newTemplate($fileName, 'suppliers');
                $newCsvFile->mode = $this->request->get('import-mode');
                if ($newCsvFile->save()) {
                    $this->redirect($newCsvFile->url());
                }
                return true;
            }

            // se ha elegido plantilla automática
            if ($template === CsvFileTools::AUTOMATIC && $this->importSuppliersAutoAction($filePath)) {
                return true;
            }

            // seleccionamos la plantilla
            $templateModel = $template === CsvFileTools::AUTOMATIC ?
                CsvFileTools::getFileTemplate($filePath) :
                CsvFileTools::getFileTemplate($filePath, $template, 'suppliers');
            if (is_null($templateModel)) {
                Tools::log()->warning('template-not-found');

                // creamos una nueva plantilla
                $newCsvFile = CSVfile::newTemplate($fileName, 'suppliers');
                $newCsvFile->mode = $this->request->get('import-mode');
                if ($newCsvFile->save()) {
                    $this->redirect($newCsvFile->url(), 1);
                }
                return true;
            }

            // procesamos el archivo
            $mode = $this->request->get('import-mode');
            $offset = (int)$this->request->get('import-offset', 0);
            $saveLines = (int)$this->request->get('save-lines', 0);
            $result = $templateModel->getProfile($offset, $saveLines, $filePath, $mode)->import();
            if ($result['offset'] > 0 && $result['offset'] < $result['total']) {
                Tools::log()->notice(
                    'items-save-correctly-to-total',
                    ['%lines%' => $result['offset'], '%total%' => $result['total'], '%save%' => $result['save']]
                );
                Tools::log()->notice('importing');
                $this->redirect($this->url() . '?action=import-suppliers&import-filename=' . urlencode($fileName)
                    . '&import-offset=' . $result['offset'] . '&save-lines=' . $result['save']
                    . '&import-template=' . $templateModel->id . '&import-mode=' . $mode, 1);
                return true;
            }

            unlink($filePath);
            Tools::log()->notice('items-added-correctly', ['%num%' => $result['save']]);
            return true;
        };
    }

    public function importSuppliersAutoAction(): Closure
    {
        return function (string $filePath) {
            // buscamos una plantilla automática
            $autoTemplates = CSVfile::autoTemplate($filePath, 'suppliers');
            if ($autoTemplates === null) {
                return false;
            }

            // procesamos el archivo
            $mode = $this->request->get('import-mode');
            $offset = (int)$this->request->get('import-offset', 0);
            $saveLines = (int)$this->request->get('save-lines', 0);
            if (false === $autoTemplates->run($filePath, 'suppliers', $mode, $offset, $saveLines)) {
                return true;
            }

            if ($autoTemplates->continue()) {
                Tools::log()->notice(
                    'items-save-correctly-to-total',
                    ['%lines%' => $offset, '%total%' => $autoTemplates->getTotalLines(), '%save%' => $saveLines]
                );
                Tools::log()->notice('importing');
                $fileName = $this->request->get('import-filename');
                $this->redirect($this->url() . '?action=import-suppliers&import-filename=' . urlencode($fileName)
                    . '&import-offset=' . $offset . '&save-lines=' . $saveLines
                    . '&import-template=' . CsvFileTools::AUTOMATIC . '&import-mode=' . $mode, 1);
                return true;
            }

            unlink($filePath);
            Tools::log()->notice('items-added-correctly', ['%num%' => $saveLines]);
            return true;
        };
    }

    public function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName !== 'ListProveedor') {
                return;
            }

            // rellenamos el select de plantillas del modal
            $column = $this->views[$viewName]->columnModalForName('template');
            if ($column && $column->widget->getType() === 'select') {
                // añadimos las opciones automatic y new
                $customValues = [
                    ['value' => 'automatic', 'title' => Tools::lang()->trans('automatic-template')],
                    ['value' => 'new-template', 'title' => Tools::lang()->trans('new-template')]
                ];

                // añadimos la lista de plantillas compatibles
                $where = [
                    Where::column('template', null, 'IS NOT'),
                    Where::column('options', null, 'IS NOT'),
                    Where::column('profile', 'suppliers')
                ];
                $templates = CSVfile::all($where, ['template' => 'ASC']);
                if ($templates) {
                    $customValues[] = ['value' => '', 'title' => '------'];
                }
                foreach ($templates as $csv) {
                    $customValues[] = ['value' => $csv->id, 'title' => $csv->template];
                }

                // asignamos el valor predeterminado
                $view->model->template = CsvFileTools::AUTOMATIC;

                // cargamos la lista de valores
                $column->widget->setValuesFromArray($customValues);
            }
        };
    }

    public function uploadSuppliersAction(): Closure
    {
        return function () {
            // comprobamos los permisos de importación
            if (false === $this->permissions->allowImport) {
                Tools::log()->warning('no-import-permission');
                return true;
            }

            // comprobamos el token
            if (false === $this->validateFormToken()) {
                return true;
            }

            // comprobamos el tamaño y tipo del archivo
            $uploadFile = $this->request->files->get('suppliersfile');
            if (CsvFileTools::isBigFile($uploadFile) || false === CsvFileTools::isValidFile($uploadFile->getRealPath())) {
                return true;
            }

            try {
                // movemos el archivo
                $path = CsvFileTools::saveUploadFile($uploadFile);

                // convertimos el archivo a CSV, si es necesario
                $filePath = CsvFileTools::convertFileToCsv($path);
            } catch (Exception $exc) {
                Tools::log()->warning('upload-file-error');
                Tools::log()->warning($uploadFile->getClientOriginalName());
                Tools::log()->warning($exc->getMessage());
                return true;
            }

            // recargamos la página para llamar a la acción de importación
            $fileName = basename($filePath);
            $template = $this->request->request->get('template', CsvFileTools::AUTOMATIC);
            $mode = $this->request->request->get('mode', CsvFileTools::AUTOMATIC);
            $this->redirect($this->url() . '?action=import-suppliers&import-filename=' . urlencode($fileName)
                . '&import-template=' . $template . '&import-mode=' . $mode);
            return true;
        };
    }
}
