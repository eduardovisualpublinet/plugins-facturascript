<?php
/**
 * Copyright (C) 2020-2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\ManualTemplates;

use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Familia;
use FacturaScripts\Plugins\CSVimport\Contract\ManualTemplateInterface;

/**
 * Description of Families
 *
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernandez Giménez <hola@danielfg.es>
 */
class Families extends ManualTemplateClass implements ManualTemplateInterface
{

    private static array $listFamilies = [];

    public function getDataFields(): array
    {
        return [
            'codfamilia' => ['title' => 'code'],
            'descripcion' => ['title' => 'description'],
            'madre' => ['title' => 'parent']
        ];
    }

    public function getFieldsToColumn(): array
    {
        return [];
    }

    public static function getProfile(): string
    {
        return 'families';
    }

    public function getRequiredFieldsAnd(): array
    {
        return ['codfamilia'];
    }

    public function getRequiredFieldsOr(): array
    {
        return [];
    }

    public function importItem(array $item): bool
    {
        if (!isset($item['codfamilia']) || empty($item['codfamilia'])) {
            Tools::log()->warning('field-required', ['%field%' => 'codfamilia']);
            return false;
        }

        $family = new Familia();
        if (self::checkFamilia($item['codfamilia']) && $this->model->mode === CsvFileTools::INSERT_MODE
            || false === self::checkFamilia($item['codfamilia']) && $this->model->mode === CsvFileTools::UPDATE_MODE) {
            return false;
        }

        if (!empty($item['madre'])) {
            if (false === self::checkFamilia($item['madre'])) {
                Tools::log()->warning('family-parent-not-exists', ['%parent%' => $item['madre']]);
                return false;
            }

            $family->madre = $item['madre'];
        }

        // Excluir 'madre' del setModelValues ya que se maneja manualmente
        $itemWithoutMadre = $item;
        unset($itemWithoutMadre['madre']);

        $this->setModelValues($family, $itemWithoutMadre, '');
        self::$listFamilies[] = $family;
        return $family->save();
    }

    private function checkFamilia(string $id): bool
    {
        if (empty(self::$listFamilies)){
            self::$listFamilies = Familia::all();
        }

        if (empty($id)){
            return false;
        }

        foreach (self::$listFamilies as $family) {
            if ($family->codfamilia == $id) {
                return true;
            }
        }

        return false;
    }
}
