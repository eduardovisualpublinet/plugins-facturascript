<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\DataSrc\Almacenes;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\BusinessDocumentCode;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ClinicCustomerInvoices implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 10;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'customer-invoices') {
            return false;
        }

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start);

            if (count($csv['titles']) < 2) {
                continue;
            }

            if ($csv['titles'][0] === 'Nº de Factura' &&
                $csv['titles'][1] === 'Nº de Fact. Simplificada' &&
                $csv['titles'][2] === 'Fecha de Factura' &&
                $csv['titles'][5] === 'Código de Cliente' &&
                $csv['titles'][9] === 'Base Imponible (0%)' &&
                $csv['titles'][13] === 'IVA (0%)' &&
                $csv['titles'][22] === 'Total') {
                $invoices = $this->readInvoices($csv['data']);
                $this->total_lines = count($invoices);
                return true;
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start);
        $invoices = $this->readInvoices($csv['data']);
        $this->total_lines = count($invoices);
        $this->continue = false;

        // recorremos las facturas empezando por el offset y terminando por el limit
        for ($i = $offset; $i < min($this->total_lines, $offset + static::LIMIT_IMPORT); $i++) {
            $row = $invoices[$i]['invoice'];

            $this->continue = true;

            // obtenemos el ejercicio para la fecha de la factura
            $exercise = new Ejercicio();
            $exercise->idempresa = static::getIdEmpresa($row['Nº de Factura']);
            $exercise->loadFromDate(CsvFileTools::formatDate($row['Fecha de Factura']));
            if (empty($exercise->id())) {
                Tools::log()->warning('exercise-not-found', ['%date%' => $row['Fecha de Factura']]);
                continue;
            }

            // buscamos si ya existe la factura
            $oldInvoice = new FacturaCliente();
            $where = [
                Where::eq('codigo', $row['Nº de Factura']),
                Where::eq('codejercicio', $exercise->codejercicio)
            ];
            if ($oldInvoice->loadWhere($where)) {
                continue;
            }

            // creamos la factura
            $newInvoice = new FacturaCliente();
            $newInvoice->setSubject(static::getCustomer($row));
            $newInvoice->idempresa = $exercise->idempresa;
            $newInvoice->codejercicio = $exercise->codejercicio;
            $newInvoice->codalmacen = static::getCodAlmacen($exercise->idempresa);
            $newInvoice->fecha = CsvFileTools::formatDate($row['Fecha de Factura']);
            $newInvoice->hora = date('H:i:s');
            $newInvoice->codigo = $row['Nº de Factura'];
            BusinessDocumentCode::setNewNumber($newInvoice);
            $newInvoice->codpago = static::getCodpago($row, $newInvoice->codpago);
            if (false === $newInvoice->save()) {
                break;
            }

            $saveLines++;

            // añadimos las líneas
            $tax_types = [
                'Base Imponible (0%)' => 0,
                'Base Imponible (4%)' => 4,
                'Base Imponible (10%)' => 10,
                'Base Imponible (21%)' => 21,
            ];
            foreach ($tax_types as $tax_type => $tax_value) {
                if (floatval($row[$tax_type]) != 0) {
                    $newLine = $newInvoice->getNewLine();
                    $newLine->descripcion = $tax_type;
                    $newLine->cantidad = 1;
                    $newLine->pvpunitario = CsvFileTools::formatFloat($row[$tax_type]);
                    foreach (Impuestos::all() as $imp) {
                        if ($imp->iva == $tax_value) {
                            $newLine->codimpuesto = $imp->codimpuesto;
                            $newLine->iva = $imp->iva;
                            $newLine->recargo = 0;
                            break;
                        }
                    }
                    if (false === $newLine->save()) {
                        break 2;
                    }
                }
            }

            // actualizamos los totales
            $lines = $newInvoice->getLines();
            Calculator::calculate($newInvoice, $lines, true);
            if (abs($newInvoice->total - CsvFileTools::formatFloat($row['Total'])) > 0.02) {
                Tools::log()->warning('total-value-error', [
                    '%docType%' => $newInvoice->modelClassName(),
                    '%docCode%' => $newInvoice->codigo,
                    '%docTotal%' => $newInvoice->total,
                    '%calcTotal%' => CsvFileTools::formatFloat($row['Total'])
                ]);
            }

            // guardamos los recibos de cada forma de pago
            self::saveReceipts($newInvoice, $row);
        }

        $offset += static::LIMIT_IMPORT;

        return true;
    }

    protected static function getCodpago(array $line, ?string $default): ?string
    {
        if (floatval($line['Efectivo']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'efectivo') {
                    return $forma->codpago;
                }
            }
        }

        if (floatval($line['Tarjeta']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'tarjeta') {
                    return $forma->codpago;
                }
            }
        }

        if (floatval($line['Transferencia']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'transferen') {
                    return $forma->codpago;
                }
            }
        }

        return $default;
    }

    protected static function getCustomer(array $line): Cliente
    {
        $customer = new Cliente();
        if ($customer->load($line['Código de Cliente'])) {
            return $customer;
        }

        // buscamos por DNI
        if ($customer->loadWhereEq('cifnif', $line['DNI'])) {
            return $customer;
        }

        // no existe el cliente, lo creamos
        $customer->codcliente = $line['Código de Cliente'];
        $customer->nombre = $line['Nombre de Cliente'];
        $customer->cifnif = $line['DNI'];

        // si el DNI empieza por una letra, es un CIF (persona jurídica)
        if (!empty($line['DNI']) && preg_match('/^[A-Z]/i', $line['DNI'])) {
            $customer->tipoidfiscal = 'cif';
            $customer->personafisica = false;
        }

        $customer->save();

        return $customer;
    }

    protected function readInvoices(array $data): array
    {
        // Inicializar el array para almacenar las facturas
        $invoices = [];

        foreach ($data as $row) {
            if (empty($row['Fecha de Factura'] ?? '')) {
                continue; // saltamos filas sin fecha de factura
            }

            $invoices[] = ['date' => $row['Fecha de Factura'], 'invoice' => $row];
        }

        // ordenamos por fecha, de menor a mayor
        usort($invoices, function ($a, $b) {
            $date_a = CsvFileTools::formatDate($a['date']);
            $date_b = CsvFileTools::formatDate($b['date']);
            return strtotime($date_a) <=> strtotime($date_b);
        });

        return $invoices;
    }

    protected static function saveReceipts(FacturaCliente &$invoice, array $row): void
    {
        // eliminamos los recibos anteriores
        foreach ($invoice->getReceipts() as $receipt) {
            $receipt->delete();
        }

        $numero = 1;

        $efectivo = floatval($row['Efectivo'] ?? 0);
        if ($efectivo != 0) {
            $newReceipt = new ReciboCliente();
            $newReceipt->codcliente = $invoice->codcliente;
            $newReceipt->coddivisa = $invoice->coddivisa;
            $newReceipt->idempresa = $invoice->idempresa;
            $newReceipt->idfactura = $invoice->idfactura;
            $newReceipt->importe = $efectivo;
            $newReceipt->numero = $numero;
            $newReceipt->fecha = $invoice->fecha;
            $newReceipt->fechapago = $invoice->fecha;
            $newReceipt->pagado = true;

            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'efectivo') {
                    $newReceipt->codpago = $forma->codpago;
                    break;
                }
            }

            if ($newReceipt->save()) {
                $numero++;
            }
        }

        $tarjeta = floatval($row['Tarjeta'] ?? 0);
        if ($tarjeta != 0) {
            $newReceipt = new ReciboCliente();
            $newReceipt->codcliente = $invoice->codcliente;
            $newReceipt->coddivisa = $invoice->coddivisa;
            $newReceipt->idempresa = $invoice->idempresa;
            $newReceipt->idfactura = $invoice->idfactura;
            $newReceipt->importe = $tarjeta;
            $newReceipt->numero = $numero;
            $newReceipt->fecha = $invoice->fecha;
            $newReceipt->fechapago = $invoice->fecha;
            $newReceipt->pagado = true;

            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'tarjeta') {
                    $newReceipt->codpago = $forma->codpago;
                    break;
                }
            }

            if ($newReceipt->save()) {
                $numero++;
            }
        }

        $transferencia = floatval($row['Transferencia'] ?? 0);
        if ($transferencia != 0) {
            $newReceipt = new ReciboCliente();
            $newReceipt->codcliente = $invoice->codcliente;
            $newReceipt->coddivisa = $invoice->coddivisa;
            $newReceipt->idempresa = $invoice->idempresa;
            $newReceipt->idfactura = $invoice->idfactura;
            $newReceipt->importe = $transferencia;
            $newReceipt->numero = $numero;
            $newReceipt->fecha = $invoice->fecha;
            $newReceipt->fechapago = $invoice->fecha;
            $newReceipt->pagado = true;

            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'transferen') {
                    $newReceipt->codpago = $forma->codpago;
                    break;
                }
            }

            if ($newReceipt->save()) {
                $numero++;
            }
        }

        foreach (['Saldo', 'Frakmenta', 'Otros'] as $field) {
            $importe = floatval($row[$field] ?? 0);
            if ($importe != 0) {
                $newReceipt = new ReciboCliente();
                $newReceipt->codcliente = $invoice->codcliente;
                $newReceipt->coddivisa = $invoice->coddivisa;
                $newReceipt->idempresa = $invoice->idempresa;
                $newReceipt->idfactura = $invoice->idfactura;
                $newReceipt->importe = $importe;
                $newReceipt->numero = $numero;
                $newReceipt->fecha = $invoice->fecha;
                $newReceipt->fechapago = $invoice->fecha;
                $newReceipt->pagado = true;

                // buscamos la forma de pago por código o descripción
                foreach (FormasPago::all() as $forma) {
                    if (strtolower($forma->codpago) === strtolower($field) ||
                        strtolower($forma->descripcion) === strtolower($field)) {
                        $newReceipt->codpago = $forma->codpago;
                        break;
                    }
                }

                if ($newReceipt->save()) {
                    $numero++;
                }
            }
        }

        // ahora hay que añadir lo que quede pendiente de pagar como un recibo no pagado
        $pending_amount = $invoice->total;
        foreach ($invoice->getReceipts() as $receipt) {
            $pending_amount -= $receipt->importe;
        }
        if (abs($pending_amount) > 0.02) {
            $newReceipt = new ReciboCliente();
            $newReceipt->codcliente = $invoice->codcliente;
            $newReceipt->coddivisa = $invoice->coddivisa;
            $newReceipt->idempresa = $invoice->idempresa;
            $newReceipt->idfactura = $invoice->idfactura;
            $newReceipt->importe = $pending_amount;
            $newReceipt->numero = $numero;
            $newReceipt->fecha = $invoice->fecha;
            $newReceipt->fechapago = null;
            $newReceipt->pagado = false;

            // usamos la forma de pago de la factura
            $newReceipt->codpago = $invoice->codpago;

            $newReceipt->save();
        } elseif (abs($pending_amount) > 0.00) {
            // si es cosa de 1 céntimo, lo añadimos como pagado
            $newReceipt = new ReciboCliente();
            $newReceipt->codcliente = $invoice->codcliente;
            $newReceipt->coddivisa = $invoice->coddivisa;
            $newReceipt->idempresa = $invoice->idempresa;
            $newReceipt->idfactura = $invoice->idfactura;
            $newReceipt->importe = $pending_amount;
            $newReceipt->numero = $numero;
            $newReceipt->fecha = $invoice->fecha;
            $newReceipt->fechapago = $invoice->fecha;
            $newReceipt->pagado = true;

            // usamos la forma de pago de la factura
            $newReceipt->codpago = $invoice->codpago;

            $newReceipt->save();
        }
    }

    protected static function getCodAlmacen(int $idempresa): ?string
    {
        // obtenemos el primer almacén de la empresa
        foreach (Almacenes::all() as $almacen) {
            if ($almacen->idempresa == $idempresa) {
                return $almacen->codalmacen;
            }
        }

        return null;
    }

    protected static function getIdEmpresa(string $invoiceNumber): int
    {
        $empresas = Empresas::all();

        // si solo hay una empresa, la devolvemos
        if (count($empresas) === 1) {
            return $empresas[0]->idempresa;
        }

        // si hay más de una empresa, buscamos por la primera letra del número de factura
        $firstLetter = strtoupper(substr($invoiceNumber, 0, 1));
        foreach ($empresas as $empresa) {
            if (strtoupper(substr($empresa->nombre, 0, 1)) === $firstLetter) {
                return $empresa->idempresa;
            }
        }

        // si no encontramos ninguna, devolvemos la empresa por defecto
        return Tools::settings('default', 'idempresa');
    }
}
