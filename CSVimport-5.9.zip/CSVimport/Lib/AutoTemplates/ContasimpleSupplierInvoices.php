<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Dinamic\Model\Proveedor;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ContasimpleSupplierInvoices implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 10;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'supplier-invoices') {
            return false;
        }

        $expectedColumns = [
            'NÚM. REG.',
            'TIPO LINEA',
            'NÚMERO',
            'FECHA',
            'FECHA VENCIMIENTO',
            'ESTADO',
            'INICIO SERVICIO',
            'FIN SERVICIO',
            'CONCEPTO LINEA',
            'B.I. UNITARIA LINEA',
            'CANTIDAD LINEA',
            '% DESCUENTO LINEA',
            'B.I. TOTAL LINEA',
            'TIPO IVA',
            'TOTAL IVA LINEA',
            'DESCRIPCION DETALLADA LINEA',
            'BASE IMPONIBLE',
            'RET. %',
            'TOTAL RET.',
            'TOTAL FACTURA',
            '% IMPUTACIÓN',
            '% IMPUTACION A IVA',
            'Número DUA/H7 (solo para facturas de importación)',
            'TIPO GASTO',
            'DESC. TIPO GASTO',
            'TIPO OPERACIÓN',
            'NOMBRE O RAZÓN SOCIAL',
            'NIF',
            'DIRECCIÓN',
            'CÓDIGO POSTAL',
            'POBLACIÓN',
            'PROVINCIA',
            'PAÍS',
            'TELÉFONO',
            'CRITERIO DE CAJA',
            'NOMBRE O RAZÓN SOCIAL_1',
            'NIF_1',
            'DIRECCIÓN_1',
            'CÓDIGO POSTAL_1',
            'POBLACIÓN_1',
            'PROVINCIA_1',
            'PAÍS_1',
            'TELÉFONO_1',
            'NOTAS PRIVADAS',
            'FECHA PAGO',
            'IMPORTE',
            'MÉTODO DE PAGO',
            'TIPO DE MÉTODO DE PAGO',
            'NÚMERO CUENTA/TARJETA'
        ];

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start, 0, 1);
            $this->total_lines = CsvFileTools::getTotalLines();

            if (isset($csv['titles'])) {
                $headers = array_map('trim', $csv['titles']);
                // Comprobar que todas las columnas esperadas están presentes
                if (empty(array_diff($expectedColumns, $headers))) {
                    return true;
                }
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start);
        $invoices = $this->readInvoices($csv['data']);
        $this->total_lines = count($invoices);
        $this->continue = false;

        for ($i = $offset; $i < min($this->total_lines, $offset + static::LIMIT_IMPORT); $i++) {
            $row = $invoices[$i]['invoice'];

            $this->continue = true;

            // obtenemos el ejercicio para la fecha de la factura
            $exercise = new Ejercicio();
            $exercise->idempresa = Tools::settings('default', 'idempresa');
            $exercise->loadFromDate(CsvFileTools::formatDate($row['FECHA']));
            if (empty($exercise->id())) {
                Tools::log()->warning('exercise-not-found', ['%date%' => $row['FECHA']]);
                continue;
            }

            // buscamos la factura
            $invoice = new FacturaProveedor();
            $where = [
                Where::eq('codigo', $row['NÚMERO']),
                Where::eq('codejercicio', $exercise->codejercicio),
            ];
            if ($invoice->loadWhere($where)) {
                continue;
            }

            // guardamos la factura
            $invoice->setSubject(static::getSupplier($row));
            $invoice->setDate(CsvFileTools::formatDate($row['FECHA']), date('H:i:s'));
            $invoice->idempresa = $exercise->idempresa;
            $invoice->codejercicio = $exercise->codejercicio;
            $invoice->fecha = CsvFileTools::formatDate($row['FECHA']);
            $invoice->hora = date('H:i:s');
            $invoice->numproveedor = $row['NÚMERO'];
            $invoice->observaciones = $row['NOTAS PRIVADAS'];
            if (false === $invoice->save()) {
                return false;
            }

            $saveLines++;

            // añadimos las líneas
            foreach ($invoices[$i]['lines'] as $line) {
                $newLine = $invoice->getNewLine();
                $newLine->descripcion = $line['CONCEPTO LINEA'];
                $newLine->cantidad = (float)$line['CANTIDAD LINEA'];
                $newLine->pvpunitario = CsvFileTools::formatFloat($line['B.I. UNITARIA LINEA']);
                $newLine->dtopor = CsvFileTools::formatFloat($line['% DESCUENTO LINEA']);

                $iva = CsvFileTools::formatFloat($line['TIPO IVA']);
                foreach (Impuestos::all() as $impuesto) {
                    if (abs($impuesto->iva - $iva) < 0.01) {
                        $newLine->codimpuesto = $impuesto->codimpuesto;
                        $newLine->iva = $impuesto->iva;
                        $newLine->recargo = 0;
                        break;
                    }
                }

                $newLine->irpf = CsvFileTools::formatFloat($row['RET. %']);
                $newLine->save();
            }

            // actualizamos los totales
            $lines = $invoice->getLines();
            Calculator::calculate($invoice, $lines, true);
            if (abs($invoice->total - CsvFileTools::formatFloat($row['TOTAL FACTURA'])) > 0.02) {
                Tools::log()->warning('total-value-error', [
                    '%docType%' => $invoice->modelClassName(),
                    '%docCode%' => $invoice->codigo,
                    '%docTotal%' => $invoice->total,
                    '%calcTotal%' => CsvFileTools::formatFloat($row['TOTAL FACTURA'])
                ]);
            }

            // ¿La factura está pagada?
            if ($row['ESTADO'] === 'Pagado') {
                foreach ($invoice->getReceipts() as $receipt) {
                    $receipt->fechapago = CsvFileTools::formatDate($row['FECHA PAGO']);
                    $receipt->pagado = true;
                    $receipt->save();
                }
            }
        }

        $offset += static::LIMIT_IMPORT;

        return true;
    }

    protected static function getSupplier(array $line): Proveedor
    {
        // buscamos por NIF
        $supplier = new Proveedor();
        if ($supplier->loadWhereEq('cifnif', $line['NIF'])) {
            return $supplier;
        }

        // no existe, creamos uno nuevo
        $supplier->cifnif = $line['NIF'];
        $supplier->nombre = $line['NOMBRE O RAZÓN SOCIAL'];

        // si el DNI empieza por una letra, es un CIF (persona jurídica)
        if (!empty($line['NIF']) && preg_match('/^[A-Z]/i', $line['NIF'])) {
            $supplier->tipoidfiscal = 'cif';
            $supplier->personafisica = false;
        }

        $supplier->save();

        return $supplier;
    }

    protected function readInvoices(array $data): array
    {
        // Inicializar el array para almacenar las facturas
        $invoices = [];
        $currentInvoice = [];

        foreach ($data as $row) {
            // Comprobación para detectar el inicio de una nueva factura
            if ($row['TIPO LINEA'] == 'Cabecera') {
                if (!empty($currentInvoice)) {
                    // Si ya tenemos una factura acumulada, la añadimos a la lista de invoices
                    $invoices[] = $currentInvoice;
                }
                $currentInvoice = ['date' => $row['FECHA'], 'invoice' => $row, 'lines' => []];
            } elseif ($row['TIPO LINEA'] == 'Detalle') {
                // Si estamos en una línea de detalle, la añadimos a la factura actual
                $currentInvoice['lines'][] = $row;
            }
        }

        // Añadir la última factura leída, si existe
        if (!empty($currentInvoice)) {
            $invoices[] = $currentInvoice;
        }

        // ordenamos por fecha, de menor a mayor
        usort($invoices, function ($a, $b) {
            $date_a = CsvFileTools::formatDate($a['date']);
            $date_b = CsvFileTools::formatDate($b['date']);
            return strtotime($date_a) <=> strtotime($date_b);
        });

        return $invoices;
    }
}
