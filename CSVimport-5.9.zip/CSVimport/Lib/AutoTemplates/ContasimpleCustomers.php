<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\DataSrc\Paises;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ContasimpleCustomers implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 500;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'customers') {
            return false;
        }

        $expectedColumns = [
            'NIF',
            'NOMBRE O RAZÓN SOCIAL',
            'EMAIL',
            'TELF.',
            'MÓVIL',
            'FAX',
            'DIRECCIÓN',
            'COD. POSTAL',
            'POBLACIÓN',
            'PROVINCIA',
            'PAÍS',
            'URL',
            '% DESCUENTO POR DEFECTO',
            'LATITUD',
            'LONGITUD',
            'Personalizado1',
            'Personalizado2',
            'NOTAS PRIVADAS',
            'CUENTAS BANCARIAS'
        ];

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start, 0, 1);
            $this->total_lines = CsvFileTools::getTotalLines();

            if (isset($csv['titles']) && count($csv['titles']) === count($expectedColumns)) {
                $headers = array_map('trim', $csv['titles']);
                if ($headers === $expectedColumns) {
                    return true;
                }
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start, $offset, static::LIMIT_IMPORT);
        $this->total_lines = CsvFileTools::getTotalLines();
        $this->continue = false;

        foreach ($csv['data'] as $row) {
            // buscamos el cliente por NIF
            $customer = new Cliente();
            if ($customer->loadWhereEq('cifnif', $row['NIF'])) {
                continue;
            }

            // creamos el cliente nuevo
            $customer->cifnif = $row['NIF'];
            $customer->nombre = mb_substr(Tools::noHtml($row['NOMBRE O RAZÓN SOCIAL']), 0, 100);
            $customer->telefono1 = substr($row['TELF.'] ?? '', 0, 20);
            $customer->telefono2 = substr($row['MÓVIL'] ?? '', 0, 20);
            $customer->fax = substr($row['FAX'] ?? '', 0, 20);

            // si el DNI empieza por una letra, es un CIF (persona jurídica)
            if (!empty($row['NIF']) && preg_match('/^[A-Z]/i', $row['NIF'])) {
                $customer->tipoidfiscal = 'cif';
                $customer->personafisica = false;
            }

            if (!empty($row['EMAIL']) && filter_var(trim($row['EMAIL']), FILTER_VALIDATE_EMAIL)) {
                $customer->email = trim($row['EMAIL']);
            }

            if (empty($customer->nombre)) {
                $customer->nombre = 'Cliente ' . $customer->cifnif;
            }

            $customer->observaciones = $row['NOTAS PRIVADAS'] ?? '';

            if (false === $customer->save()) {
                continue;
            }

            $this->continue = true;
            $offset++;
            $saveLines++;

            foreach ($customer->getAddresses() as $address) {
                $address->direccion = mb_substr(Tools::noHtml($row['DIRECCIÓN']), 0, 100);
                $address->codpostal = substr($row['COD. POSTAL'], 0, 10);
                $address->ciudad = $row['POBLACIÓN'];
                $address->provincia = $row['PROVINCIA'];
                foreach (Paises::all() as $pais) {
                    if (strtolower($pais->nombre) === strtolower($row['PAÍS'] ?? '')) {
                        $address->codpais = $pais->codpais;
                        break;
                    }
                }
                $address->save();
                break;
            }
        }

        return true;
    }
}
