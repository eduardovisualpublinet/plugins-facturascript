<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Extension\Controller;

use Closure;
use FacturaScripts\Core\Where;

/**
 * Description of EditReciboCliente
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class EditReciboProveedor
{
    public function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName !== 'EditReciboProveedor') {
                return;
            }

            // set widget values
            $where = [Where::column('codproveedor', $view->model->codproveedor)];
            $ibanColumn = $this->views[$viewName]->columnForName('iban');
            if ($ibanColumn) {
                $ibanValues = $this->codeModel->all('cuentasbcopro', 'iban', 'iban', true, $where);
                $ibanColumn->widget->setValuesFromCodeModel($ibanValues);
            }
            $swiftColumn = $this->views[$viewName]->columnForName('swift');
            if ($swiftColumn) {
                $swiftValues = $this->codeModel->all('cuentasbcopro', 'swift', 'swift', true, $where);
                $swiftColumn->widget->setValuesFromCodeModel($swiftValues);
            }
        };
    }
}
