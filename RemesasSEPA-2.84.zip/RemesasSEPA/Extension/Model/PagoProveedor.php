<?php
/**
 * Copyright (C) 2019-2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Extension\Model;

use Closure;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class PagoProveedor
{
    public function saveBefore(): Closure
    {
        return function () {
            if ($this->getReceipt()->idremesa) {
                $this->disableAccountingGeneration(true);
            }
        };
    }
}
