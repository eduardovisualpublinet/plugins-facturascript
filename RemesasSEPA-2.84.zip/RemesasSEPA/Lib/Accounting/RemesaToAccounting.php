<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Lib\Accounting;

use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Asiento;
use FacturaScripts\Dinamic\Model\Cuenta;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\Subcuenta;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPA;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class RemesaToAccounting
{
    use ExtensionsTrait;

    public function generate(RemesaSEPA &$remesa): void
    {
        // si ya tiene asiento, no hacemos nada
        if ($remesa->idasiento) {
            Tools::log()->warning('accounting-entry-exists');
            return;
        }

        // creamos el asiento
        $asiento = new Asiento();
        $asiento->concepto = $remesa->primaryDescription();
        $asiento->fecha = $remesa->fechacargo;
        $asiento->idempresa = $remesa->idempresa;
        $asiento->importe = $remesa->total;
        if (false === $asiento->save()) {
            Tools::log()->warning('accounting-entry-error');
            return;
        }

        // añadimos las líneas de recibos
        foreach ($remesa->getReceipts() as $receipt) {
            if (false === $this->addReceiptLine($asiento, $receipt)) {
                Tools::log()->error('receipt-error-' . $receipt->codigofactura);
                $asiento->delete();
                return;
            }
        }

        // añadimos la línea de la remesa y comprobamos
        if (false === $this->addRemittanceLine($asiento, $remesa)) {
            Tools::log()->error('remittance-error-' . $remesa->idremesa);
            $asiento->delete();
            return;
        }

        // comprobamos si el asiento está descuadrado
        if (false === $asiento->isBalanced()) {
            Tools::log()->warning('mismatched-accounting-entry');
            $asiento->delete();
            return;
        }

        $remesa->idasiento = $asiento->id();
    }

    /**
     * @param Asiento $asiento
     * @param ReciboCliente $receipt
     *
     * @return bool
     */
    protected function addReceiptLine($asiento, $receipt): bool
    {
        $customer = $receipt->getSubject();
        $account = $customer->getSubcuenta($asiento->codejercicio, true);
        if (false === $account->exists()) {
            return false;
        }

        $newLine = $asiento->getNewLine();
        $newLine->setAccount($account);
        $newLine->concepto = Tools::trans('customer-payment-concept', ['%document%' => $receipt->getCode()]);
        $newLine->haber = $receipt->importe;
        if (false === $newLine->save()) {
            return false;
        }

        if (false === $this->pipeFalse('addReceiptLine', $asiento, $receipt)) {
            return false;
        }

        return true;
    }

    /**
     * @param Asiento $asiento
     * @param RemesaSEPA $remesa
     *
     * @return bool
     */
    protected function addRemittanceLine($asiento, $remesa): bool
    {
        $bankLine = $asiento->getNewLine();

        $bankSubaccount = new Subcuenta();
        $where = [
            Where::eq('codsubcuenta', $remesa->getBankAccount()->codsubcuenta),
            Where::eq('codejercicio', $asiento->codejercicio)
        ];
        if ($bankSubaccount->loadWhere($where)) {
            $bankLine->setAccount($bankSubaccount);
        } else {
            $altBankSubaccount = $this->getSpecialSubAccount('CAJA', $asiento);
            $bankLine->setAccount($altBankSubaccount);
        }

        $bankLine->debe = $remesa->total;

        if (false === $bankLine->save()) {
            return false;
        }

        if (false === $this->pipeFalse('addRemittanceLine', $asiento, $remesa)) {
            return false;
        }

        return true;
    }

    /**
     * @param string $specialAccount
     * @param Asiento $asiento
     *
     * @return Cuenta
     */
    public function getSpecialAccount(string $specialAccount, $asiento): Cuenta
    {
        $account = new Cuenta();
        $where = [
            Where::eq('codejercicio', $asiento->codejercicio),
            Where::eq('codcuentaesp', $specialAccount)
        ];
        $orderBy = ['codcuenta' => 'ASC'];
        $account->loadWhere($where, $orderBy);
        return $account;
    }

    /**
     * @param string $specialAccount
     * @param Asiento $asiento
     *
     * @return Subcuenta
     */
    public function getSpecialSubAccount(string $specialAccount, $asiento): Subcuenta
    {
        $subAccount = new Subcuenta();
        $where = [
            Where::eq('codejercicio', $asiento->codejercicio),
            Where::eq('codcuentaesp', $specialAccount)
        ];
        $orderBy = ['codsubcuenta' => 'ASC'];
        if ($subAccount->loadWhere($where, $orderBy)) {
            return $subAccount;
        }

        $account = $this->getSpecialAccount($specialAccount, $asiento);
        foreach ($account->getSubcuentas() as $subc) {
            return $subc;
        }

        return new Subcuenta();
    }
}
