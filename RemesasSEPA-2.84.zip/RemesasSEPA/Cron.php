<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\CuentaBancoCliente;

class Cron extends CronClass
{
    public function run(): void
    {
        $this->job('update-bank-accounts')
            ->every('1 year')
            ->run(function () {
                $this->updateCustomerBankAccounts();
            });
    }

    protected function updateCustomerBankAccounts(): void
    {
        // recorremos todas las cuentas bancarias de cliente sin mandato SEPA
        $where = [Where::eq('mandato', '')];
        foreach (CuentaBancoCliente::all($where) as $item) {
            $item->save();
        }
    }
}
