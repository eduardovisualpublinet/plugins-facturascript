<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA;

require_once __DIR__ . '/vendor/autoload.php';

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPA;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPAprov;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPArefund;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPArefundprov;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Controller\EditReciboCliente());
        $this->loadExtension(new Extension\Controller\EditReciboProveedor());
        $this->loadExtension(new Extension\Model\CuentaBancoCliente());
        $this->loadExtension(new Extension\Model\CuentaBancoProveedor());
        $this->loadExtension(new Extension\Model\PagoCliente());
        $this->loadExtension(new Extension\Model\PagoProveedor());
        $this->loadExtension(new Extension\Model\ReciboCliente());
        $this->loadExtension(new Extension\Model\ReciboProveedor());
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
        new RemesaSEPA();
        new RemesaSEPAprov();
        new RemesaSEPArefund();
        new RemesaSEPArefundprov();

        $this->updatePreviousData();
        $this->removeSEPAprov();
    }

    private function removeSEPAprov(): void
    {
        // comprobamos si existe el plugin SEPAprov
        if (is_null(Plugins::get('RemesasSEPAprov'))) {
            return;
        }

        // desactivamos el plugin
        if (Plugins::disable('RemesasSEPAprov')) {
            // eliminamos el plugin
            Plugins::remove('RemesasSEPAprov');
        }
    }

    private function updatePreviousData(): void
    {
        $dataBase = new DataBase();
        $idempresa = Tools::settings('default', 'idempresa');
        $sql = "UPDATE " . RemesaSEPA::tableName() . " SET tipo = " . $dataBase->var2str('CORE') . " WHERE tipo IS NULL;"
            . "UPDATE " . RemesaSEPA::tableName() . " SET idempresa = " . $dataBase->var2str($idempresa) . " WHERE idempresa IS NULL;";
        $dataBase->exec($sql);
    }
}
