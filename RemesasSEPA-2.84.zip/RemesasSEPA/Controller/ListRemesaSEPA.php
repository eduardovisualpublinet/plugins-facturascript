<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class ListRemesaSEPA extends ListController
{
    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'accounting';
        $data['title'] = 'remittances';
        $data['icon'] = 'fa-solid fa-piggy-bank';
        return $data;
    }

    protected function createViews(): void
    {
        $this->createViewsRemesaSepa();
        $this->createViewsRemesaSepaProv();
        $this->createViewsRemesaSepaRefund();
        $this->createViewsRemesaSepaProvRefund();
    }

    protected function createViewsRemesaSepa($viewName = 'ListRemesaSEPA'): void
    {
        $this->addView($viewName, 'RemesaSEPA', 'charges', 'fa-solid fa-file-import')
            ->addOrderBy(['idremesa'], 'code')
            ->addOrderBy(['fecha'], 'date')
            ->addOrderBy(['fechacargo'], 'charge-date', 2)
            ->addOrderBy(['total'], 'amount')
            ->addSearchFields(['descripcion', 'idremesa']);

        // filters
        $this->addFilterPeriod($viewName, 'fecha', 'date', 'fecha');

        $banks = $this->codeModel->all('cuentasbanco', 'codcuenta', 'descripcion');
        $this->addFilterSelect($viewName, 'codcuenta', 'bank-account', 'codcuenta', $banks);

        $status = $this->codeModel->all('remesas_sepa', 'estado', 'estado');
        $this->addFilterSelect($viewName, 'estado', 'status', 'estado', $status);
    }

    public function createViewsRemesaSepaProv($viewName = 'ListRemesaSEPAprov'): void
    {
        $this->addView($viewName, 'RemesaSEPAprov', 'payments', 'fa-solid fa-file-export')
            ->addOrderBy(['idremesa'], 'code')
            ->addOrderBy(['fecha'], 'date')
            ->addOrderBy(['fechacargo'], 'charge-date', 2)
            ->addOrderBy(['total'], 'amount')
            ->addSearchFields(['descripcion', 'idremesa']);

        // filters
        $this->addFilterPeriod($viewName, 'fecha', 'date', 'fecha');

        $banks = $this->codeModel->all('cuentasbanco', 'codcuenta', 'descripcion');
        $this->addFilterSelect($viewName, 'codcuenta', 'bank-account', 'codcuenta', $banks);

        $status = $this->codeModel->all('remesas_sepa', 'estado', 'estado');
        $this->addFilterSelect($viewName, 'estado', 'status', 'estado', $status);
    }

    protected function createViewsRemesaSepaProvRefund(string $viewName = "ListRemesaSEPArefundprov"): void
    {
        $this->addView($viewName, "RemesaSEPArefundprov", "refunds-payments", "fa-solid fa-share-square")
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false);
    }

    protected function createViewsRemesaSepaRefund(string $viewName = "ListRemesaSEPArefund"): void
    {
        $this->addView($viewName, "RemesaSEPArefund", "refunds-charges", "fa-solid fa-share-square")
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false);
    }
}
