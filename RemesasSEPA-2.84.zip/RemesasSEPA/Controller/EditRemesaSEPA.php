<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Controller;

use Digitick\Sepa\Exception\InvalidArgumentException;
use Exception;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\Accounting\PaymentToAccounting;
use FacturaScripts\Dinamic\Lib\Accounting\RemesaToAccounting;
use FacturaScripts\Dinamic\Lib\RemesaPagosCli;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\RemesaSEPA;
use FacturaScripts\Dinamic\Model\RemesaSEPArefund;

/**
 * Description of EditRemesaSEPA
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class EditRemesaSEPA extends EditController
{
    public function getModelClassName(): string
    {
        return 'RemesaSEPA';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'accounting';
        $data['title'] = 'collection-remittance';
        $data['icon'] = 'fa-solid fa-piggy-bank';
        return $data;
    }

    protected function addReceiptsAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        $num = 0;
        foreach ($codes as $code) {
            $receipt = new ReciboCliente();
            if (false === $receipt->load($code)) {
                continue;
            }

            $receipt->updateBankAccount();
            if (empty($receipt->iban)) {
                Tools::log()->warning('customer-have-no-iban', ['%customer%' => $receipt->getSubject()->nombre]);
                continue;
            }

            // si la factura es editable, avísamos
            $invoice = $receipt->getInvoice();
            if ($invoice->editable) {
                Tools::log()->info('invoice-editable', ['%invoice%' => $invoice->codigo]);
            }

            $receipt->idremesa = $remittance->id();
            if ($receipt->save()) {
                $num++;
            }
        }

        $remittance->save();
        Tools::log()->notice('items-added-correctly', ['%num%' => $num]);
        return true;
    }

    protected function chargedAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        // marcamos la remesa como cobrada
        $remittance->estado = RemesaSEPA::STATUS_DONE;
        if (false === $remittance->save()) {
            Tools::log()->warning('record-save-error');
            return true;
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        $this->createViewReceipts();
        $this->createViewReceiptsAdd();
        $this->createViewsRefunds();
    }

    protected function createViewReceipts(string $viewName = 'ListReciboClienteIBAN'): void
    {
        $this->addListView($viewName, 'ReciboCliente', 'receipts', 'fa-solid fa-file-invoice-dollar')
            ->addSearchFields(['codigofactura', 'observaciones'])
            ->addOrderBy(['codcliente'], 'customer')
            ->addOrderBy(['importe'], 'amount')
            ->addOrderBy(['fecha'], 'date', 2)
            ->addOrderBy(['vencimiento'], 'expiration');

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);

        // disable columns
        $this->views[$viewName]->disableColumn('payment-method');
    }

    protected function createViewReceiptsAdd(string $viewName = 'ListReciboClienteIBAN-add'): void
    {
        $this->addListView($viewName, 'ReciboCliente', 'add', 'fa-solid fa-folder-plus')
            ->addSearchFields(['codigofactura', 'observaciones'])
            ->addOrderBy(['codcliente'], 'customer')
            ->addOrderBy(['importe'], 'amount')
            ->addOrderBy(['fecha'], 'date', 2)
            ->addOrderBy(['vencimiento'], 'expiration');

        // filters
        $this->views[$viewName]->addFilterPeriod('vencimiento', 'expiration', 'vencimiento');
        $this->views[$viewName]->addFilterAutocomplete('codcliente', 'customer', 'codcliente', 'clientes', 'codcliente', 'razonsocial');

        $this->views[$viewName]->addFilterCheckbox('iban', 'with-iban', 'iban', 'IS NOT', null);

        $where = [
            Where::column('domiciliado', true),
            Where::column('idempresa', $this->getViewModelValue($viewName, 'idempresa')),
        ];
        $paymentMethods = $this->codeModel->all('formaspago', 'codpago', 'descripcion', true, $where);
        $this->views[$viewName]->addFilterSelect('codpago', 'payment-method', 'codpago', $paymentMethods);

        $this->views[$viewName]->addFilterNumber('total', 'amount', 'importe', '>=');
        $this->views[$viewName]->addFilterNumber('total2', 'amount', 'importe', '<=');

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
    }

    protected function createViewsRefunds(string $viewName = 'ListRemesaSEPArefund'): void
    {
        $this->addListView($viewName, 'RemesaSEPArefund', 'refunds', 'fa-solid fa-share-square')
            ->addOrderBy(['creation_date'], 'date', 2);

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
        $this->setSettings($viewName, 'checkBoxes', false);
        $this->setSettings($viewName, 'clickable', false);

        // disable columns
        $this->views[$viewName]->disableColumn('remittance');
    }

    /**
     * @return bool
     * @throws Exception
     */
    protected function downloadAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowExport) {
            Tools::log()->warning('not-allowed-export');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        // la marcamos como enviada
        $remittance->estado = RemesaSEPA::STATUS_REVIEW;
        $remittance->save();

        // exportamos el xml
        $this->setTemplate(false);
        $this->response->headers->set('Content-Type', 'text/xml');
        $this->response->headers->set(
            'Content-Disposition',
            'attachment;filename=sepa-' . $remittance->id() . '.xml'
        );
        $this->response->setContent(RemesaPagosCli::getXML($remittance));
        return false;
    }

    /**
     * @param string $action
     *
     * @return bool
     * @throws InvalidArgumentException
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'add-receipts':
                return $this->addReceiptsAction();

            case 'charged':
                return $this->chargedAction();

            case 'download':
                return $this->downloadAction();

            case 'generate-accounting':
                return $this->generateAccountingAction();

            case 'ready':
                return $this->readyAction();

            case 'rectify':
                return $this->rectifyAction();

            case 'refund':
                return $this->refundAction();

            case 'remove-receipts':
                return $this->removeReceiptsAction();

            case 'sent':
                return $this->sentAction();
        }

        return parent::execPreviousAction($action);
    }

    protected function generateAccountingAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $tool = new RemesaToAccounting();
        $tool->generate($remittance);

        if ($remittance->idasiento && $remittance->save()) {
            // recorremos los recibos
            foreach ($remittance->getReceipts() as $receipt) {
                // asignamos el asiento al último pago
                foreach ($receipt->getPayments() as $payment) {
                    $payment->idasiento = $remittance->idasiento;
                    $payment->save();
                    break;
                }
            }

            Tools::log()->notice('record-updated-correctly');
            return true;
        }

        Tools::log()->warning('record-save-error');
        return true;
    }

    protected function getRemittance(): RemesaSEPA
    {
        $remesa = new RemesaSEPA();
        $remesa->load($this->request->query('code'));
        return $remesa;
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $mainViewName = $this->getMainViewName();
        $idremesa = $this->getViewModelValue($mainViewName, 'idremesa');

        switch ($viewName) {
            case 'ListReciboClienteIBAN':
                $where = [Where::eq('idremesa', $idremesa)];
                $view->loadData('', $where);

                if (RemesaSEPA::STATUS_DONE === $this->getViewModelValue($mainViewName, 'estado')) {
                    $this->addButton($viewName, [
                        'action' => 'refund',
                        'color' => 'danger',
                        'icon' => 'fa-solid fa-share-square',
                        'label' => 'refund',
                        'confirm' => true,
                    ]);
                }
                break;

            case 'ListReciboClienteIBAN-add':
                $where = [
                    Where::isNull('idremesa'),
                    Where::eq('pagado', false),
                    Where::eq('coddivisa', $this->getViewModelValue($mainViewName, 'coddivisa')),
                    Where::eq('idempresa', $this->getViewModelValue($mainViewName, 'idempresa'))
                ];
                $view->loadData('', $where);
                break;

            case 'ListRemesaSEPArefund':
                $where = [Where::eq('idremesa', $idremesa)];
                $view->loadData('', $where);
                $view->setSettings('active', $view->model->count() > 0);
                break;

            case $mainViewName:
                parent::loadData($viewName, $view);
                $this->loadDataRemesaSEPA($viewName, $view);
                break;
        }
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadDataRemesaSEPA(string $viewName, BaseView $view): void
    {
        // hide company field
        if ($this->empresa->count() < 2) {
            $view->disableColumn('company');
        }

        // lock some fields
        switch ($view->model->estado) {
            default:
                if ($view->model->total > 0) {
                    // add ready button
                    $this->addButton($viewName, [
                        'action' => 'ready',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-check',
                        'label' => 'mark-as-ready'
                    ]);
                }
                // remove receipts action button
                $this->addButton('ListReciboClienteIBAN', [
                    'action' => 'remove-receipts',
                    'color' => 'danger',
                    'confirm' => true,
                    'icon' => 'fa-solid fa-folder-minus',
                    'label' => 'remove-from-list'
                ]);
                // add action button
                $this->addButton('ListReciboClienteIBAN-add', [
                    'action' => 'add-receipts',
                    'color' => 'success',
                    'icon' => 'fa-solid fa-folder-plus',
                    'label' => 'add'
                ]);
                break;

            case RemesaSEPA::STATUS_WAIT:
                $view->disableColumn('date', false, 'true');
                $view->disableColumn('description', false, 'true');
                $view->disableColumn('company', $this->empresa->count() < 2, 'true');
                $view->disableColumn('bank-account', false, 'true');
                if ($view->model->total > 0) {
                    // add download button
                    $this->addButton($viewName, [
                        'action' => 'download',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-download',
                        'label' => 'download-xml'
                    ]);

                    // add sent button
                    $this->addButton($viewName, [
                        'action' => 'sent',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-calendar-check',
                        'label' => 'mark-as-sent'
                    ]);
                }
                break;

            case RemesaSEPA::STATUS_REVIEW:
                // add paid button
                $this->addButton($viewName, [
                    'action' => 'charged',
                    'color' => 'success',
                    'icon' => 'fa-solid fa-check-square',
                    'label' => 'mark-as-charged'
                ]);
                // add download button
                $this->addButton($viewName, [
                    'action' => 'download',
                    'color' => 'info',
                    'icon' => 'fa-solid fa-download',
                    'label' => 'download-xml'
                ]);
                // add rectify button
                $this->addButton($viewName, [
                    'action' => 'rectify',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-edit',
                    'label' => 'rectify'
                ]);
            // no break

            case RemesaSEPA::STATUS_DONE:
                $view->disableColumn('date', false, 'true');
                $view->disableColumn('description', false, 'true');
                $view->disableColumn('name', false, 'true');
                $view->disableColumn('company', $this->empresa->count() < 2, 'true');
                $view->disableColumn('bank-account', false, 'true');
                $view->disableColumn('creditor-id', false, 'true');
                $view->disableColumn('charge-date', false, 'true');
                $view->disableColumn('type', false, 'true');
                $view->disableColumn('group-receipts-by-customer', false, 'true');
                $this->setSettings('ListReciboClienteIBAN-add', 'active', false);
                break;
        }

        // si la remesa está completada y no tiene asiento, añadimos el botón para crearlo
        if ($view->model->estado == RemesaSEPA::STATUS_DONE && empty($view->model->idasiento)) {
            $this->addButton($viewName, [
                'action' => 'generate-accounting',
                'color' => 'info',
                'icon' => 'fa-solid fa-magic',
                'label' => 'generate-accounting-entry'
            ]);
        }
    }

    protected function readyAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPA::STATUS_WAIT;
        $remittance->save();

        Tools::log()->notice('remittance-ready-to-download');
        return true;
    }

    protected function rectifyAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPA::STATUS_NEW;
        $remittance->save();

        Tools::log()->notice('remittance-ready-to-download');
        return true;
    }

    protected function refundAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        // comprobamos la remesa
        if ($remittance->estado !== RemesaSEPA::STATUS_DONE) {
            return true;
        }

        // obtenemos los códigos de los recibos
        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        foreach ($codes as $code) {
            $receipt = new ReciboCliente();
            if (false === $receipt->load($code)) {
                Tools::log()->warning('record-not-found');
                continue;
            }

            $receipt->idremesa = null;
            $receipt->pagado = false;
            if (false === $receipt->save()) {
                Tools::log()->warning('record-save-error');
                continue;
            }

            // obtenemos los pagos del recibo
            $payments = $receipt->getPayments();

            if (empty($payments)) {
                continue;
            }

            // obtenemos el último pago creado
            $lastPayment = end($payments);

            // si el pago ya tiene asiento, saltamos
            if (false === empty($lastPayment->idasiento)) {
                continue;
            }

            // creamos el asiento del pago
            $tool = new PaymentToAccounting();
            if (false === $tool->generate($lastPayment)) {
                continue;
            }

            // guardamos el pago
            if (false === $lastPayment->save()) {
                continue;
            }

            // registramos la devolución
            $refund = new RemesaSEPArefund();
            $refund->idremesa = $remittance->idremesa;
            $refund->idrecibo = $receipt->idrecibo;
            $refund->idfactura = $receipt->idfactura;
            $refund->save();
        }

        $remittance->save();
        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function removeReceiptsAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        $num = 0;
        foreach ($codes as $code) {
            $receipt = new ReciboCliente();
            if ($receipt->load($code)) {
                $receipt->idremesa = null;
                $receipt->pagado = false;
                $receipt->nick = $this->user->nick;
                if ($receipt->save()) {
                    $num++;
                }
            }
        }

        $remittance->save();
        Tools::log()->notice('items-removed-correctly', ['%num%' => $num]);
        return true;
    }

    protected function sentAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPA::STATUS_REVIEW;
        $remittance->save();

        Tools::log()->notice('remittance-ready-to-download');
        return true;
    }
}
