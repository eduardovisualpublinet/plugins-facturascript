<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Controller;

use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\Accounting\PaymentToAccounting;
use FacturaScripts\Dinamic\Lib\Accounting\RemesaProvToAccounting;
use FacturaScripts\Dinamic\Lib\RemesaPagosProv;
use FacturaScripts\Dinamic\Model\ReciboProveedor;
use FacturaScripts\Dinamic\Model\RemesaSEPAprov;
use FacturaScripts\Dinamic\Model\RemesaSEPArefundprov;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class EditRemesaSEPAprov extends EditController
{
    public function getModelClassName(): string
    {
        return "RemesaSEPAprov";
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'accounting';
        $data['title'] = 'collection-remittance-supplier';
        $data['icon'] = 'fa-solid fa-piggy-bank';
        return $data;
    }

    protected function addReceiptsAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        $num = 0;
        foreach ($codes as $code) {
            $receipt = new ReciboProveedor();
            if (false === $receipt->load($code)) {
                continue;
            }

            $receipt->updateBankAccount();
            if (empty($receipt->iban)) {
                Tools::log()->warning('supplier-have-no-iban', ['%supplier%' => $receipt->getSubject()->nombre]);
                continue;
            }

            // si la factura es editable, avísamos
            $invoice = $receipt->getInvoice();
            if ($invoice->editable) {
                Tools::log()->info('invoice-editable', ['%invoice%' => $invoice->codigo]);
            }

            $receipt->idremesa = $remittance->id();
            if ($receipt->save()) {
                $num++;
            }
        }

        $remittance->save();
        Tools::log()->notice('items-added-correctly', ['%num%' => $num]);
        return true;
    }

    protected function chargedAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        // marcamos la remesa como pagada
        $remittance->estado = RemesaSEPAprov::STATUS_DONE;
        if (false === $remittance->save()) {
            Tools::log()->warning('record-save-error');
            return true;
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function createViews(): void
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        $this->createViewReceipts();
        $this->createViewReceiptsAdd();
        $this->createViewsRefunds();
    }

    protected function createViewReceipts(string $viewName = 'ListReciboProveedorIBAN'): void
    {
        $this->addListView($viewName, 'ReciboProveedor', 'receipts', 'fa-solid fa-file-invoice-dollar')
            ->addSearchFields(['codigofactura', 'observaciones'])
            ->addOrderBy(['codproveedor'], 'supplier')
            ->addOrderBy(['importe'], 'amount')
            ->addOrderBy(['fecha'], 'date', 2)
            ->addOrderBy(['vencimiento'], 'expiration');

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);

        // disable columns
        $this->views[$viewName]->disableColumn('payment-method');
    }

    protected function createViewReceiptsAdd(string $viewName = 'ListReciboProveedorIBAN-add'): void
    {
        $this->addListView($viewName, 'ReciboProveedor', 'add', 'fa-solid fa-folder-plus')
            ->addSearchFields(['codigofactura', 'observaciones'])
            ->addOrderBy(['codproveedor'], 'supplier')
            ->addOrderBy(['importe'], 'amount')
            ->addOrderBy(['fecha'], 'date', 2)
            ->addOrderBy(['vencimiento'], 'expiration');

        // filters
        $this->views[$viewName]->addFilterPeriod('vencimiento', 'expiration', 'vencimiento');
        $this->views[$viewName]->addFilterAutocomplete('codproveedor', 'supplier', 'codproveedor', 'proveedores', 'codproveedor', 'razonsocial');

        $this->views[$viewName]->addFilterCheckbox('iban', 'with-iban', 'iban', 'IS NOT', null);

        $paymentMethods = $this->codeModel->all('formaspago', 'codpago', 'descripcion');
        $this->views[$viewName]->addFilterSelect('codpago', 'payment-method', 'codpago', $paymentMethods);

        $this->views[$viewName]->addFilterNumber('total', 'amount', 'importe', '>=');
        $this->views[$viewName]->addFilterNumber('total2', 'amount', 'importe', '<=');

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
    }

    protected function createViewsRefunds(string $viewName = 'ListRemesaSEPArefundprov'): void
    {
        $this->addListView($viewName, 'RemesaSEPArefundprov', 'refunds', 'fa-solid fa-share-square')
            ->addOrderBy(['creation_date'], 'date', 2);

        // disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
        $this->setSettings($viewName, 'checkBoxes', false);
        $this->setSettings($viewName, 'clickable', false);

        // disable columns
        $this->views[$viewName]->disableColumn('remittance');
    }

    protected function downloadAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowExport) {
            Tools::log()->warning('not-allowed-export');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPAprov::STATUS_REVIEW;
        $remittance->save();

        $this->setTemplate(false);
        $this->response->headers->set('Content-Type', 'text/xml');
        $this->response->headers->set(
            'Content-Disposition',
            'attachment;filename=sepa-' . $remittance->id() . '.xml'
        );
        $this->response->setContent(RemesaPagosProv::getXML($remittance));
        return false;
    }

    /**
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'add-receipts' => $this->addReceiptsAction(),
            'charged' => $this->chargedAction(),
            'download' => $this->downloadAction(),
            'generate-accounting' => $this->generateAccountingAction(),
            'ready' => $this->readyAction(),
            'rectify' => $this->rectifyAction(),
            'refund' => $this->refundAction(),
            'remove-receipts' => $this->removeReceiptsAction(),
            'sent' => $this->sentAction(),
            default => parent::execPreviousAction($action),
        };
    }

    protected function generateAccountingAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $tool = new RemesaProvToAccounting();
        $tool->generate($remittance);

        if ($remittance->idasiento && $remittance->save()) {
            // recorremos los recibos
            foreach ($remittance->getReceipts() as $receipt) {
                // asignamos el asiento al último pago
                foreach ($receipt->getPayments() as $payment) {
                    $payment->idasiento = $remittance->idasiento;
                    $payment->save();
                    break;
                }
            }

            Tools::log()->notice('record-updated-correctly');
            return true;
        }

        Tools::log()->warning('record-save-error');
        return true;
    }

    protected function getRemittance(): RemesaSEPAprov
    {
        $remesa = new RemesaSEPAprov();
        $remesa->load($this->request->query->get('code'));
        return $remesa;
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $mvn = $this->getMainViewName();
        $idremesa = $this->getViewModelValue($mvn, 'idremesa');

        switch ($viewName) {
            case 'ListReciboProveedorIBAN':
                $where = [Where::column('idremesa', $idremesa)];
                $view->loadData('', $where);

                if (RemesaSEPAprov::STATUS_DONE === $this->getViewModelValue($mvn, 'estado')) {
                    $this->addButton($viewName, [
                        'action' => 'refund',
                        'color' => 'danger',
                        'icon' => 'fa-solid fa-share-square',
                        'label' => 'refund',
                        'confirm' => true,
                    ]);
                }
                break;

            case 'ListReciboProveedorIBAN-add':
                $where = [
                    Where::column('idremesa', null, 'IS'),
                    Where::column('pagado', false),
                    Where::column('coddivisa', $this->getViewModelValue($mvn, 'coddivisa')),
                    Where::column('idempresa', $this->getViewModelValue($mvn, 'idempresa'))
                ];
                $view->loadData('', $where);
                break;

            case 'ListRemesaSEPArefundprov':
                $where = [Where::column('idremesa', $idremesa)];
                $view->loadData('', $where);
                $view->setSettings('active', $view->model->count() > 0);
                break;

            case $mvn:
                parent::loadData($viewName, $view);
                $this->loadDataRemesaSEPA($viewName, $view);
                break;
        }
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadDataRemesaSEPA($viewName, $view): void
    {
        // hide company field
        if ($this->empresa->count() < 2) {
            $view->disableColumn('company');
        }

        // lock some fields
        switch ($view->model->estado) {
            default:
                if ($view->model->total > 0) {
                    // add ready button
                    $this->addButton($viewName, [
                        'action' => 'ready',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-check',
                        'label' => 'mark-as-ready'
                    ]);
                }
                // remove receipts action button
                $this->addButton('ListReciboProveedorIBAN', [
                    'action' => 'remove-receipts',
                    'color' => 'danger',
                    'confirm' => true,
                    'icon' => 'fa-solid fa-folder-minus',
                    'label' => 'remove-from-list'
                ]);
                // add action button
                $this->addButton('ListReciboProveedorIBAN-add', [
                    'action' => 'add-receipts',
                    'color' => 'success',
                    'icon' => 'fa-solid fa-folder-plus',
                    'label' => 'add'
                ]);
                break;

            case RemesaSEPAprov::STATUS_WAIT:
                $view->disableColumn('date', false, 'true');
                $view->disableColumn('description', false, 'true');
                $view->disableColumn('company', $this->empresa->count() < 2, 'true');
                $view->disableColumn('bank-account', false, 'true');
                if ($view->model->total > 0) {
                    // add download button
                    $this->addButton($viewName, [
                        'action' => 'download',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-download',
                        'label' => 'download-xml'
                    ]);

                    // add sent button
                    $this->addButton($viewName, [
                        'action' => 'sent',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-calendar-check',
                        'label' => 'mark-as-sent'
                    ]);
                }
                break;

            case RemesaSEPAprov::STATUS_REVIEW:
                // add paid button
                $this->addButton($viewName, [
                    'action' => 'charged',
                    'color' => 'success',
                    'icon' => 'fa-solid fa-check-square',
                    'label' => 'mark-as-charged'
                ]);
                // add download button
                $this->addButton($viewName, [
                    'action' => 'download',
                    'color' => 'info',
                    'icon' => 'fa-solid fa-download',
                    'label' => 'download-xml'
                ]);
                // add rectify button
                $this->addButton($viewName, [
                    'action' => 'rectify',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-edit',
                    'label' => 'rectify'
                ]);
            // no break

            case RemesaSEPAprov::STATUS_DONE:
                $view->disableColumn('date', false, 'true');
                $view->disableColumn('description', false, 'true');
                $view->disableColumn('name', false, 'true');
                $view->disableColumn('company', $this->empresa->count() < 2, 'true');
                $view->disableColumn('bank-account', false, 'true');
                $view->disableColumn('creditor-id', false, 'true');
                $view->disableColumn('charge-date', false, 'true');
                $view->disableColumn('type', false, 'true');
                $view->disableColumn('group-receipts-by-supplier', false, 'true');
                $this->setSettings('ListReciboProveedorIBAN-add', 'active', false);
                break;
        }

        // si la remesa está completada y no tiene asiento, añadimos el botón para crearlo
        if ($view->model->estado == RemesaSEPAprov::STATUS_DONE && empty($view->model->idasiento)) {
            $this->addButton($viewName, [
                'action' => 'generate-accounting',
                'color' => 'info',
                'icon' => 'fa-solid fa-magic',
                'label' => 'generate-accounting-entry'
            ]);
        }
    }

    protected function readyAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPAprov::STATUS_WAIT;
        $remittance->save();

        Tools::log()->notice('remittance-ready-to-download');
        return true;
    }

    protected function rectifyAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPAprov::STATUS_NEW;
        $remittance->save();

        Tools::log()->notice('remittance-ready-to-download');
        return true;
    }

    protected function refundAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        // comprobamos la remesa
        if ($remittance->estado !== RemesaSEPAprov::STATUS_DONE) {
            return true;
        }

        // obtenemos los códigos de los recibos
        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        foreach ($codes as $code) {
            $receipt = new ReciboProveedor();
            if (false === $receipt->load($code)) {
                Tools::log()->warning('record-not-found');
                continue;
            }

            $receipt->idremesa = null;
            $receipt->pagado = false;
            if (false === $receipt->save()) {
                Tools::log()->warning('record-save-error');
                continue;
            }

            // obtenemos los pagos del recibo
            $payments = $receipt->getPayments();

            if (empty($payments)) {
                continue;
            }

            // obtenemos el último pago creado
            $lastPayment = end($payments);

            // si el pago ya tiene asiento, saltamos
            if (false === empty($lastPayment->idasiento)) {
                continue;
            }

            // creamos el asiento del pago
            $tool = new PaymentToAccounting();
            if (false === $tool->generate($lastPayment)) {
                continue;
            }

            // guardamos el pago
            if (false === $lastPayment->save()) {
                continue;
            }

            // registramos la devolución
            $refund = new RemesaSEPArefundprov();
            $refund->idremesa = $remittance->idremesa;
            $refund->idrecibo = $receipt->idrecibo;
            $refund->idfactura = $receipt->idfactura;
            $refund->save();
        }

        $remittance->save();
        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function removeReceiptsAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        $num = 0;
        foreach ($codes as $code) {
            $receipt = new ReciboProveedor();
            if ($receipt->load($code)) {
                $receipt->idremesa = null;
                $receipt->pagado = false;
                $receipt->nick = $this->user->nick;
                if ($receipt->save()) {
                    $num++;
                }
            }
        }

        $remittance->save();
        Tools::log()->notice('items-removed-correctly', ['%num%' => $num]);
        return true;
    }

    protected function sentAction(): bool
    {
        $remittance = $this->getRemittance();
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        } elseif (false === $this->validateFormToken()) {
            return true;
        } elseif (false === $remittance->exists()) {
            Tools::log()->warning('record-not-found');
            return true;
        }

        $remittance->estado = RemesaSEPAprov::STATUS_REVIEW;
        $remittance->save();

        Tools::log()->notice('record-updated-correctly');
        return true;
    }
}
