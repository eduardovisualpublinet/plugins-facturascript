<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\ConciliacionBancaria\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\DataSrc\Ejercicios;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Asiento;
use FacturaScripts\Dinamic\Model\Base\ModelCore;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Dinamic\Model\MovimientoBanco;
use FacturaScripts\Dinamic\Model\Proveedor;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\ReciboProveedor;
use FacturaScripts\Dinamic\Model\RemesaSEPA;
use FacturaScripts\Dinamic\Model\Subcuenta;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ConciliateBankMovements extends Controller
{
    /** @var string */
    public $codcuenta;

    /** @var CuentaBanco */
    public $cuenta;

    /** @var array */
    private $logLevels = ['critical', 'error', 'info', 'notice', 'warning'];

    public function getBankAccounts(): array
    {
        return CuentaBanco::all();
    }

    public function getPaymentMethods(): array
    {
        return FormasPago::all();
    }

    public function getSubaccounts(): array
    {
        foreach (Ejercicios::all() as $ejercicio) {
            if ($ejercicio->idempresa != $this->cuenta->idempresa) {
                continue;
            }

            if (!$ejercicio->isOpened()) {
                continue;
            }

            $where = [Where::column('codejercicio', $ejercicio->codejercicio),];
            return Subcuenta::all($where, ['codsubcuenta' => 'ASC']);
        }

        return [];
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["menu"] = "accounting";
        $data["title"] = "conciliate-bank-movements";
        $data["icon"] = "fa-solid fa-check-double";
        $data["showonmenu"] = false;
        return $data;
    }

    public function privateCore(&$response, $user, $permissions)
    {
        parent::privateCore($response, $user, $permissions);

        $this->codcuenta = $this->request->get('codcuenta', '');
        $this->cuenta = new CuentaBanco();
        if (false === $this->cuenta->load($this->codcuenta)) {
            Tools::log()->warning('record-not-found');
            return;
        }

        if ($this->request->get('ajax', false)) {
            $this->setTemplate(false);

            $action = $this->request->get('action', '');
            switch ($action) {
                case 'autocomplete-client':
                    $data = $this->autocompleteClientAction();
                    break;

                case 'autocomplete-supplier':
                    $data = $this->autocompleteSupplierAction();
                    break;

                case 'getAsientos':
                    $data = $this->getAsientos();
                    break;

                case 'getBankMovements':
                    $data = $this->getBankMovements();
                    break;

                case 'getReceiptsPurchases':
                    $data = $this->getReceiptsPurchases();
                    break;

                case 'getReceiptsSales':
                    $data = $this->getReceiptsSales();
                    break;

                case 'getRemesas':
                    $data = $this->getRemesas();
                    break;

                case 'reconciliate':
                    $data = $this->reconciliateAction();
                    break;
            }

            $content = array_merge(
                ['messages' => Tools::log()->read('master', $this->logLevels)],
                $data ?? []
            );
            $this->response->setContent(json_encode($content));
        }
    }

    protected function autocompleteClientAction(): array
    {
        $list = [];
        $client = new Cliente();
        $query = $this->request->get('query');
        foreach ($client->codeModelSearch($query, 'codcliente') as $value) {
            $list[] = [
                'key' => Tools::fixHtml($value->code),
                'value' => Tools::fixHtml($value->description)
            ];
        }

        if (empty($list)) {
            $list[] = ['key' => null, 'value' => Tools::lang()->trans('no-data')];
        }

        return ['clients' => $list];
    }

    protected function autocompleteSupplierAction(): array
    {
        $list = [];
        $supplier = new Proveedor();
        $query = $this->request->get('query');
        foreach ($supplier->codeModelSearch($query, 'codproveedor') as $value) {
            $list[] = [
                'key' => Tools::fixHtml($value->code),
                'value' => Tools::fixHtml($value->description)
            ];
        }

        if (empty($list)) {
            $list[] = ['key' => null, 'value' => Tools::lang()->trans('no-data')];
        }

        return ['suppliers' => $list];
    }

    protected function getAsientos(): array
    {
        $html = '';
        $cuentaBanco = new CuentaBanco();
        if (false === $cuentaBanco->load($this->request->get('codcuenta', ''))) {
            return [
                'getAsientos' => false,
                'html' => $html,
            ];
        }

        $concepto = $this->request->get('concepto', '');
        $amountGreaterOrEqual = $this->request->get('amountGreaterOrEqual', '');
        $amountLessThanOrEqual = $this->request->get('amountLessThanOrEqual', '');
        $dateGreaterOrEqual = $this->request->get('dateGreaterOrEqual', '');
        $dateLessThanOrEqual = $this->request->get('dateLessThanOrEqual', '');

        $where = [
            Where::column('idempresa', $cuentaBanco->idempresa),
            Where::column('idbankmovement', null),
            Where::column('editable', true),
        ];

        if ($dateGreaterOrEqual) {
            $where[] = Where::column('fecha', $dateGreaterOrEqual, '>=');
        }

        if ($dateLessThanOrEqual) {
            $where[] = Where::column('fecha', $dateLessThanOrEqual, '<=');
        }

        if ($amountGreaterOrEqual) {
            $where[] = Where::column('importe', $amountGreaterOrEqual, '>=');
        }

        if ($amountLessThanOrEqual) {
            $where[] = Where::column('importe', $amountLessThanOrEqual, '<=');
        }

        if ($concepto) {
            $where[] = Where::column('concepto', $concepto, 'XLIKE');
        }

        foreach (Asiento::all($where, ['fecha' => 'ASC']) as $asiento) {
            $amount = Tools::number($asiento->importe);

            if ($asiento->documento) {
                $facturaCliente = new FacturaCliente();
                $facturaProveedor = new FacturaProveedor();
                $where = [
                    Where::column('codigo', $asiento->documento),
                    Where::column('idasiento', $asiento->idasiento),
                ];
                if ($facturaCliente->loadWhere($where)) {
                    $amount = Tools::money($facturaCliente->total, $facturaCliente->coddivisa);
                } elseif ($facturaProveedor->loadWhere($where)) {
                    $amount = Tools::money($facturaProveedor->total, $facturaProveedor->coddivisa);
                }
            }

            $html .= '<tr>'
                . '<td class="align-middle text-center"><input type="checkbox" value="' . $asiento->idasiento . '"/></td>'
                . '<td class="align-middle">'
                . '<a href="' . $asiento->url() . '" target="_blank">' . $asiento->idasiento . '</a> - ' . $asiento->concepto
                . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . $amount . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . $asiento->fecha . '</td>'
                . '</tr>';
        }

        return [
            'getAsientos' => true,
            'html' => $html,
        ];
    }

    protected function getBankMovements(): array
    {
        $html = '';
        $where = [
            Where::column('codcuenta', $this->codcuenta),
            Where::column('reconciled', false),
        ];

        foreach (MovimientoBanco::all($where, ['date' => 'ASC', 'id' => 'ASC']) as $bankMovement) {
            $cssAmount = $bankMovement->amount > 0 ? 'text-success' : 'text-danger';

            $html .= '<tr data-idmovement="' . $bankMovement->id . '">'
                . '<td class="align-middle amount text-end text-nowrap ' . $cssAmount . '">'
                . Tools::number($bankMovement->amount) . '</td>'
                . '<td class="align-middle date text-nowrap">' . date(ModelCore::DATE_STYLE, strtotime($bankMovement->date)) . '</td>'
                . '<td class="align-middle observations">' . $bankMovement->observations . '</td>'
                . '<td class="align-middle text-end">'
                . '<div class="dropdown">'
                . '<button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">'
                . Tools::lang()->trans('link-up')
                . '</button>'
                . '<div class="dropdown-menu">'
                . '<button type="button" class="dropdown-item" data-bankMovementId="' . $bankMovement->id . '" onclick="showModalAsientos(this)">'
                . '<i class="fa-solid fa-link me-2"></i>' . Tools::lang()->trans('accounting-entries')
                . '</button>'
                . '<button type="button" class="dropdown-item" data-bankMovementId="' . $bankMovement->id . '" onclick="showModalClients(this)">'
                . '<i class="fa-solid fa-link me-2"></i>' . Tools::lang()->trans('customer-receipts')
                . '</button>'
                . '<button type="button" class="dropdown-item" data-bankMovementId="' . $bankMovement->id . '" onclick="showModalSuppliers(this)">'
                . '<i class="fa-solid fa-link me-2"></i>' . Tools::lang()->trans('supplier-receipts')
                . '</button>';

            if (Plugins::isEnabled('RemesasSEPA')) {
                $html .= '<button type="button" class="dropdown-item" data-bankMovementId="' . $bankMovement->id . '" onclick="showModalRemesas(this)">'
                    . '<i class="fa-solid fa-link me-2"></i>' . Tools::lang()->trans('remittances')
                    . '</button>';
            }

            $html .= '</div>'
                . '</div>'
                . '</td>'
                . '</tr>';
        }

        if (empty($html)) {
            $html = '<tr>'
                . '<td colspan="4" class="text-center table-warning">' . Tools::lang()->trans('no-data') . '</td>'
                . '</tr>';
        }

        return [
            'getBankMovements' => true,
            'html' => $html,
        ];
    }

    protected function getReceiptsPurchases(): array
    {
        $html = '';
        $where = [];
        $codproveedor = $this->request->get('codproveedor', '');
        $codpago = $this->request->get('codpago', '');
        $amountGreaterOrEqual = $this->request->get('amountGreaterOrEqual', '');
        $amountLessThanOrEqual = $this->request->get('amountLessThanOrEqual', '');
        $dateGreaterOrEqual = $this->request->get('dateGreaterOrEqual', '');
        $dateLessThanOrEqual = $this->request->get('dateLessThanOrEqual', '');
        $search = $this->request->get('search', '');
        $status = $this->request->get('status', '');

        if ($dateGreaterOrEqual) {
            $where[] = Where::column('fecha', $dateGreaterOrEqual, '>=');
        }

        if ($dateLessThanOrEqual) {
            $where[] = Where::column('fecha', $dateLessThanOrEqual, '<=');
        }

        if ($status === 'paid') {
            $where[] = Where::column('pagado', true);
        } elseif ($status === 'unpaid') {
            $where[] = Where::column('pagado', false);
        }

        if ($codproveedor) {
            $where[] = Where::column('codproveedor', $codproveedor);
        }

        if ($codpago) {
            $where[] = Where::column('codpago', $codpago);
        }

        if ($amountGreaterOrEqual) {
            $where[] = Where::column('importe', $amountGreaterOrEqual, '>=');
        }

        if ($amountLessThanOrEqual) {
            $where[] = Where::column('importe', $amountLessThanOrEqual, '<=');
        }

        if ($search) {
            $where[] = Where::column('observaciones', $search, 'XLIKE');
            $where[] = Where::column('codigofactura', $search, 'LIKE', 'OR');
        }

        $orderBy = ['vencimiento' => 'DESC', 'codproveedor' => 'ASC'];
        foreach (ReciboProveedor::all($where, $orderBy) as $receipt) {
            $html .= '<tr>'
                . '<td class="align-middle text-center"><input type="checkbox" value="' . $receipt->idrecibo . '"/></td>'
                . '<td>'
                . '<a href="' . $receipt->url() . '" target="_blank">' . $receipt->codigofactura . '-' . $receipt->numero . '</a> '
                . $receipt->getSubject()->nombre . ' ' . $receipt->observaciones
                . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . Tools::number($receipt->importe) . '</td>'
                . '<td class="align-middle">' . $receipt->getPaymentMethod()->descripcion . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . date(ModelCore::DATE_STYLE, strtotime($receipt->vencimiento)) . '</td>'
                . '</tr>';
        }

        if (empty($html)) {
            $html = '<tr>'
                . '<td colspan="5" class="text-center table-warning">' . Tools::lang()->trans('no-data') . '</td>'
                . '</tr>';
        }

        return [
            'getReceiptsPurchases' => true,
            'html' => $html,
        ];
    }

    protected function getReceiptsSales(): array
    {
        $html = '';
        $where = [];
        $codcliente = $this->request->get('codcliente', '');
        $codpago = $this->request->get('codpago', '');
        $amountGreaterOrEqual = $this->request->get('amountGreaterOrEqual', '');
        $amountLessThanOrEqual = $this->request->get('amountLessThanOrEqual', '');
        $dateGreaterOrEqual = $this->request->get('dateGreaterOrEqual', '');
        $dateLessThanOrEqual = $this->request->get('dateLessThanOrEqual', '');
        $status = $this->request->get('status', '');
        $search = $this->request->get('search', '');

        if ($status === 'paid') {
            $where[] = Where::column('pagado', true);
        } elseif ($status === 'unpaid') {
            $where[] = Where::column('pagado', false);
        }

        if ($dateGreaterOrEqual) {
            $where[] = Where::column('fecha', $dateGreaterOrEqual, '>=');
        }

        if ($dateLessThanOrEqual) {
            $where[] = Where::column('fecha', $dateLessThanOrEqual, '<=');
        }

        if ($codcliente) {
            $where[] = Where::column('codcliente', $codcliente);
        }

        if ($codpago && $codpago !== 'all') {
            $where[] = Where::column('codpago', $codpago);
        }

        if ($amountGreaterOrEqual) {
            $where[] = Where::column('importe', $amountGreaterOrEqual, '>=');
        }

        if ($amountLessThanOrEqual) {
            $where[] = Where::column('importe', $amountLessThanOrEqual, '<=');
        }

        if ($search) {
            $where[] = Where::column('observaciones', $search, 'XLIKE');
            $where[] = Where::column('codigofactura', $search, 'LIKE', 'OR');
        }

        if (Plugins::isEnabled('RemesasSEPA')) {
            $where[] = Where::column('idremesa', null);
        }

        $orderBy = ['vencimiento' => 'DESC', 'codcliente' => 'ASC'];
        foreach (ReciboCliente::all($where, $orderBy) as $receipt) {
            $html .= '<tr>'
                . '<td class="align-middle text-center"><input type="checkbox" value="' . $receipt->idrecibo . '"/></td>'
                . '<td>'
                . '<a href="' . $receipt->url() . '" target="_blank">' . $receipt->codigofactura . '-' . $receipt->numero . '</a> '
                . $receipt->getSubject()->nombre . ' ' . $receipt->observaciones
                . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . Tools::number($receipt->importe) . '</td>'
                . '<td class="align-middle">' . $receipt->getPaymentMethod()->descripcion . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . date(ModelCore::DATE_STYLE, strtotime($receipt->vencimiento)) . '</td>'
                . '</tr>';
        }

        if (empty($html)) {
            $html = '<tr>'
                . '<td colspan="5" class="text-center table-warning">' . Tools::lang()->trans('no-data') . '</td>'
                . '</tr>';
        }

        return [
            'getReceiptsSales' => true,
            'html' => $html,
        ];
    }

    protected function getRemesas(): array
    {
        $html = '';
        $codcuenta = $this->request->get('codcuenta', '');
        if (false === Plugins::isEnabled('RemesasSEPA') || empty($codcuenta)) {
            return [
                'getRemesas' => false,
                'html' => $html,
            ];
        }

        $where = [
            Where::column('codcuenta', $codcuenta),
        ];
        foreach (RemesaSEPA::all($where, ['fechacargo' => 'ASC']) as $remesa) {
            $html .= '<tr>'
                . '<td class="align-middle text-center"><input type="checkbox" value="' . $remesa->idremesa . '"/></td>'
                . '<td class="align-middle">'
                . '<a href="' . $remesa->url() . '" target="_blank">' . $remesa->idremesa . '</a> - ' . $remesa->fecha
                . '</td>'
                . '<td class="align-middle">' . $remesa->descripcion . '</td>'
                . '<td class="align-middle text-end text-nowrap">' . Tools::number($remesa->total) . '</td>'
                . '<td class="align-middle text-end ">' . $remesa->fechacargo . '</td>'
                . '</tr>';
        }

        if (empty($html)) {
            $html = '<tr>'
                . '<td colspan="5" class="text-center table-warning">' . Tools::lang()->trans('no-data') . '</td>'
                . '</tr>';
        }

        return [
            'getRemesas' => true,
            'html' => $html,
        ];
    }

    protected function reconciliateAction(): array
    {
        $bankMovement = new MovimientoBanco();
        if (false === $bankMovement->load($this->request->get('idMovement', ''))) {
            Tools::log()->warning('record-not-found');
            return ['reconciliate' => false];
        }

        $type = $this->request->get('type', '');
        switch ($type) {
            case 'asientos':
                return ['reconciliate' => $this->reconciliateAsientosAction($bankMovement)];

            case 'new-asiento':
                return ['reconciliate' => $this->reconciliateNewAsientoAction($bankMovement)];

            case 'purchases':
            case 'sales':
                return ['reconciliate' => $this->reconciliateReceiptsAction($bankMovement, $type)];

            case 'remesas':
                return ['reconciliate' => $this->reconciliateRemesasAction($bankMovement)];

            default:
                Tools::log()->warning('no-data');
                return ['reconciliate' => false];
        }
    }

    protected function reconciliateAsientosAction(MovimientoBanco $bankMovement): bool
    {
        $idAsientos = $this->request->get('idAsientos', []);
        if (empty($idAsientos)) {
            Tools::log()->warning('no-data');
            return false;
        }

        $this->dataBase->beginTransaction();

        $idAsientos = explode(',', $idAsientos);
        foreach ($idAsientos as $idAsiento) {
            // cargamos el asiento
            $asiento = new Asiento();

            if (false === $asiento->load($idAsiento)) {
                continue;
            }

            $asiento->idbankmovement = $bankMovement->id;
            if (false === $asiento->save()) {
                $this->dataBase->rollback();
                Tools::log()->warning('record-save-error');
                return false;
            }
        }

        $bankMovement->reconciled = true;
        if (false === $bankMovement->save()) {
            $this->dataBase->rollback();
            Tools::log()->warning('record-save-error');
            return false;
        }


        $this->dataBase->commit();
        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function reconciliateNewAsientoAction(MovimientoBanco $bankMovement): bool
    {
        $this->dataBase->beginTransaction();
        $concept = $this->request->get('concept', '');

        // creamos el asiento
        $asiento = new Asiento();
        $asiento->idempresa = $this->cuenta->idempresa;
        $asiento->fecha = $bankMovement->date;
        $asiento->concepto = empty($concept) ? $bankMovement->observations : $concept;
        $asiento->importe = abs($bankMovement->amount);
        $asiento->idbankmovement = $bankMovement->id;
        if (false === $asiento->save()) {
            Tools::log()->warning('record-save-error');
            $this->dataBase->rollback();
            return false;
        }

        // añadimos la partida de la cuenta de banco
        $partida1 = $asiento->getNewLine();
        $subcuenta1 = $partida1->getSubcuenta($this->cuenta->codsubcuenta);
        $partida1->setAccount($subcuenta1);
        $partida1->debe = $bankMovement->amount > 0 ? $asiento->importe : 0;
        $partida1->haber = $bankMovement->amount < 0 ? $asiento->importe : 0;
        if (false === $partida1->save()) {
            Tools::log()->warning('record-save-error');
            $this->dataBase->rollback();
            return false;
        }

        // añadimos la otra partida
        $partida2 = $asiento->getNewLine();
        $subcuenta2 = $partida2->getSubcuenta($this->request->get('contra'));
        $partida2->setAccount($subcuenta2);
        $partida2->debe = $bankMovement->amount < 0 ? $asiento->importe : 0;
        $partida2->haber = $bankMovement->amount > 0 ? $asiento->importe : 0;
        if (false === $partida2->save()) {
            Tools::log()->warning('record-save-error');
            $this->dataBase->rollback();
            return false;
        }

        // guardamos el movimiento de banco
        $bankMovement->reconciled = true;
        $bankMovement->save();

        $this->dataBase->commit();
        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function reconciliateReceiptsAction(MovimientoBanco $bankMovement, string $type): bool
    {
        $idReceipts = $this->request->get('idReceipts', []);
        if (empty($idReceipts)) {
            Tools::log()->warning('no-data');
            return false;
        }

        $newTransaction = $this->dataBase->inTransaction();
        if (false === $newTransaction) {
            $newTransaction = true;
            $this->dataBase->beginTransaction();
        }

        $idReceipts = explode(',', $idReceipts);
        foreach ($idReceipts as $idReceipt) {
            // cargamos el modelo correspondiente
            if ($type === 'purchases') {
                $receipt = new ReciboProveedor();
            } else {
                $receipt = new ReciboCliente();
            }

            // si el recibo no existe, lo saltamos
            if (false === isset($receipt) || false === $receipt->load($idReceipt)) {
                continue;
            }

            // si el recibo ya está pagado, lo saltamos
            if ($receipt->pagado) {
                continue;
            }

            $receipt->idbankmovement = $bankMovement->id;
            $receipt->fechapago = $bankMovement->date;
            $receipt->pagado = true;

            if (false === $receipt->save()) {
                if ($newTransaction) {
                    $this->dataBase->rollback();
                }

                Tools::log()->warning('record-save-error');
                return false;
            }
        }

        $bankMovement->reconciled = true;
        if (false === $bankMovement->save()) {
            if ($newTransaction) {
                $this->dataBase->rollback();
            }

            Tools::log()->warning('record-save-error');
            return false;
        }

        if ($newTransaction) {
            $this->dataBase->commit();
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function reconciliateRemesasAction(MovimientoBanco $bankMovement): bool
    {
        $idRemesas = $this->request->get('idRemesas', []);
        if (empty($idRemesas)) {
            Tools::log()->warning('no-data');
            return false;
        }

        $newTransaction = $this->dataBase->inTransaction();
        if (false === $newTransaction) {
            $newTransaction = true;
            $this->dataBase->beginTransaction();
        }

        $idRemesas = explode(',', $idRemesas);
        foreach ($idRemesas as $idRemesa) {
            // cargamos el modelo remesa
            $remesa = new RemesaSEPA();
            if (false === $remesa->load($idRemesa)) {
                continue;
            }

            // si la remesa ya esta pagada la saltamos
            if ($remesa->estado === RemesaSEPA::STATUS_DONE) {
                continue;
            }

            foreach ($remesa->getReceipts() as $receipt) {
                if (false === $receipt->pagado) {
                    $receipt->idbankmovement = $bankMovement->id;
                    $receipt->fechapago = $remesa->fechacargo;
                    $receipt->nick = $this->user->nick;
                    $receipt->pagado = true;
                    if (false === $receipt->save()) {
                        if ($newTransaction) {
                            $this->dataBase->rollback();
                        }

                        Tools::log()->warning('record-save-error');
                        return false;
                    }
                }
            }

            $remesa->idbankmovement = $bankMovement->id;
            $remesa->estado = RemesaSEPA::STATUS_DONE;

            if (false === $remesa->save()) {
                if ($newTransaction) {
                    $this->dataBase->rollback();
                }

                Tools::log()->warning('record-save-error');
                return false;
            }
        }

        $bankMovement->reconciled = true;
        if (false === $bankMovement->save()) {
            if ($newTransaction) {
                $this->dataBase->rollback();
            }

            Tools::log()->warning('record-save-error');
            return false;
        }

        if ($newTransaction) {
            $this->dataBase->commit();
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }
}
