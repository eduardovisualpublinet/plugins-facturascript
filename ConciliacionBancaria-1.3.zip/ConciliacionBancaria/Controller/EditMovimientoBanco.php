<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\ConciliacionBancaria\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Where;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditMovimientoBanco extends EditController
{
    public function getModelClassName(): string
    {
        return "MovimientoBanco";
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["title"] = "bank-movement";
        $data["icon"] = "fa-solid fa-list";
        return $data;
    }

    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        // desactivamos los botones de nuevo, deshacer y guardar
        $mvn = $this->getMainViewName();
        $this->setSettings($mvn, 'btnNew', false);

        $this->createViewsRecibos();
        $this->createViewsAsientos();
    }

    protected function createViewsAsientos($viewName = 'ListAsiento'): void
    {
        $model = $this->getModel();
        if (false === $model->load($this->request->get('code'))) {
            return;
        }

        $this->addListView($viewName, 'Asiento', "accounting-entries", "fa-solid fa-balance-scale")
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false);

    }

    protected function createViewsRecibos(): void
    {
        $model = $this->getModel();
        if (false === $model->load($this->request->get('code'))) {
            return;
        }

        $loadModel = $model->amount > 0 ? 'ReciboCliente' : 'ReciboProveedor';
        $viewName = $model->amount > 0 ? 'ListReciboCliente' : 'ListReciboProveedor';
        $this->addListView($viewName, $loadModel, "receipts", "fa-solid fa-dollar-sign")
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false);
    }

    protected function loadData($viewName, $view)
    {
        $mvn = $this->getMainViewName();
        switch ($viewName) {
            case 'ListAsiento':
            case 'ListReciboCliente':
            case 'ListReciboProveedor':
                $where = [Where::column('idbankmovement', $this->getViewModelValue($mvn, 'id'))];
                $view->loadData('', $where);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }
}
