<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\ConciliacionBancaria\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Asiento;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\User;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class MovimientoBanco extends ModelClass
{
    use ModelTrait;

    /** @var float */
    public $amount;

    /** @var float */
    public $balance;

    /** @var string */
    public $codcuenta;

    /** @var string */
    public $creationdate;

    /** @var string */
    public $date;

    /** @var int */
    public $id;

    /** @var string */
    public $lastnick;

    /** @var string */
    public $lastupdate;

    /** @var string */
    public $nick;

    /** @var string */
    public $observations;

    /** @var bool */
    public $reconciled;

    public function clear(): void
    {
        parent::clear();
        $this->reconciled = false;
    }

    public function getAccountingEntries(): array
    {
        $where = [Where::column('idbankmovement', $this->id)];
        return Asiento::all($where);
    }

    public function getCuenta(): CuentaBanco
    {
        $cuenta = new CuentaBanco();
        $cuenta->load($this->codcuenta);
        return $cuenta;
    }

    public function getReceipts(): array
    {
        $where = [Where::column('idbankmovement', $this->id)];
        return ReciboCliente::all($where);
    }

    public function install(): string
    {
        new User();
        new CuentaBanco();
        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return "id";
    }

    public static function tableName(): string
    {
        return "cuentasbanco_movimientos";
    }

    public function test(): bool
    {
        $this->creationdate = $this->creationdate ?? Tools::dateTime();
        $this->nick = $this->nick ?? Session::user()->nick;
        $this->codcuenta = Tools::noHtml($this->codcuenta);
        $this->observations = Tools::noHtml($this->observations);

        return parent::test();
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        if ($type === 'list') {
            return $this->getCuenta()->url() . '&activetab=ListMovimientoBanco';
        }

        return parent::url($type, $list);
    }

    protected function saveUpdate(array $values = []): bool
    {
        $this->lastnick = Session::user()->nick;
        $this->lastupdate = Tools::dateTime();
        return parent::saveUpdate($values);
    }
}
