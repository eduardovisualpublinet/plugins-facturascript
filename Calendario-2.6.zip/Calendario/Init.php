<?php

namespace FacturaScripts\Plugins\Calendario;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Model\Role;
use FacturaScripts\Core\Model\RoleAccess;

/**
 * Summary of Init
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2023
 */
class Init extends InitClass
{
    const ROLE_NAME = 'Calendario';
    public function init(): void
    {
    }
    public function uninstall(): void
    {
    }

    public function update(): void
    {
        $this->createRoleForPlugin();
    }
    private function createRoleForPlugin(): void
    {
        $dataBase = new DataBase();
        $dataBase->beginTransaction();

        // creates the role if not exists
        $role = new Role();
        if (false === $role->load(self::ROLE_NAME)) {
            $role->codrole = $role->descripcion = self::ROLE_NAME;
            if (false === $role->save()) {
                // exit and rollback on fail
                $dataBase->rollback();
                return;
            }
        }

        // check the role permissions
        $controllerNames = [
            'Calendario'
        ];
        foreach ($controllerNames as $controllerName) {
            $roleAccess = new RoleAccess();
            $where = [
                new DataBaseWhere('codrole', self::ROLE_NAME),
                new DataBaseWhere('pagename', $controllerName)
            ];
            if ($roleAccess->loadWhere($where)) {
                // permission exists? the skip
                continue;
            }

            // creates the permission if not exists
            $roleAccess->allowdelete = true;
            $roleAccess->allowupdate = true;
            $roleAccess->codrole = self::ROLE_NAME;
            $roleAccess->pagename = $controllerName;
            $roleAccess->onlyownerdata = false;
            if (false === $roleAccess->save()) {
                // exit and rollback on fail
                $dataBase->rollback();
                return;
            }
        }

        // without problems = Commit
        $dataBase->commit();
    }
}
