<?php

namespace FacturaScripts\Plugins\Calendario\Lib;

use FacturaScripts\Plugins\VencimientosPeriodicos\Model\DocControl;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;


class VencimientoService implements EventoServiceInterface
{
    /**
     * Obtiene el nombre del objeto que este servicio maneja.
     *
     * @return string Nombre del objeto.
     */
    public function getHandledObject(): string
    {
        return '';
    }
    public function obtenerEventos(): array
    {
        $DocControl = new DocControl();
        $where = [
            new DataBaseWhere('status', '1,2',  'IN'), // Pendientes y vencidos
            new DataBaseWhere('procesado', NULL, 'IS'), // No procesados
            new DataBaseWhere('duedate', date('Y') . '-01-01', '>='), // Desde el 1 de enero del año actual
            new DataBaseWhere('duedate', date('Y-m-d', strtotime('31-12-' . (date('Y') + 1))), '<=') // Hasta el 31 de diciembre del próximo año
        ];

        foreach ($DocControl->all($where, ['duedate' => 'ASC'], 0, 0) as $value) {

            $isNextYear = date('Y', strtotime($value->duedate)) == (date('Y') + 1);
            $color = $isNextYear ? '#17a2b8' : '#DB7882'; // Azul para el próximo año, rojo para el actual

            [$title, $tipoDocName, $description] = explode(':', $value->getCustomerName());

            $eventos[] = [
                "title" => $title,
                "start" =>  strtotime($value->duedate) * 1000,
                'color' => $color,
                'url' => $value->url(),
                'allDay' => true,
                'tipo' => $tipoDocName,
                'description' => $description ?? '',
            ];
        }
        return $eventos;
    }
}
