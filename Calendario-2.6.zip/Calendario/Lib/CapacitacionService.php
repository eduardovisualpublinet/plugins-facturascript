<?php

namespace FacturaScripts\Plugins\Calendario\Lib;

use FacturaScripts\Plugins\CapacitacionPersonal\Model\Curso;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;


/**
 * Servicio que maneja los eventos del plugin CapacitacionPersonal.
 * @author Facundo Gonzalez <coregf@gmail.com>
 */
class CapacitacionService implements EventoServiceInterface
{
    /**
     * Obtiene el nombre del objeto que este servicio maneja.
     *
     * @return string Nombre del objeto.
     */
    public function getHandledObject(): string
    {
        return 'Curso';
    }
    /**
     * Obtiene los eventos del plugin CapacitacionPersonal.
     *
     * @return array Array de eventos formateados para el calendario.
     */
    public function obtenerEventos(): array
    {
        $cursos = new Curso();
        $where = [new DataBaseWhere('status', '0')];
        $cursos = $cursos->all($where, ['fecha' => 'ASC'], 0, 0);

        foreach ($cursos as $value) {
            $eventos[] = [
                "title" => $value->name,
                "start" =>  strtotime($value->fecha) * 1000,
                'color' => 'primary',
                'url' => $value->url(),
                'allDay' => true,
                'tipo' => 'Capacitación',
                'description' => !empty($value->observations) ? $value->observations : 'Capacitación',

            ];
        }

        return $eventos;
    }
}
