<?php

namespace FacturaScripts\Plugins\Calendario\Lib;


/**
 * Interfaz que define el contrato para los servicios de eventos.
 * @author Facundo Gonzalez <coregf@gmail.com>
 */
interface EventoServiceInterface
{
    /**
     * Obtiene los eventos para el calendario.
     *
     * @return array Array de eventos formateados para el calendario.
     */
    public function obtenerEventos(): array;

    /**
     * Obtiene el nombre del objeto que este servicio maneja.
     *
     * @return string Nombre del objeto (e.g., 'Turno').
     */
    public function getHandledObject(): string;
}
