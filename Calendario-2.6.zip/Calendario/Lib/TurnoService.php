<?php

namespace FacturaScripts\Plugins\Calendario\Lib;

use FacturaScripts\Dinamic\Model\Turno;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Base\Utils;
use FacturaScripts\Core\Tools;
use DateTime;

/**
 * Servicio que maneja los eventos del plugin Turnos.
 * @author Facundo Gonzalez <coregf@gmail.com>
 */
class TurnoService implements EventoServiceInterface
{
    /**
     * Obtiene el nombre del objeto que este servicio maneja.
     *
     * @return string Nombre del objeto.
     */
    public function getHandledObject(): string
    {
        return 'Turno';
    }
    /**
     * Obtiene los eventos del plugin Turnos.
     *
     * @return array Array de eventos formateados para el calendario.
     */
    public function obtenerEventos(): array
    {
        $eventos = [];
        $turnoModel = new Turno();

        // Definir condiciones para obtener turnos pendientes o próximos
        $where = [
            new DataBaseWhere('status', 'pendiente,proximo', 'IN')
        ];

        // Obtener todos los turnos que cumplan con las condiciones
        $turnos = $turnoModel->all($where, ['fechaturno' => 'ASC'], 0, 0);

        foreach ($turnos as $turno) {
            $eventos[] = [
                "title" => Tools::fixHtml($turno->getCustomerName()),
                "start" => strtotime($turno->fechaturno) * 1000, // Convertir a milisegundos
                "color" => '#17a2b8',
                "url" => $turno->url(),
                "allDay" => false,
                "tipo" => 'Turno',
                "description" => "{$turno->name}. {$turno->observation}",
            ];
        }

        return $eventos;
    }

    /**
     * Agrega un nuevo turno.
     *
     * @param array $data Datos del turno.
     * @return bool
     */
    public function add(array $data): bool
    {
        $fecha = $data['fecha'];
        $hora = $data['hora'];
        $codcliente = $data['codcliente'];
        $name = $data['name'];
        $observations = $data['observations'];

        // Validar y formatear la fecha
        $fechaDateTime = DateTime::createFromFormat('d/n/Y', $fecha);

        $fechaFormateada = $fechaDateTime->format('Y-m-d') . ' ' . $hora;

        $data = [
            'fechaturno' => $fechaFormateada,
            'codcliente' => $codcliente,
            'name' => $name,
            'observation' => $observations,
        ];
        // Validar y sanitizar los datos según sea necesario
        if (
            empty($data['fechaturno']) ||
            empty($data['codcliente']) ||
            empty($data['name'])
        ) {
            Tools::log()->error('Datos incompletos para crear un turno');
            return false;
        }

        $turno = new Turno($data);
        if ($turno->save()) {
            Tools::log()->notice('record-updated-correctly');
            return true;
        } else {
            Tools::log()->error('record-save-error');
            return false;
        }
    }
}
