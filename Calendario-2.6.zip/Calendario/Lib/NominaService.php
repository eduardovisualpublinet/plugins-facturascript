<?php

namespace FacturaScripts\Plugins\Calendario\Lib;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;

use FacturaScripts\Dinamic\Model\Employee;
use FacturaScripts\Dinamic\Model\Matricula;
use FacturaScripts\Dinamic\Model\AptoMedico;
use FacturaScripts\Core\Tools;

use DateTime;

/**
 * Servicio que maneja los eventos de Nomina.
 * @author Facundo Gonzalez <coregf@gmail.com>
 */
class NominaService implements EventoServiceInterface
{
    /**
     * Obtiene el nombre del objeto que este servicio maneja.
     *
     * @return string Nombre del objeto.
     */
    public function getHandledObject(): string
    {
        return '';
    }
    public function obtenerEventos(): array
    {
        // Obtener empleados activos
        $empleados = (new Employee())->all([new DataBaseWhere('dischargedate', null, 'IS')]);
        $anoActual = date('Y');

        // Pre-inicializar modelos para evitar instanciarlos en cada iteración
        $matriculaModel = new Matricula();
        $aptoMedicoModel = new AptoMedico();

        // Definir los años de antigüedad que se mostrarán
        $antMilestones = [5, 10, 15, 20, 25, 30];

        $eventos = []; // Inicializar el array de eventos

        foreach ($empleados as $emp) {
            // Calcular antigüedad
            $ant = $this->permanencia($emp, true);
            if (in_array($ant, $antMilestones)) {
                $fechaAnt = date('d-m-', strtotime($emp->fechaalta)) . $anoActual;

                $eventos[] = [
                    "title" => Tools::fixHtml("{$ant} año" . ($ant > 1 ? 's' : '') . " Antigüedad: {$emp->nombre}"),
                    "start" => strtotime("{$fechaAnt} 00:00:00") * 1000,
                    "end" => strtotime("{$fechaAnt} 23:59:59") * 1000,
                    "url" => $emp->url(),
                    "allDay" => true,
                    'tipo' => 'Antigüedad',
                    'description' => Tools::fixHtml("{$ant} año" . ($ant > 1 ? 's' : '')),
                ];
            }

            // Manejar cumpleaños
            if (!empty($emp->birthday)) {
                $diaCumple = date('d', strtotime($emp->birthday));
                $mesCumple = date('m', strtotime($emp->birthday));
                $fechaCumple = "{$diaCumple}-{$mesCumple}-{$anoActual}";

                // Cumpleaños actual
                $eventos[] = [
                    'title' => "Cumpleaños: {$emp->nombre}",
                    'start' => strtotime("{$fechaCumple} 00:00:00") * 1000,
                    'end' => strtotime("{$fechaCumple} 23:59:59") * 1000,
                    'url' => $emp->url(),
                    'color' => 'purple',
                    'allDay' => true,
                    'tipo' => 'Cumpleaños',
                    'description' => 'Cumpleaños',
                ];

                // Próximo año
                $fechaCumpleProxStart = strtotime("+1 year", strtotime("{$fechaCumple} 00:00:00")) * 1000;
                $fechaCumpleProxEnd = strtotime("+1 year", strtotime("{$fechaCumple} 23:59:59")) * 1000;

                $eventos[] = [
                    'title' => "Cumpleaños: {$emp->nombre}",
                    'start' => $fechaCumpleProxStart,
                    'end' => $fechaCumpleProxEnd,
                    'url' => $emp->url(),
                    'color' => 'purple',
                    'allDay' => true,
                    'tipo' => 'Cumpleaños',
                    'description' => 'Cumpleaños',
                ];
            }

            // Manejar matrículas vencidas
            $matriculaTipo1 = $matriculaModel->all([
                new DataBaseWhere('idemployee', $emp->id),
                new DataBaseWhere('status', '1,2,3', 'IN'),
                new DataBaseWhere('tipo', '1')
            ], ['enddate' => 'desc'], 0, 1);  // Obtener solo 1 registro del tipo 1

            $matriculaTipo2 = $matriculaModel->all([
                new DataBaseWhere('idemployee', $emp->id),
                new DataBaseWhere('status', '1,2,3', 'IN'),
                new DataBaseWhere('tipo', '2')
            ], ['enddate' => 'desc'], 0, 1);  // Obtener solo 1 registro del tipo 2

            // Combinar ambos resultados en un solo array
            $matriculas = array_merge($matriculaTipo1, $matriculaTipo2);

            if ($matriculas) {
                $tipoName = [1 => 'Nacional', 2 => 'Provincial'];
                foreach ($matriculas as $matricula) {
                    $enddate = $matricula->enddate;
                    $eventos[] = [
                        'title' => "Ven. Matr.: {$emp->nombre} ({$tipoName[$matricula->tipo]})",
                        'start' => strtotime("{$enddate} 00:00:00") * 1000,
                        'end' => strtotime("{$enddate} 23:59:59") * 1000,
                        'url' => $emp->url(),
                        'color' => 'red',  // Diferenciar por tipo
                        'allDay' => true,
                        'tipo' => "Matrícula {$tipoName[$matricula->tipo]}",
                        'description' => "Vencimiento Matrícula Tipo {$tipoName[$matricula->tipo]}",
                    ];
                }
            }


            // Manejar aptos médicos
            $aptos = $aptoMedicoModel->all([
                new DataBaseWhere('idemployee', $emp->id),
                new DataBaseWhere('status', '1,2,3', 'IN'),
            ], ['enddate' => 'desc'], 0, 1);

            if ($aptos) {
                $enddate = $aptos[0]->enddate;
                $eventos[] = [
                    'title' => "Ven. Apto Médico: {$emp->nombre}",
                    'start' => strtotime("{$enddate} 00:00:00") * 1000,
                    'end' => strtotime("{$enddate} 23:59:59") * 1000,
                    'url' => $emp->url(),
                    'color' => 'red',
                    'allDay' => true,
                    'tipo' => 'Apto Médico',
                    'description' => 'Vencimiento Apto Médico',
                ];
            }
        }

        return $eventos;
    }

    public function permanencia($obj, $retornarAnos = false)
    {
        // Determinar la fecha de fin: fecha de alta o 'today' si no está presente
        $fin = $obj->dischargedate ?? 'today';

        // Crear objetos DateTime para la fecha de inicio y fin
        $inicio = new DateTime($obj->fechaalta);
        $final = new DateTime($fin);

        // Calcular la diferencia entre las fechas
        $diff = $inicio->diff($final);
        $y = $diff->y;
        $m = $diff->m;
        $d = $diff->d;

        // Si se solicita solo los años, retornar el número de años
        if ($retornarAnos) {
            return "{$y}";
        }

        // Construir la cadena de permanencia
        $perm = '';

        if ($y) {
            $perm .= "{$y} año" . ($y > 1 ? 's ' : ' ');
        }

        if ($m) {
            $perm .= "{$m} mes" . ($m > 1 ? 'es ' : ' ');
        }

        if ($d) {
            $perm .= "{$d} día" . ($d > 1 ? 's ' : ' ');
        }

        // Retornar la cadena de permanencia sin espacios al final
        return trim($perm);
    }
}
