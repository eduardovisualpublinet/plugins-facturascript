<?php

namespace FacturaScripts\Plugins\Calendario\Lib;

/**
 *
 * @author Facundo Gonzalez <coregf@gmail.com>
 *
 */
class ServiceProvider
{

    /**
     * Mapa que relaciona nombres de plugins con sus servicios correspondientes.
     *
     * @var array
     */
    protected $serviceMap = [
        'Turnos' => TurnoService::class,
        'CapacitacionPersonal' => CapacitacionService::class,
        'VencimientosPeriodicos' => VencimientoService::class,
        'FunExtrasNomina' => NominaService::class,
    ];

    /**
     * Registra los servicios de eventos disponibles basados en plugins activos.
     *
     * @param array $activePlugins Lista de nombres de plugins activos.
     * @return EventoServiceInterface[] Array de servicios de eventos activos.
     */
    public function registrarServicios(array $activePlugins): array
    {
        $services = [];

        foreach ($this->serviceMap as $pluginName => $serviceClass) {
            if (in_array($pluginName, $activePlugins)) {
                // Instanciar el servicio y añadirlo al array de servicios
                $services[] = new $serviceClass();
            }
        }

        return $services;
    }

    /**
     * Obtiene el servicio que maneja un objeto específico.
     *
     * @param string $object Nombre del objeto (e.g., 'Turno').
     * @param EventoServiceInterface[] $services Array de servicios registrados.
     * @return EventoServiceInterface|null Servicio correspondiente o null si no existe.
     */
    public function getServiceByObject(string $object, array $services): ?EventoServiceInterface
    {
        foreach ($services as $service) {
            if ($service->getHandledObject() === $object) {
                return $service;
            }
        }
        return null;
    }
}
