<?php
namespace FacturaScripts\Plugins\Calendario;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Tools;

/**
 * Summary of Cron
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2023
 */
class Cron extends CronClass
{
    public function run(): void
    {

    }
}

