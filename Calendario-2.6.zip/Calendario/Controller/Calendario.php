<?php

namespace FacturaScripts\Plugins\Calendario\Controller;

use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\AssetManager;
use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Plugins\Calendario\Lib\EventoServiceInterface;
use FacturaScripts\Plugins\Calendario\Lib\ServiceProvider;
use FacturaScripts\Plugins\Calendario\Lib\TraitCalendario;

/**
 * @author Facundo Gonzalez <coregf@gmail.com>
 */

class Calendario extends Controller
{
    use TraitCalendario;
    public $activatedPlugins;
    public $modalTurno = false;

    /**
     * @var EventoServiceInterface[] Array de servicios de eventos.
     */
    protected $eventoServices = [];

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["menu"] = "Agenda";
        $data["title"] = "Calendario";
        $data["icon"] = "fa-solid fa-calendar-alt";
        return $data;
    }

    /**
     * Carga los servicios de eventos registrados basados en plugins activos.
     *
     * @return void
     */
    protected function cargarServiciosDeEventos(): void
    {
        $this->pluginsEnabled();
        // Instanciar el ServiceProvider
        $provider = new ServiceProvider();

        // Registrar los servicios basados en plugins activos
        $this->eventoServices = $provider->registrarServicios($this->activatedPlugins);
    }

    /**
     * Obtiene todos los eventos de los servicios registrados.
     *
     * @return void
     */
    public function getEventos(): void
    {
        $eventos = [];

        foreach ($this->eventoServices as $service) {
            $eventos = array_merge($eventos, $service->obtenerEventos());
        }

        echo json_encode($eventos);
    }
    public function privateCore(&$response, $user, $permissions)
    {

        parent::privateCore($response, $user, $permissions);
        $this->cargarServiciosDeEventos();
        AssetManager::add('js', FS_ROUTE . '/node_modules/jquery-ui-dist/jquery-ui.min.js');


        $action = $this->request->request->get('action', false);
        switch ($action) {
            case 'autocomplete':
                $this->setTemplate(false);
                $results = $this->autocompleteAction();
                $this->response->setContent(json_encode($results));
                return false;

            case 'add':
                if (false === $this->permissions->allowUpdate) {
                    Tools::log()->warning('not-allowed-modify');
                    return false;
                } elseif (false === $this->validateFormToken()) {
                    return false;
                }
                $this->handleAdd();


            default:
                # code...
                break;
        }
        if (in_array('Turnos', $this->activatedPlugins)) {
            $this->modalTurno = true;
        }
    }

    protected function handleAdd(): bool
    {
        // Obtener el nombre del objeto a agregar
        $object = $this->request->request->get('object', false);
        if (!$object) {
            Tools::log()->error('Objeto no especificado para agregar');
            return false;
        }

        $serviceProvider = new ServiceProvider();

        // Obtener el servicio correspondiente al objeto
        $service = $serviceProvider->getServiceByObject($object, $this->eventoServices);
        if (!$service) {
            Tools::log()->error("No existe un servicio para el objeto '{$object}'");
            return false;
        }

        if ($service->add($this->request->request->all())) {
            return true;
        } else {
            // El servicio ya maneja los logs de error
            return false;
        }
    }
}
