# TarifasAvanzadas
Amplía las opciones de tarifas en productos y familias.
- https://facturascripts.com/plugins/tarifasavanzadas

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **TarifasAvanzadas**.
