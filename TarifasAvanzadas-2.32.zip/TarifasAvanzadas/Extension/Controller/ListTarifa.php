<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TarifasAvanzadas\Extension\Controller;

use Closure;

/**
 * Description of ListTarifa
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class ListTarifa
{
    public function createViews(): Closure
    {
        return function () {
            $familias = $this->codeModel->all('familias', 'codfamilia', 'descripcion');
            $grupos = $this->codeModel->all('gruposclientes', 'codgrupo', 'nombre');

            $this->addView('ListDescuentoCliente', 'DescuentoCliente', 'discounts', 'fa-solid fa-tags')
                ->addSearchFields(['observaciones', 'referencia'])
                ->addOrderBy(['fecha0'], 'from-date')
                ->addOrderBy(['fecha1'], 'until-date')
                ->addOrderBy(['porcentaje'], 'percentage')
                ->addOrderBy(['prioridad'], 'priority', 2)
                ->addOrderBy(['referencia'], 'reference')
                ->addFilterPeriod('fecha0', 'from-date', 'fecha0')
                ->addFilterPeriod('fecha1', 'until-date', 'fecha1')
                ->addFilterSelect('codfamilia', 'family', 'codfamilia', $familias)
                ->addFilterSelect('codgrupo', 'group', 'codgrupo', $grupos)
                ->addFilterCheckbox('acumular', 'accumulate-discount');
        };
    }
}
