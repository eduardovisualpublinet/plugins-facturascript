<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TarifasAvanzadas\Extension\Controller;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;

/**
 * Description of EditCliente
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class EditCliente
{
    public function createViews(): Closure
    {
        return function () {
            $this->addEditListView('EditDescuentoCliente', 'DescuentoCliente', 'discounts', 'fa-solid fa-tags')
                ->disableColumn('customer')
                ->disableColumn('customer-group');
        };
    }

    public function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName === 'EditDescuentoCliente') {
                $code = $this->getViewModelValue($this->getMainViewName(), 'codcliente');
                $where = [new DataBaseWhere('codcliente', $code)];
                $view->loadData('', $where, ['prioridad' => 'DESC', 'id' => 'DESC']);
            }
        };
    }
}
