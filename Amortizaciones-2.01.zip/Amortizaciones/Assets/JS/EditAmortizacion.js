/**
 * This file is part of Amortizaciones plugin for FacturaScripts.
 * FacturaScripts  Copyright (C) 2015-2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 * Amortizaciones  Copyright (C) 2023-2024 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */

"use strict";

/**
 * Obtiene datos de la factura y actualiza los campos valor y divisa.
 *
 * @param {Event} event
 */
function setAmountFromInvoice(event) {
    const data = new FormData();
    data.append("action", "invoice-data");
    data.append("invoice", event.target.value);

    fetch(window.location.href, {
        method: "POST",
        body: data
    }).then(response => {
        if (!response.ok) {
            throw new Error(response.status + " " + response.statusText);
        }
        return response.json();
    }).then(result => {
        const valorInput = document.querySelector('input[name="valor"]');
        const divisaSelect = document.querySelector('select[name="coddivisa"]');

        if (valorInput) valorInput.value = result.base;
        if (divisaSelect) divisaSelect.value = result.divisa;
    }).catch(error => {
        alert(error.message);
    });
}


/**
 * Main process
 *   - Set event listener for invoice field to get invoice amount.
 */
document.addEventListener("DOMContentLoaded", function () {
    const invoice = document.querySelector('input[data-field="idfactura"]');
    if (invoice) {
        invoice.addEventListener("change", setAmountFromInvoice, false);
    }
});