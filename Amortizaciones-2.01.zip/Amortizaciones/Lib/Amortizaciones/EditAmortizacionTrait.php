<?php
/**
 * This file is part of Amortizaciones plugin for FacturaScripts.
 * FacturaScripts  Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * Amortizaciones  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\Amortizaciones\Lib\Amortizaciones;

use Exception;
use FacturaScripts\Core\Lib\AssetManager;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Amortizacion;

/**
 * Auxiliar code for EditAmortizacion Controller.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
trait EditAmortizacionTrait
{
    /**
     * Add main buttons to the controller.
     *
     * @param Amortizacion $model
     * @param bool $hasLines
     * @throws Exception
     */
    private function addMainButtons(Amortizacion $model, bool $hasLines): void
    {
        $isBanking = $model->tipo === Amortizacion::TYPE_BANKING;
        $mvn = $this->getMainViewName();
        if (false === $hasLines) {
            $this->addButton($mvn, [
                'action' => 'generate',
                'label' => 'create-plan',
                'color' => 'info',
                'icon' => 'fa-solid fa-cogs',
                'type' => $isBanking ? 'action' : 'modal',
                'confirm' => $isBanking ? 'true' : 'false',
            ]);
        }

        if (false === $isBanking) {
            $this->addButton($mvn, [
                'action' => 'sell',
                'label' => 'sell',
                'color' => 'danger',
                'icon' => 'fa-solid fa-donate',
                'type' => 'modal',
            ]);

            $this->addButton($mvn, [
                'action' => 'finalize',
                'label' => 'end-useful-life',
                'color' => 'danger',
                'icon' => 'fa-regular fa-calendar-times',
                'type' => 'modal',
            ]);
        }
    }

    /**
     * Add accounting view to the controller.
     */
    private function createViewsAccounts(): void
    {
        $this->addEditView(self::VIEW_ACCOUNTS, 'Amortizacion', 'subaccounts', 'fa-solid fa-book')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add accounting view to the controller.
     */
    private function createViewsAccountsBank(): void
    {
        $this->addEditView(self::VIEW_ACCOUNTS_BANK, 'Amortizacion', 'subaccounts', 'fa-solid fa-book')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add contabilization view to the controller.
     */
    private function createViewsDetail(): void
    {
        $this->addEditView(self::VIEW_AMORTIZATION, 'Amortizacion', 'contabilization', 'fa-solid fa-sitemap')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add contabilization view to the controller.
     */
    private function createViewsDetailBank(): void
    {
        $this->addEditView(self::VIEW_AMORTIZATION_BANK, 'Amortizacion', 'contabilization', 'fa-solid fa-sitemap')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add amortization plan view to the controller.
     *
     * @param string $viewName
     */
    private function createViewLines(string $viewName = self::VIEW_LINES): void
    {
        $this->addListView($viewName, 'LineaAmortizacion', 'lines')
            ->setSettings('clickable', false)
            ->setSettings('modalInsert', 'insertline')
            ->disableColumn('amortization')
            ->disableColumn('description');

        AssetManager::add('js', Tools::config('route') . '/Dinamic/Assets/JS/' . $viewName . '.js');
    }

    /**
     * Add notes view to the controller.
     *
     * @param string $viewName
     */
    private function createViewsNote(string $viewName = self::VIEW_NOTE): void
    {
        $this->addEditView($viewName, 'Amortizacion', 'notes', 'fa-solid fa-sticky-note')
            ->setSettings('btnDelete', false);
    }

    /**
     * Configure the views depending on the amortization type.
     *   - if the amortization has no lines, remove the amortization plan view.
     *   - If the amortization has lines, the amortization data is disabled or readonly.
     *   - If the amortization is banking, show the banking columns.
     *
     * @param bool $hasLines
     */
    private function setStatusToViews(bool $hasLines): void
    {
        if (false === $hasLines) {
            unset($this->views[self::VIEW_LINES]);
            return;
        }

        $viewDetail = isset($this->views[self::VIEW_AMORTIZATION])
            ? self::VIEW_AMORTIZATION
            : self::VIEW_AMORTIZATION_BANK;

        $this->views[$viewDetail]->setReadOnly(true);
        $viewMain = $this->views[$this->getMainViewName()];
        $viewMain->disableColumn('type', false, 'true')
            ->disableColumn('start-date', false, 'true')
            ->disableColumn(
                'company',
                ($this->empresa->count() < 2),
                'true'
            );

        if ($viewMain->model->tipo === Amortizacion::TYPE_BANKING) {
            $viewLines = $this->views[self::VIEW_LINES];
            $totalColumn = $viewLines->columnForField('capital');
            if ($totalColumn) {
                $totalColumn->display = 'right';
            }
            $interestColumn = $viewLines->columnForField('interes');
            if ($interestColumn) {
                $interestColumn->display = 'right';
            }
        }
    }
}
