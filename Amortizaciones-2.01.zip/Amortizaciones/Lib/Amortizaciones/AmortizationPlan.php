<?php
/**
 * This file is part of Amortizaciones plugin for FacturaScripts.
 * FacturaScripts  Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * Amortizaciones  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\Amortizaciones\Lib\Amortizaciones;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Amortizacion;

/**
 * Class for creating the amortization plan.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class AmortizationPlan
{
    /**
     * Create the depreciation plan for the fixed assets.
     *
     * @param array $params
     */
    public static function exec(array $params): void
    {
        $amortizationPlan = new self();
        $id = $params['idamortizacion'] ?? 0;
        $amortization = new Amortizacion();
        if (false === $amortization->load($id)) {
            return;
        }

        $controller = $amortizationPlan->getController($amortization);
        if (false === isset($controller) || false === $controller->checkData($params)) {
            return;
        }

        $database = new DataBase();
        $database->beginTransaction();
        try {
            if ($controller->createAmortizationPlan($amortization)) {
                $database->commit();
                Tools::log()->notice('record-updated-correctly');
            }
        } finally {
            if ($database->inTransaction()) {
                $database->rollback();
                Tools::log()->error('amortization-plan-error');
            }
        }
    }

    /**
     * @param Amortizacion $amortizacion
     * @return AmortizationConstant|AmortizationBank|null
     */
    protected function getController(Amortizacion $amortizacion): AmortizationBank|AmortizationConstant|null
    {
        return match ($amortizacion->tipo) {
            Amortizacion::TYPE_CONSTANT => new AmortizationConstant($amortizacion),
            Amortizacion::TYPE_BANKING => new AmortizationBank($amortizacion),
            default => null,
        };
    }
}
