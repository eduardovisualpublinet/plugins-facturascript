<?php
/**
 * This file is part of Amortizaciones plugin for FacturaScripts.
 * FacturaScripts  Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * Amortizaciones  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\Amortizaciones\Controller;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Dinamic\Lib\Accounting\AmortizationPlanToAccounting;

/**
 * Controller for Amortize model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ListAmortizacion extends ListController
{
    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'amortization';
        $pageData['icon'] = 'fa-solid fa-piggy-bank';
        $pageData['menu'] = 'accounting';
        return $pageData;
    }

    /**
     * Load views
     *
     * @throws Exception
     */
    protected function createViews()
    {
        $this->createViewAmortization();
        $this->createViewAmortizationPending();
        $this->createViewAmortizationTemplate();
        $this->createViewAmortizationTable();
        $this->createViewAmortizationSubAccount();
    }

    /**
     * @param $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'contabilize':
                if ($this->validateFormToken()) {
                    $codes = $this->request->request->getArray('codes');
                    AmortizationPlanToAccounting::exec($codes);
                }
                return true;

            default:
                return parent::execPreviousAction($action);
        }
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'ListLineaAmortizacion':
                $where = [
                    new DataBaseWhere('ano', date('Y'), '<='),
                    new DataBaseWhere('idasiento', null),
                ];
                $view->loadData('', $where);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    /**
     * Create the amortization view List.
     *
     * @param string $viewName
     */
    private function createViewAmortization(string $viewName = 'ListAmortizacion'): void
    {
        $this->addView($viewName, 'Join\Amortizacion', 'amortization', 'fa-solid fa-piggy-bank')
            // Search and Order
            ->addSearchFields(['amortizaciones.descripcion'])
            ->addOrderBy(['amortizaciones.idamortizacion'], 'code')
            ->addOrderBy(['amortizaciones.descripcion'], 'description')
            // Filters
            ->addFilterPeriod('date', 'date', 'fechainicio')
            ->addFilterNumber('residual-1', 'residual', 'residual')
            ->addFilterNumber('residual-2', 'residual', 'residual', '<=');

        // disable company column if there is only one company
        $companies = Empresas::codeModel();
        if (count($companies) > 2) {
            $this->addFilterSelect($viewName, 'idempresa', 'company', 'amortizaciones.idempresa', $companies);
            $this->views[$viewName]->disableColumn('company', false);
        }
    }

    /**
     * Create the view for pending amortizations.
     *
     * @param string $viewName
     * @throws Exception
     */
    private function createViewAmortizationPending(string $viewName = 'ListLineaAmortizacion'): void
    {
        $this->addView($viewName, 'LineaAmortizacion', 'pending', 'fa-solid fa-list')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('clickable', false)
            ->addOrderBy(['ano', 'periodo', 'idamortizacion'], 'period')
            ->addOrderBy(['idamortizacion', 'ano', 'periodo'], 'amortization')
            ->addFilterPeriod('date', 'date', 'fecha')
            ->addFilterAutocomplete('amortization', 'amortization', 'idamortizacion', 'amortizaciones', 'idamortizacion', 'descripcion');

        $this->addButton($viewName, [
            'action' => 'contabilize',
            'label' => 'contabilization',
            'color' => 'warning',
            'icon' => 'fa-solid fa-cogs',
            'confirm' => true,
        ]);
    }

    /**
     * Create the view for amortization tables.
     *
     * @param string $viewName
     */
    private function createViewAmortizationTable(string $viewName = 'ListAmortizacionTabla'): void
    {
        $this->addView($viewName, 'AmortizacionTabla', 'legal-periods', 'fa-solid fa-list-alt')
            ->addSearchFields(['name']);
    }

    /**
     * Create the view for amortization templates.
     *
     * @param string $viewName
     */
    private function createViewAmortizationTemplate(string $viewName = 'ListAmortizacionPlantilla'): void
    {
        $this->addView($viewName, 'AmortizacionPlantilla', 'templates', 'fa-solid fa-paste')
            ->addSearchFields(['name'])
            ->addOrderBy(['id'], 'code')
            ->addOrderBy(['name', 'id'], 'description', 1);
    }

    /**
     * Create the view for amortization subaccounts.
     *
     * @param string $viewName
     */
    private function createViewAmortizationSubAccount(string $viewName = 'ListAmortizacionSubcuenta'): void
    {
        $this->addView($viewName, 'AmortizacionSubcuenta', 'accounts', 'fa-solid fa-list-alt')
            ->addSearchFields(['code']);
    }
}
