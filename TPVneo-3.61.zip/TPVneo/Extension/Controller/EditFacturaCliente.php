<?php
/**
 * Copyright (C) 2023 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Extension\Controller;

use FacturaScripts\Plugins\TPVneo\Extension\Traits\TPVneoControllerSalesTrait;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditFacturaCliente
{
    use TPVneoControllerSalesTrait;
}
