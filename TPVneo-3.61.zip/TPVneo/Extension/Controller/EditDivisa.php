<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Extension\Controller;

use Closure;
use FacturaScripts\Core\Where;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditDivisa
{
    public function createViews(): Closure
    {
        return function () {
            $this->setTabsPosition('bottom');
            $this->createViewsCoin();
        };
    }

    protected function createViewsCoin(): Closure
    {
        return function (string $viewName = 'EditDivisaCoin') {
            $this->addEditListView($viewName, 'TpvCoin', 'coins', 'fa-solid fa-coins');
        };
    }

    protected function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName == 'EditDivisaCoin') {
                $where = [Where::column('coddivisa', $this->request->query->get('code'))];
                $view->loadData('', $where);
            }
        };
    }
}