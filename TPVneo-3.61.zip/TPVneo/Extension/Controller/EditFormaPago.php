<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Extension\Controller;

use Closure;
use FacturaScripts\Core\Where;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditFormaPago
{
    public function createViews(): Closure
    {
        return function () {
            $this->setTabsPosition('bottom');

            $this->createViewsTpv();
        };
    }

    protected function createViewsTpv(): Closure
    {
        return function (string $viewName = 'EditTpvPago') {
            $this->addEditListView($viewName, 'TpvPago', 'pos-terminal', 'fa-solid fa-cash-register')
                ->disableColumn('payment-method')
                ->setInLine(true);
        };
    }

    protected function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName == 'EditTpvPago') {
                $where = [Where::column('codpago', $this->request->query->get('code'))];
                $view->loadData('', $where);
            }
        };
    }
}
