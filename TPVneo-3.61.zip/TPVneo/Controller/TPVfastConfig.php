<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\Base\ControllerPermissions;
use FacturaScripts\Core\KernelException;
use FacturaScripts\Core\Response;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\TicketPrinter;
use FacturaScripts\Dinamic\Model\TpvTerminal;
use FacturaScripts\Dinamic\Model\User;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class TPVfastConfig extends Controller
{
    /** @var TicketPrinter */
    public $printer;

    public function getAppKey(): string
    {
        return $this->printer ? $this->printer->apikey : '';
    }

    public function getAppUrl(): string
    {
        return Tools::siteUrl();
    }

    public function getPageData(): array
    {
        $page = parent::getPageData();
        $page['title'] = 'fast-tpv-config';
        $page['menu'] = 'sales';
        $page['icon'] = 'fa-solid fa-wand-magic-sparkles';
        $page['showonmenu'] = false;
        return $page;
    }

    /**
     * @param Response $response
     * @param User $user
     * @param ControllerPermissions $permissions
     * @throws KernelException
     */
    public function privateCore(&$response, $user, $permissions)
    {
        parent::privateCore($response, $user, $permissions);

        $action = $this->request->request->get('action');
        if ($action === 'fast-config') {
            $this->fastConfigAction();
        }
    }

    protected function fastConfigAction(): void
    {
        if (false === $this->validateFormToken()) {
            return;
        }

        // si ya hay terminales, redirigimos a TPVneo
        $terminal = new TpvTerminal();
        if ($terminal->count() > 0) {
            Tools::log()->warning('tpv-terminal-already-exists');
            $this->redirect('TPVneo');
            return;
        }

        // si no hay clientes, creamos el cliente contado
        $cliente = new Cliente();
        if ($cliente->count() === 0) {
            $cliente->cifnif = '00000000-A';
            $cliente->nombre = 'Contado';
            $cliente->save();
        } else {
            foreach ($cliente->all() as $cli) {
                // seleccionamos el primero que encontremos
                $cliente = $cli;
                break;
            }
        }

        // si no hay una impresora, creamos una
        $this->printer = new TicketPrinter();
        if ($this->printer->count() === 0) {
            $this->printer->name = 'TPV';
            $this->printer->nick = $this->user->nick;
            $this->printer->save();
        } else {
            foreach ($this->printer->all() as $imp) {
                // seleccionamos la primera que encontremos
                $this->printer = $imp;
                break;
            }
        }

        // creamos la terminal
        $terminal->codcliente = $cliente->codcliente;
        $terminal->idprinter = $this->printer->id;
        $terminal->name = 'Terminal 1';
        $terminal->ticketformat = 'Normal';
        if ($terminal->save()) {
            Tools::log()->notice('record-updated-correctly');
            $this->setTemplate('TPVfastConfig/success');
            return;
        }

        Tools::log()->warning('tpv-terminal-not-created');
    }
}
