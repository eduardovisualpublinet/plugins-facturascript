<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Controller;

use FacturaScripts\Core\DataSrc\Agentes;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\Tickets\BoxClosure;
use FacturaScripts\Dinamic\Lib\TPVneo\SaleTicket;
use FacturaScripts\Dinamic\Model\TpvCaja;
use FacturaScripts\Dinamic\Model\TpvTerminal;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditTpvTerminal extends EditController
{
    public function getModelClassName(): string
    {
        return 'TpvTerminal';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["title"] = "pos-terminal";
        $data["icon"] = "fa-solid fa-cash-register";
        return $data;
    }

    protected function closeBoxAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (empty($codes)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        foreach ($codes as $code) {
            $caja = new TpvCaja();
            if (false === $caja->load($code) || $caja->fechafin !== null) {
                continue;
            }

            $caja->close(0);
            if (false === $caja->save()) {
                Tools::log()->warning('record-save-error');
                return true;
            }

            Tools::log()->notice('record-updated-correctly');
        }

        return true;
    }

    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        $this->createViewsBoxes();
        $this->createViewsDocs();
        $this->createViewsBudgets();
        $this->createViewsAgents();
        $this->createViewsPayments();
        $this->createViewsHtml();
    }

    protected function createViewsAgents(string $viewName = 'EditTpvAgente'): void
    {
        $this->addEditListView($viewName, 'TpvAgente', 'agents', 'fa-solid fa-user-tie')
            ->disableColumn('pos-terminal')
            ->setInLine(true);
    }

    protected function createViewsBoxes(string $viewName = 'ListTpvCaja'): void
    {
        $this->addListView($viewName, 'TpvCaja', 'boxes', 'fa-solid fa-box')
            ->addSearchFields(['observaciones'])
            ->addOrderBy(['idcaja'], 'code', 2)
            ->addOrderBy(['fechaini'], 'start-date')
            ->addOrderBy(['fechafin'], 'end-date')
            ->addFilterPeriod('fechaini', 'start-date', 'fechaini')
            ->addFilterPeriod('fechafin', 'end-date', 'fechafin')
            ->addFilterNumber('income', 'income', 'ingresos', '>=')
            ->addFilterCheckbox('box', 'opened', 'fechafin', 'IS', null)
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('btnPrint', true);

        $this->addButton($viewName, [
            'action' => 'print-box-closure',
            'color' => 'light',
            'icon' => 'fa-solid fa-print',
            'title' => 'print-box-closure',
            'type' => 'action'
        ]);

        // si es administrador, añadimos el botón cerrar caja y recalcular
        if ($this->user->admin) {
            $this->addButton($viewName, [
                'action' => 'close-box',
                'color' => 'warning',
                'confirm' => true,
                'icon' => 'fa-solid fa-lock',
                'title' => 'close-box'
            ]);
            $this->addButton($viewName, [
                'action' => 'recalculate-box',
                'color' => 'info',
                'icon' => 'fa-solid fa-calculator',
                'title' => 'recalculate-box'
            ]);
        }
    }

    protected function createViewsBudgets(string $viewName = 'ListTpvPresupuesto'): void
    {
        $this->addListView($viewName, 'PresupuestoCliente', 'estimations', 'fa-regular fa-file-powerpoint')
            ->setSettings($viewName, 'btnNew', false);

        // filtros
        $this->setOptionsFilters($viewName);
    }

    protected function createViewsDocs(string $viewName = 'ListTpvDoc'): void
    {
        $this->addListView($viewName . '-1', 'FacturaCliente', 'invoices', 'fa-solid fa-file-invoice-dollar fa-fw')
            ->setSettings($viewName, 'btnNew', false);

        $this->addListView($viewName . '-2', 'AlbaranCliente', 'delivery-notes', 'fa-solid fa-dolly-flatbed')
            ->setSettings($viewName, 'btnNew', false);

        // filtros
        $this->setOptionsFilters($viewName . '-1');
        $this->setOptionsFilters($viewName . '-2');
    }

    protected function createViewsPayments(string $viewName = 'EditTpvPago'): void
    {
        $this->addEditListView($viewName, 'TpvPago', 'payment-methods', 'fa-solid fa-credit-card')
            ->disableColumn('pos-terminal')
            ->setInLine(true);
    }

    protected function createViewsHtml(string $viewName = 'HtmlView'): void
    {
        $this->addHtmlView($viewName, 'Tab/mc20printerWs', 'TpvTerminal', 'print', 'fa-solid fa-print');
    }

    protected function execPreviousAction($action)
    {
        return match ($action) {
            'close-box' => $this->closeBoxAction(),
            'recalculate-box' => $this->recalculateBoxAction(),
            'print-box-closure' => $this->printBoxClosureAction(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $mvn = $this->getMainViewName();
        $id = $this->getViewModelValue($mvn, 'idtpv');

        switch ($viewName) {
            case 'EditTpvAgente':
            case 'EditTpvPago':
                $this->loadMethodPayments($mvn, $view);
            case 'ListTpvCaja':
            case 'ListTpvPresupuesto':
            case 'ListTpvDoc-1':
            case 'ListTpvDoc-2':
                $where = [Where::column('idtpv', $id)];
                $view->loadData('', $where);
                break;

            default:
                parent::loadData($viewName, $view);
                $this->loadTicketFormats($view);
                break;
        }
    }

    protected function loadMethodPayments(string $mvn, BaseView $view): void
    {
        $column = $view->columnForName('payment-method');
        if ($column && $column->widget->getType() === 'select') {
            $where = [Where::column('idempresa', $this->getViewModelValue($mvn, 'idempresa'))];
            $customValues = $this->codeModel->all('formaspago', 'codpago', 'descripcion', false, $where);
            $column->widget->setValuesFromCodeModel($customValues);
        }
    }

    protected function loadTicketFormats(BaseView $view): void
    {
        $column = $view->columnForName('ticket-format');
        if ($column && $column->widget->getType() === 'select') {
            $customValues = [];
            foreach (SaleTicket::loadFormats($view->model->doctype) as $format) {
                $customValues[] = [
                    'value' => $format['nameFile'],
                    'title' => Tools::trans(strtolower($format['label']))
                ];
            }
            $column->widget->setValuesFromArray($customValues, false, false);
        }
    }

    protected function recalculateBoxAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        if (empty($codes)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        foreach ($codes as $code) {
            $box = new TpvCaja();
            if ($box->load($code)) {
                $box->save();
            }
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function printBoxClosureAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $terminal = $this->getModel();
        if (false === $terminal->load($this->request->query->get('code', ''))
            || empty($terminal->idprinter)) {
            return true;
        }

        $codes = $this->request->request->getArray('codes');
        if (false === is_array($codes)) {
            return true;
        }

        if (empty($codes)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        foreach ($codes as $code) {
            $box = new TpvCaja();
            if (false === $box->load($code)) {
                continue;
            } elseif (empty($box->fechafin)) {
                Tools::log()->warning('box-not-closed', ['%date%' => $box->fechaini]);
                continue;
            }

            BoxClosure::print($box);
        }

        return true;
    }

    protected function selectAction(): array
    {
        $data = $this->requestGet(['field', 'fieldcode', 'fieldfilter', 'fieldtitle', 'formname', 'source', 'term']);

        if ($data['field'] !== 'ticketformat' && $data['field'] !== 'payment-method') {
            return parent::selectAction();
        }

        $results = [];
        foreach (SaleTicket::loadFormats($data['term']) as $format) {
            $results[] = ['key' => $format['nameFile'], 'value' => Tools::trans(strtolower($format['label']))];
        }
        return $results;
    }

    protected function setOptionsFilters($viewName): void
    {
        $this->listView($viewName)
            ->addSearchFields(['codigo', 'nombrecliente', 'numero2', 'observaciones'])
            ->addOrderBy(['fecha', 'hora'], 'date', 2)
            ->addOrderBy(['codigo'], 'code')
            ->addOrderBy(['codagente'], 'agent')
            ->addOrderBy(['nombrecliente'], 'customer')
            ->addOrderBy(['total'], 'total')
            ->addFilterPeriod('date', 'date', 'fecha')
            ->addFilterNumber('min-total', 'total', 'total', '>=')
            ->addFilterNumber('max-total', 'total', 'total', '<=')
            ->addFilterSelect('codagente', 'agent', 'codagente', Agentes::codeModel())
            ->addFilterSelect('codpago', 'payment-method', 'codpago', FormasPago::codeModel());
    }
}
