<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Lib\Tickets;

use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Agente;
use FacturaScripts\Dinamic\Model\Ticket;
use FacturaScripts\Dinamic\Model\TicketPrinter;
use FacturaScripts\Dinamic\Model\TpvCaja;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Plugins\Tickets\Lib\Tickets\BaseTicket;

class BoxClosure extends BaseTicket
{
    use ExtensionsTrait;

    public static function print(ModelClass $model, TicketPrinter $printer, User $user, Agente $agent = null): bool
    {
        if (empty($model->fechafin)) {
            return false;
        }

        static::init();

        $ticket = new Ticket();
        $ticket->idprinter = $printer->id;
        $ticket->nick = $user->nick;
        $ticket->title = self::$i18n->trans('box-closure');

        if ($agent) {
            $ticket->codagente = $agent->codagente;
        }

        //static::setHeader($model, $printer, $ticket->title);
        static::setBody($model, $printer);
        //static::setFooter($model, $printer);
        $ticket->body = static::getBody();
        $ticket->base64 = true;
        $ticket->appversion = 1;

        if (false === $ticket->save()) {
            return false;
        }

        return true;
    }

    protected static function setBody(ModelClass $model, TicketPrinter $printer): void
    {
        $terminal = $model->getTerminal();

        static::$escpos->setTextSize($printer->title_font_size, $printer->title_font_size);
        static::$escpos->text(static::sanitize(Tools::trans('box-closure')) . "\n");

        static::$escpos->setTextSize($printer->font_size, $printer->font_size);
        static::$escpos->text(static::sanitize(Tools::trans('pos-terminal') . ': ' . $terminal->name) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('start') . ': ' . $model->fechaini) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('end') . ': ' . $model->fechafin) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('user') . ': ' . $model->nick) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('start-money') . ': ' . Tools::money($model->dineroini, $terminal->coddivisa)) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('income') . ': ' . Tools::money($model->ingresos, $terminal->coddivisa)) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('end-money') . ': ' . Tools::money($model->dinerofin, $terminal->coddivisa)) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('difference') . ': ' . Tools::money($model->diferencia, $terminal->coddivisa)) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('total-sales') . ': ' . Tools::money($model->totaltickets, $terminal->coddivisa)) . "\n");
        static::$escpos->text(static::sanitize(Tools::trans('tickets') . ': ' . $model->numtickets) . "\n");

        $payments = $model->getPaymentBreakdown();
        if (count($payments) > 0) {
            static::$escpos->text("\n" . static::sanitize(Tools::trans('payment-breakdown') . "\n"));
            foreach ($model->getPaymentBreakdown() as $payment) {
                static::$escpos->text(static::sanitize($payment['descripcion'] . ': ' . Tools::money($payment['total'], $terminal->coddivisa)) . "\n");
            }
        }

        if (false === empty($model->observaciones)) {
            static::$escpos->text("\n" . static::sanitize(Tools::trans('observations') . ":\n" . $model->observaciones) . "\n");
        }
    }
}