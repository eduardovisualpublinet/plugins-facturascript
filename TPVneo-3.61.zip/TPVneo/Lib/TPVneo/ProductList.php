<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Lib\TPVneo;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Producto;
use FacturaScripts\Dinamic\Model\Stock;
use FacturaScripts\Dinamic\Model\TpvTerminal;
use FacturaScripts\Dinamic\Model\Variante;

/**
 *
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ProductList extends TpvList
{
    public static function render(TpvTerminal $tpv, string $codalmacen = ''): string
    {
        parent::renderData($tpv, $codalmacen);
        return static::familyList() . static::productList($tpv);
    }

    protected static function getProducts(): array
    {
        $dataBase = new DataBase();
        $sql = 'SELECT p.tpvsort, p.descripcion, i.iva, p.nostock, p.observaciones,'
            . ' p.referencia, p.idproducto, i.iva'
            . ' FROM productos as p'
            . ' LEFT JOIN impuestos as i ON p.codimpuesto = i.codimpuesto'
            . ' LEFT JOIN familias as f ON p.codfamilia = f.codfamilia'
            . ' WHERE p.sevende = true AND p.bloqueado = false AND p.tpvsort > 0'
            . ' AND (f.tpv_show = true OR f.tpv_show IS NULL)';

        if (self::$query) {
            foreach (explode(' ', self::$query) as $value) {
                $sql .= " AND (LOWER(p.referencia) LIKE LOWER(" . $dataBase->var2str('%' . $value . '%') . ")"
                    . " OR LOWER(p.descripcion) LIKE LOWER(" . $dataBase->var2str('%' . $value . '%') . "))";
            }
        }

        if (self::$codfamilia != '-1' && self::$codfamilia != '0') {
            $sql .= ' AND p.codfamilia = ' . $dataBase->var2str(self::$codfamilia);
        }

        $sql .= " ORDER BY p.tpvsort ASC";

        if (self::$limit > 0) {
            return $dataBase->selectLimit($sql, self::$limit);
        }

        $sql .= ';';
        return $dataBase->select($sql);
    }

    protected static function getVariants(): array
    {
        $dataBase = new DataBase();
        $sql = 'SELECT p.tpvsort, p.descripcion, i.iva, p.nostock, p.observaciones,'
            . ' p.referencia, p.idproducto, i.iva'
            . ' FROM productos as p'
            . ' INNER JOIN variantes as v ON v.idproducto = p.idproducto'
            . ' LEFT JOIN impuestos as i ON p.codimpuesto = i.codimpuesto'
            . ' LEFT JOIN familias as f ON p.codfamilia = f.codfamilia'
            . ' WHERE p.sevende = true AND p.bloqueado = false AND p.tpvsort > 0'
            . ' AND (f.tpv_show = true OR f.tpv_show IS NULL)';

        if (self::$query) {
            $sql .= " AND (LOWER(v.codbarras) = LOWER(" . $dataBase->var2str(self::$query) . ")"
                . " OR LOWER(v.referencia) LIKE LOWER(" . $dataBase->var2str('%' . self::$query . '%') . "))";
        }

        if (self::$codfamilia != '-1' && self::$codfamilia != '0') {
            $sql .= ' AND p.codfamilia = ' . $dataBase->var2str(self::$codfamilia);
        }

        $sql .= " ORDER BY p.tpvsort ASC";

        if (self::$limit > 0) {
            return $dataBase->selectLimit($sql, self::$limit);
        }

        $sql .= ';';
        return $dataBase->select($sql);
    }

    protected static function productList(TpvTerminal $tpv): string
    {
        $html = '';

        $products = static::getProducts();
        if (empty($products)) {
            $products = static::getVariants();
        }

        foreach ($products as $row) {
            // obtenemos el producto
            $product = new Producto();
            $product->load($row['idproducto']);

            // obtenemos todas las variantes del producto
            $whereVariant = [Where::column('idproducto', $row['idproducto'])];
            $variants = Variante::all($whereVariant, ['precio' => 'ASC']);

            // pintamos el precio mínimo y máximo
            $price = '';
            if ($variants) {
                $priceMin = static::getPrice($tpv, floatval($variants[0]->precio), floatval($row['iva']));
                $price = Tools::money($priceMin, $tpv->coddivisa);

                if (count($variants) > 1) {
                    $priceMax = static::getPrice($tpv, floatval($variants[count($variants) - 1]->precio), floatval($row['iva']));
                    $price .= ' - ' . Tools::money($priceMax, $tpv->coddivisa);
                }
            }

            $descripcion = Tools::textBreak($row['descripcion'], 100);

            // buscamos si las variantes tienen stock disponible
            $disponible = false;
            foreach ($variants as &$variant) {
                $stock = new Stock();
                $whereStock = [
                    Where::column('referencia', $variant->referencia),
                    Where::column('codalmacen', self::$codalmacen),
                    Where::column('idproducto', $variant->idproducto)
                ];

                if ($stock->loadWhere($whereStock)) {
                    $variant->stock = $stock;
                    if ($stock->disponible > 0) {
                        $disponible = true;
                    }
                    continue;
                }

                $variant->stock = null;
            }

            if ($disponible || in_array($row['nostock'], ['1', 't'])) {
                $cssBorder = 'border-success';
                $cssCoin = 'table-success';
            } else {
                $cssBorder = 'border-warning';
                $cssCoin = 'table-warning';
            }

            $nameModal = 'productModal' . $row['idproducto'];
            $html .= '<div class="col-6 col-sm-4 col-md-3 col-xl-2">'
                . '<div class="' . $cssBorder . ' card shadow-sm mb-3 text-center">'
                . '<div class="cursor-pointer" onclick="$(\'#' . $nameModal . '\').modal(\'show\')">';

            $img = self::getProductImage($product, 'photo-default');
            if (false === empty($img)) {
                $html .= '<div class="photo">' . $img . '</div>';
            }

            $html .= '<div class="h5 mt-2 text-primary ps-1 pe-1">' . $row['referencia'] . '</div>';

            if (empty($img)) {
                $html .= '<p class="small mb-0 ps-1 pe-1">' . $descripcion . '</p>';
            }

            $html .= '</div>'
                . '<div class="' . $cssCoin . ' mt-auto px-1 text-center">' . $price . '</div>'
                . '</div>'
                . self::productInfoModal($tpv, $row, $product, $variants, $nameModal, $disponible)
                . '</div> ';
        }

        return $html;
    }

    protected static function productInfoModal(TpvTerminal $tpv, array $row, Producto $product, array $variants, string $nameModal, bool $disponible): string
    {
        if (empty($variants)) {
            return '';
        }

        $html = '<div class="modal fade modalProductInfo" id="' . $nameModal . '" tabindex="-1" aria-labelledby="' . $nameModal . 'Label" aria-hidden="true">'
            . '<div class="modal-dialog modal-lg">'
            . '<div class="modal-content text-start">'
            . '<div class="modal-header">'
            . '<h5 class="modal-title w-100" id="' . $nameModal . 'Label">'
            . self::getProductImage($product, 'photo-modal me-2') . Tools::trans('product') . ' ' . $row['referencia'] . '</h5>'
            . '<button type="button" class="close btn-spin-action" data-bs-dismiss="modal" aria-label="' . Tools::trans('close') . '">'
            . ''
            . '</button>'
            . '</div>'
            . '<div class="modal-description px-3 pt-2">'
            . '<strong>' . Tools::trans('description') . '</strong>'
            . '<p>' . $row['descripcion'] . '</p>'
            . '</div>';

        if ($row['observaciones']) {
            $nameCollapse = 'productCollapse' . $row['idproducto'];
            $html .= '<div class="modal-observations px-3 mb-3">'
                . '<strong data-bs-toggle="collapse" href="#' . $nameCollapse . '" role="button" aria-expanded="false" aria-controls="' . $nameCollapse . '">'
                . Tools::trans('observations')
                . '<i class="fa-solid fa-eye fa-xs ms-1"></i>'
                . '</strong>'
                . '<div class="collapse" id="' . $nameCollapse . '">'
                . '<p>' . $row['observaciones'] . '</p>'
                . '</div>'
                . '</div>';
        }

        $html .= '<div class="table-responsive border-top">'
            . '<table class="table mb-0">'
            . '<thead>'
            . '<tr>'
            . '<th>' . Tools::trans('image') . '</th>'
            . '<th>' . Tools::trans('variant') . '</th>'
            . '<th>' . Tools::trans('attributes') . '</th>'
            . '<th class="text-end">' . Tools::trans('available') . '</th>'
            . '<th class="text-end">' . Tools::trans('pending-reception') . '</th>'
            . '<th class="text-center">' . Tools::trans('price') . '</th>'
            . '</tr>'
            . '</thead>';

        foreach ($variants as $variant) {
            $qtyStock = 0;
            $qtyPtrecibir = 0;

            if (in_array($row['nostock'], ['1', 't'])) {
                $qtyStock = '∞';
                $qtyPtrecibir = '∞';
            } elseif (isset($variant->stock)) {
                $qtyStock = Tools::number($variant->stock->cantidad);
                $qtyPtrecibir = Tools::number($variant->stock->pterecibir);
            }

            if (floatval($qtyStock) > 0 || in_array($row['nostock'], ['1', 't'])) {
                $cssTr = 'table-success';
                $cssBtn = 'btn-success';
            } else {
                $cssTr = 'table-warning';
                $cssBtn = 'btn-warning';
            }

            $price = self::getPrice($tpv, floatval($variant->precio), floatval($row['iva']));

            $html .= '<tr class="' . $cssTr . '">'
                . '<td class="align-middle">' . self::getVariantImage($variant, 'photo-modal') . '</td>'
                . '<td class="align-middle">' . $variant->referencia . '</td>'
                . '<td class="align-middle">' . $variant->description(true) . '</td>'
                . '<td class="text-end align-middle">' . $qtyStock . '</td>'
                . '<td class="text-end align-middle">' . $qtyPtrecibir . '</td>'
                . '<td class="align-middle text-nowrap"><button class="btn ' . $cssBtn . ' w-100 btn-spin-action" onclick="return addProduct(\''
                . $variant->referencia . '\')"><i class="fa-solid fa-shopping-cart me-1"></i>' . Tools::money($price, $tpv->coddivisa) . '</button></td>'
                . '</tr>';
        }

        $html .= '</table>'
            . '</div>'
            . '</div>'
            . '</div>'
            . '</div>';

        return $html;
    }
}
