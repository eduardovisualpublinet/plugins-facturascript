<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\Divisa;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class TpvCoin extends ModelClass
{
    use ModelTrait;

    /** @var int */
    public $idcoin;

    /** @var string */
    public $coddivisa;

    /** @var string */
    public $name;

    public function install(): string
    {
        // dependencias
        new Divisa();

        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return "idcoin";
    }

    public static function tableName(): string
    {
        return "tpvsneo_coins";
    }
}
