<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Model;

use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\PresupuestoCliente;
use FacturaScripts\Dinamic\Model\TpvTerminal as DinTpvTerminal;
use FacturaScripts\Dinamic\Model\User;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class TpvCaja extends ModelClass
{
    use ModelTrait;

    /**
     * La diferencia entre el dinero que hay al cerrar la caja (dinerofin) y el dinero que debería haber (totalcaja).
     *
     * @var float
     */
    public $diferencia;

    /**
     * El dinero que hay al cerrar la caja.
     *
     * @var float
     */
    public $dinerofin;

    /**
     * El dinero que había al abrir la caja.
     *
     * @var float
     */
    public $dineroini;

    /** @var string */
    public $fechafin;

    /** @var string */
    public $fechaini;

    /** @var int */
    public $idcaja;

    /** @var int */
    public $idtpv;

    /**
     * La suma de todos los ingresos en efectivo. No incluye el dinero inicial.
     *
     * @var float
     */
    public $ingresos;

    /** @var string */
    public $nick;

    /**
     * El número de tickets que se han emitido.
     *
     * @var int
     */
    public $numtickets;

    /** @var string */
    public $observaciones;

    /**
     * El dinero que debería haber en la caja. Es la suma del dinero inicial más todos los ingresos en efectivo.
     *
     * @var float
     */
    public $totalcaja;

    /**
     * La suma de todos los movimientos de caja.
     *
     * @var float
     */
    public $totalmovi;

    /**
     * La suma de los totales de todos los tickets emitidos.
     *
     * @var float
     */
    public $totaltickets;

    public function clear(): void
    {
        parent::clear();
        $this->diferencia = 0.0;
        $this->dinerofin = 0.0;
        $this->dineroini = 0.0;
        $this->fechaini = Tools::dateTime();
        $this->ingresos = 0.0;
        $this->numtickets = 0;
        $this->totalcaja = 0.0;
        $this->totalmovi = 0.0;
        $this->totaltickets = 0.0;
    }

    public function close(float $finalAmount): void
    {
        $this->dinerofin = $finalAmount;
        $this->diferencia = $finalAmount - $this->totalcaja;
        $this->fechafin = Tools::dateTime();
    }

    public function getDocs(?TpvTerminal $tpv = null): array
    {
        if (is_null($tpv)) {
            $tpv = $this->getTerminal();
        }
        if (false === $tpv->exists()) {
            return [];
        }

        $docs = [];
        $arrClass = ['AlbaranCliente', 'FacturaCliente'];
        foreach ($arrClass as $className) {
            $modelClass = '\\FacturaScripts\\Dinamic\\Model\\' . $className;
            $docModel = new $modelClass();
            $where = [Where::eq('idcaja', $this->idcaja)];
            $orderBy = ['fecha' => 'DESC', 'hora' => 'DESC'];
            $results = $docModel->all($where, $orderBy);
            if (empty($results)) {
                continue;
            }

            $docs = array_merge($docs, $results);
        }

        return $docs;
    }

    public function getMovements(): array
    {
        $where = [Where::eq('idcaja', $this->idcaja)];
        return TpvMovimiento::all($where);
    }

    public function getPaymentBreakdown(): array
    {
        $payments = [];
        $tpv = $this->getTerminal();
        foreach ($this->getDocs($tpv) as $doc) {
            if ($tpv->doctype === 'AlbaranCliente') {
                $paymentMethod = $doc->getPaymentMethod();
                if (!isset($payments[$paymentMethod->codpago])) {
                    $payments[$paymentMethod->codpago] = [
                        'descripcion' => $paymentMethod->descripcion,
                        'total' => $doc->total,
                    ];
                    continue;
                }
                $payments[$paymentMethod->codpago]['total'] += $doc->total;
                continue;
            }

            foreach ($doc->getReceipts() as $receipt) {
                $paymentMethod = $receipt->getPaymentMethod();
                if (!isset($payments[$paymentMethod->codpago])) {
                    $payments[$paymentMethod->codpago] = [
                        'descripcion' => $paymentMethod->descripcion,
                        'total' => $receipt->importe,
                    ];
                    continue;
                }
                $payments[$paymentMethod->codpago]['total'] += $receipt->importe;
            }
        }
        return $payments;
    }

    public function getTerminal(): TpvTerminal
    {
        $tpv = new DinTpvTerminal();
        $tpv->load($this->idtpv);
        return $tpv;
    }

    public function install(): string
    {
        // dependencias
        new User();
        new DinTpvTerminal();

        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return 'idcaja';
    }

    public static function tableName(): string
    {
        return 'tpvsneo_cajas';
    }

    public function test(): bool
    {
        // escapamos el html de observaciones
        $this->observaciones = Tools::noHtml($this->observaciones);

        $this->setTotals();

        return parent::test();
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return $type === 'list' ?
            $this->getTerminal()->url() :
            parent::url($type, $list);
    }

    protected function setTotals(): void
    {
        if (empty($this->id())) {
            return;
        }

        $terminal = $this->getTerminal();
        $this->ingresos = 0.0;
        $this->numtickets = 0;
        $this->totalcaja = $this->dineroini;
        $this->totaltickets = 0.0;
        $this->totalmovi = 0.0;

        // recorremos los documentos de la caja
        $keys = [];
        foreach ($this->getDocs() as $doc) {
            // comprobamos que el documento no se haya contabilizado ya
            $key = $doc->primaryColumn() . ':' . $doc->id();
            if (in_array($key, $keys, true)) {
                continue;
            }

            $this->ingresos += $doc->tpv_efectivo - $doc->tpv_cambio;
            $this->totalcaja += $doc->tpv_efectivo - $doc->tpv_cambio;
            $this->totaltickets += $doc->total;
            $this->numtickets++;

            // guardamos la clave del documento para no contabilizarlo dos veces
            $keys[] = $key;

            // si se trata de un albarán, guardamos también el id de la factura asociada
            if ($doc->modelClassName() === 'AlbaranCliente') {
                foreach ($doc->childrenDocuments() as $child) {
                    $keys[] = $child->primaryColumn() . ':' . $child->id();
                }
            }
        }

        // recorremos los presupuestos aparcados
        $where = [
            Where::eq('idcaja', $this->idcaja),
            Where::eq('aparcado', true),
        ];
        foreach (PresupuestoCliente::all($where) as $presupuesto) {
            if (false === Plugins::isEnabled('PrePagos')) {
                continue;
            }

            foreach ($presupuesto->getPayments() as $prepayment) {
                // si la forma de pago es la del terminal, es efectivo
                if ($prepayment->codpago === $terminal->codpago) {
                    $this->ingresos += $prepayment->amount;
                    $this->totalcaja += $prepayment->amount;
                }
            }
        }

        // recorremos los movimientos de la caja
        foreach ($this->getMovements() as $movement) {
            $this->totalcaja += $movement->amount;
            $this->totalmovi += $movement->amount;
        }
    }
}
