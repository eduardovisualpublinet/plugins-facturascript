<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\FormaPago;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class TpvPago extends ModelClass
{
    use ModelTrait;

    /** @var int */
    public $idtpvpago;

    /** @var string */
    public $codpago;

    /** @var int */
    public $idtpv;

    /** @var bool */
    public $paid;

    public function clear(): void
    {
        parent::clear();
        $this->paid = false;
    }

    public function getMethodPayment(): FormaPago
    {
        $formaPago = new FormaPago();
        $formaPago->load($this->codpago);
        return $formaPago;
    }

    public function install(): string
    {
        new FormaPago();
        new TpvTerminal();

        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return "idtpvpago";
    }

    public static function tableName(): string
    {
        return "tpvsneo_pagos";
    }
}
