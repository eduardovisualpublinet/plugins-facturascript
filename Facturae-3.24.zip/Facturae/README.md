# Facturae
Plugin que añade soporte para la factura electrónica española. Formato facturae 3.2.
- https://facturascripts.com/plugins/facturae

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE LA DISTRIBUCIÓN NI PUBLICACIÓN.

## Carpeta
El nombre de la carpeta debe ser el mismo que el del plugin. En este caso, **Facturae**.

## Autofirma
- https://administracionelectronica.gob.es/ctt/clienteafirma/descargas
- https://administracionelectronica.gob.es/ctt/resources/Soluciones/138/Descargas/MCF-manual-integrador-ES-1-8-2.pdf?idIniciativa=138&idElemento=26033