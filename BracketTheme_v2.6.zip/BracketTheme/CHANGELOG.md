# Changelog - BracketTheme

## Version 2.3 (2025-10-30)

### ✨ Nuevas características
- **Dropdown de usuario funcional**: Implementado sistema completo para el menú de usuario
  - JavaScript personalizado en `bracket.js` para toggle del dropdown
  - CSS específico para posicionamiento correcto del menú
  - Compatible con el sistema de menús colapsables del sidebar

- **Logos personalizados**: Reemplazados todos los logos con versiones de demo.visualfactura.es
  - `horizontal-logo.png` - Logo principal (20KB)
  - `favicon.ico` - Icono del navegador (118KB)
  - `apple-icon-180x180.png` - Icono para iOS/iPad (12KB)

### 🔧 Mejoras
- **Bootstrap 5 completo**: Actualización total de compatibilidad
  - `Login.html.twig`: Modal de "Olvidé mi contraseña" funcional
  - Atributos actualizados: `data-toggle` → `data-bs-toggle`, `data-target` → `data-bs-target`, `data-dismiss` → `data-bs-dismiss`
  - Clases actualizadas: `btn-block` → `w-100`, `mr-*` → `me-*`, `close` → `btn-close`
  - bracket.css mantiene clases legacy para compatibilidad híbrida

### 📦 Archivos modificados
- `Assets/JS/bracket.js` - Agregado handler para dropdown de usuario (líneas 196-214)
- `Assets/CSS/custom.css` - Agregado CSS para posicionamiento del dropdown (líneas 151-173)
- `View/Login/Login.html.twig` - Actualizado a Bootstrap 5 (modal, botones, márgenes)
- `Assets/Images/horizontal-logo.png` - Reemplazado con logo de demo
- `Assets/Images/favicon.ico` - Reemplazado con favicon de demo
- `Assets/Images/apple-icon-180x180.png` - Reemplazado con icono de demo

### 🐛 Bugs corregidos
- Dropdown de usuario no funcionaba al hacer clic en el nombre
- Modal de "Olvidé mi contraseña" no se abría
- Botón de cerrar modal no funcionaba
- Dropdown desplazaba el icono de usuario hacia arriba

### 📝 Compatibilidad
- **Bootstrap 5**: Totalmente compatible
- **Bootstrap 4**: Compatible mediante clases legacy en bracket.css
- **FacturaScripts**: Probado y funcional

---

## Version 2.2 (2025-10-30)

### ✨ Nuevas características
- **Colores actualizados**: Implementados todos los colores del demo VisualFactura
  - Color primario: #B2A1FE (violeta/morado)
  - Color secundario: #B4FB64 (verde lima/amarillo)
  - Fondos violeta claro: #efecff, #f5f3ff, #ddd6ff
  - Color oscuro: #111736 (azul oscuro)
  - Acentos: #ed5462 (rojo/rosa), #ff7e5e (naranja/coral)

### 🔧 Mejoras
- **Compatibilidad Bootstrap 5**: Agregados estilos para checkboxes de Bootstrap 5
  - Soporte completo para `.custom-control-label`
  - Checkboxes con pseudoelementos `::before` y `::after`
  - Estados: normal, checked, focus, disabled, indeterminate
  - Checkboxes grandes (`.custom-control-lg`) para tablas de permisos

- **Tablas mejoradas**:
  - Colores correctos para `.table-secondary` (filas de menú en gris)
  - Colores correctos para `.table-success` (filas completadas en verde)
  - Checkboxes centrados en columnas de tabla
  - Badges con tamaños optimizados

### 📦 Archivos modificados
- `Assets/CSS/bracket.css` - Reemplazado con versión del demo con colores actualizados
- `Assets/CSS/custom.css` - Nuevo archivo con fixes de Bootstrap 5 y mejoras de tablas

### 🐛 Bugs corregidos
- Checkboxes invisibles en tablas de permisos (EditRole)
- Colores inconsistentes entre tema original y demo
- Compatibilidad con controles de Bootstrap 5

---

## Version 2.1 (anterior)
- Diseño basado en template Bracket
- Ajustes iniciales para FacturaScripts
