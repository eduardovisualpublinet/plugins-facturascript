<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Verifactu\Extension\Model;

use Closure;
use FacturaScripts\Core\Tools;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class LineaFacturaCliente
{
    public function clear(): Closure
    {
        return function () {
            $this->vf_send = true;
        };
    }

    public function deleteBefore(): Closure
    {
        return function () {
            // si la factura está dada de alta o anulada en verifactu, no se pueden eliminar líneas
            $invoice = $this->getDocument();
            if (!empty($invoice->id()) && $invoice->getCompany()->verifactuIsConfigured(false)
                && ($invoice->verifactuCheckAlta() || $invoice->verifactuCheckAnulacion())) {
                Tools::log()->warning('verifactu-invoice-has-events', [
                    'model-code' => $this->id(),
                    'model-class' => $this->modelClassName(),
                ]);
                return false;
            }
        };
    }

    public function saveInsertBefore(): Closure
    {
        return function () {
            // si la factura está dada de alta o anulada en verifactu, no se pueden añadir líneas
            $invoice = $this->getDocument();
            if ($invoice->getCompany()->verifactuIsConfigured(false)
                && ($invoice->verifactuCheckAlta() || $invoice->verifactuCheckAnulacion())) {
                Tools::log()->warning('verifactu-invoice-is-already-submitted', [
                    'model-code' => $this->id(),
                    'model-class' => $this->modelClassName(),
                ]);
                return false;
            }
        };
    }

    public function saveUpdateBefore(): Closure
    {
        return function () {
            // obtenemos la factura
            $invoice = $this->getDocument();

            // si la empresa no está configurada en verifactu, permitimos guardar
            if (!$invoice->getCompany()->verifactuIsConfigured(false)) {
                return;
            }

            // obtenemos los cambios
            $dirty = $this->getDirty();

            // si no hay cambios, no hacemos nada
            if (empty($dirty)) {
                return;
            }

            // si la factura no está dada de alta y baja en verifactu, permitimos guardar
            if (!$invoice->verifactuCheckAlta() && !$invoice->verifactuCheckAnulacion()) {
                return;
            }

            // si la factura está dada de baja en verifactu, no permitimos guardar
            if ($invoice->verifactuCheckAnulacion()) {
                Tools::log()->warning('verifactu-invoice-is-annulled', [
                    'model-code' => $this->id(),
                    'model-class' => $this->modelClassName(),
                ]);
                return false;
            }

            // campos no permitidos para modificar
            $fieldsNotPermitted = ['cantidad', 'codimpuesto', 'coste', 'dtopor', 'dtopor2', 'excepcioniva',
                'idfactura', 'idlinea', 'idproducto', 'irpf', 'iva', 'pvpsindto', 'pvptotal', 'pvpunitario',
                'recargo', 'referencia', 'suplido'];

            // comprobamos que los campos modificados no estén en la lista de no permitidos
            foreach ($dirty as $field => $value) {
                if (in_array($field, $fieldsNotPermitted)) {
                    Tools::log()->warning('verifactu-invoice-line-edit-not-permitted', [
                        'model-code' => $this->id(),
                        'model-class' => $this->modelClassName(),
                        '%field%' => $field,
                        '%no-permitted%' => implode(', ', $fieldsNotPermitted),
                    ]);
                    return false;
                }
            }
        };
    }
}
