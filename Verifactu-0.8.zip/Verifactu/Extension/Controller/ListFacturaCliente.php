<?php

/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Verifactu\Extension\Controller;

use Closure;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;

class ListFacturaCliente
{
    public function createViews(): Closure
    {
        return function () {
            $this->tab('ListFacturaCliente')
                ->addFilterSelectWhere('sent-verifactu', [
                [
                    'label' => Tools::trans('verifactu'),
                    'where' => []
                ],
                [
                    'label' => Tools::trans('sent'),
                    'where' => [Where::eq('vf_sent', true)]
                ],
                [
                    'label' => Tools::trans('not-sent'),
                    'where' => [Where::eq('vf_sent', false)]
                ],
            ]);
        };
    }
}