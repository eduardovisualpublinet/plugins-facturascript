<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Verifactu;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Controller\ApiRoot;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Kernel;
use FacturaScripts\Core\Lib\AjaxForms\SalesLineHTML;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Base\BusinessDocument;
use FacturaScripts\Dinamic\Model\EstadoDocumento;
use FacturaScripts\Plugins\Verifactu\Lib\Verifactu\Certificate;
use FacturaScripts\Plugins\Verifactu\Model\VerifactuRegistroEvento;
use FacturaScripts\Plugins\Verifactu\Model\VerifactuRegistroFactura;
use FacturaScripts\Plugins\Verifactu\Model\VerifactuRequerimientoLine;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        // cargamos las extensiones
        $this->loadExtension(new Extension\Controller\DocumentStitcher());
        $this->loadExtension(new Extension\Controller\EditEmpresa());
        $this->loadExtension(new Extension\Controller\EditEstadoDocumento());
        $this->loadExtension(new Extension\Controller\EditFacturaCliente());
        $this->loadExtension(new Extension\Controller\ListFacturaCliente());
        $this->loadExtension(new Extension\Lib\PDF\PDFDocument());
        $this->loadExtension(new Extension\Lib\PlantillasPDF\BaseTemplate());
        $this->loadExtension(new Extension\Model\Ejercicio());
        $this->loadExtension(new Extension\Model\Empresa());
        $this->loadExtension(new Extension\Model\FacturaCliente());
        $this->loadExtension(new Extension\Model\LineaAlbaranCliente());
        $this->loadExtension(new Extension\Model\LineaFacturaCliente());
        $this->loadExtension(new Extension\Model\LineaPedidoCliente());
        $this->loadExtension(new Extension\Model\LineaPresupuestoCliente());

        // cargamos los Mods
        SalesLineHTML::addMod(new Mod\SalesLineMod());

        // evitamos copiar estás columnas de la factura al copiar, duplicar o rectificar la factura
        BusinessDocument::dontCopyField('vf_intents_alta');
        BusinessDocument::dontCopyField('vf_intents_anulacion');
        BusinessDocument::dontCopyField('vf_intents_subsanacion');
        BusinessDocument::dontCopyField('vf_manual_alta');
        BusinessDocument::dontCopyField('vf_manual_anulacion');
        BusinessDocument::dontCopyField('vf_sent');

        // cargamos los endpoints de la API
        Kernel::addRoute('/api/3/verifactu', 'ApiControllerVerifactu', -1);
        ApiRoot::addCustomResource('verifactu');

        // Tickets
        if (Plugins::isEnabled('Tickets')) {
            $this->loadExtension(new Extension\Lib\Tickets\Gift());
            $this->loadExtension(new Extension\Lib\Tickets\Normal());
        }
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
        new VerifactuRegistroFactura();
        new VerifactuRegistroEvento();
        new VerifactuRequerimientoLine();

        $this->addStatusDocument();

        // TODO: eliminar en la versión 1.0
        $this->checkCertificate();
        $this->removeAbsolutePathRecords();
        $this->updateEventRecords();
        $this->updateRegistroFacturaSignature();
        $this->updateRegistroEventoSignature();
    }

    private function checkCertificate(): void
    {
        foreach (Empresas::all() as $company) {
            Certificate::checkCertificate($company);
        }
    }

    private function moveDirectoryContents(string $source, string $destination): void
    {
        if (!is_dir($source)) {
            return;
        }

        Tools::folderCheckOrCreate($destination);
        $files = scandir($source);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $sourcePath = $source . '/' . $file;
            $destPath = $destination . '/' . $file;

            if (is_dir($sourcePath)) {
                // mover recursivamente subdirectorios
                $this->moveDirectoryContents($sourcePath, $destPath);
            } else {
                // mover archivos
                rename($sourcePath, $destPath);
            }
        }
    }

    private function removeAbsolutePathRecords(): void
    {
        $db = new DataBase();

        // si no existen las tablas, terminamos
        if (!$db->tableExists('verifactu_registros_facturas')
            || !$db->tableExists('verifactu_registros_eventos')
            || !$db->tableExists('empresas')) {
            return;
        }

        // eliminamos rutas absolutas de los ficheros almacenados en la base de datos
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET file_json = SUBSTRING(file_json, LOCATE('MyFiles', file_json))"
            . " WHERE file_json LIKE '%MyFiles%'");
        $db->exec("UPDATE verifactu_registros_eventos"
            . " SET file_json = SUBSTRING(file_json, LOCATE('MyFiles', file_json))"
            . " WHERE file_json LIKE '%MyFiles%'");
        $db->exec("UPDATE empresas"
            . " SET vf_certificate = SUBSTRING(vf_certificate, LOCATE('MyFiles', vf_certificate))"
            . " WHERE vf_certificate LIKE '%MyFiles%'");

        // además, buscamos cualquier ruta parecida a MyFiles/Verifactu1/ y la corregimos
        // debemos buscarla con expresiones regulares
        $registrosFacturas = $db->select("SELECT id, file_json FROM verifactu_registros_facturas WHERE file_json REGEXP 'MyFiles/Verifactu[0-9]+/'");
        foreach ($registrosFacturas as $row) {
            $newPath = preg_replace('/MyFiles\/Verifactu(\d+)\//', 'MyFiles/Verifactu/$1/', $row['file_json']);
            $db->exec("UPDATE verifactu_registros_facturas SET file_json = " . $db->var2str($newPath) . " WHERE id = " . $row['id']);
        }

        $registrosEventos = $db->select("SELECT id, file_json FROM verifactu_registros_eventos WHERE file_json REGEXP 'MyFiles/Verifactu[0-9]+/'");
        foreach ($registrosEventos as $row) {
            $newPath = preg_replace('/MyFiles\/Verifactu(\d+)\//', 'MyFiles/Verifactu/$1/', $row['file_json']);
            $db->exec("UPDATE verifactu_registros_eventos SET file_json = " . $db->var2str($newPath) . " WHERE id = " . $row['id']);
        }

        $empresas = $db->select("SELECT idempresa, vf_certificate FROM empresas WHERE vf_certificate REGEXP 'MyFiles/Verifactu[0-9]+/'");
        foreach ($empresas as $row) {
            $newPath = preg_replace('/MyFiles\/Verifactu(\d+)\//', 'MyFiles/Verifactu/$1/', $row['vf_certificate']);
            $db->exec("UPDATE empresas SET vf_certificate = " . $db->var2str($newPath) . " WHERE idempresa = " . $row['idempresa']);
        }

        // por otro lado si existe la carpeta MyFiles/Verifactu1/ la renombramos a MyFiles/Verifactu/1/
        foreach (Empresas::all() as $company) {
            $basePath = Tools::folder('MyFiles/Verifactu');
            $oldPath = $basePath . $company->idempresa;
            if (!is_dir($oldPath)) {
                continue;
            }

            $newPath = $basePath . '/' . $company->idempresa;

            // crear el directorio base si no existe
            Tools::folderCheckOrCreate($basePath);

            // si el nuevo path no existe, simplemente renombramos
            if (!is_dir($newPath)) {
                rename($oldPath, $newPath);
                continue;
            }

            // si ambos existen, movemos recursivamente el contenido
            $this->moveDirectoryContents($oldPath, $newPath);

            // eliminar el directorio antiguo recursivamente
            $this->removeDirectory($oldPath);
        }
    }

    private function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $files = scandir($directory);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $path = $directory . '/' . $file;
            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }

        rmdir($directory);
    }

    private function addStatusDocument(): void
    {
        // buscamos un estado llamado 'Verifactu', si existe, no hacemos nada
        $status = new EstadoDocumento();
        $where = [
            Where::eq('nombre', 'Verifactu'),
            Where::eq('tipodoc', 'FacturaCliente')
        ];
        if ($status->loadWhere($where)) {
            return;
        }

        // creamos el estado
        $status->nombre = 'Verifactu';
        $status->tipodoc = 'FacturaCliente';
        $status->activo = true;
        $status->editable = false;
        $status->actualizastock = -1;
        $status->vf_send = true;
        $status->save();
    }

    private function updateEventRecords(): void
    {
        $db = new DataBase();

        // si no existen las tablas, terminamos
        if (!$db->tableExists('verifactu_registros_facturas')) {
            return;
        }

        // eliminamos rutas absolutas de los ficheros almacenados en la base de datos
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET event = '" . VerifactuRegistroFactura::EVENT_ALTA . "'"
            . " WHERE event = 'alta'");
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET event = '" . VerifactuRegistroFactura::EVENT_SUBSANACION . "'"
            . " WHERE event = 'subsanacion'");
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET event = '" . VerifactuRegistroFactura::EVENT_ANULACION . "'"
            . " WHERE event = 'anulacion'");
    }

    private function updateRegistroEventoSignature(): void
    {
        $db = new DataBase();

        // si no existen las tablas, terminamos
        if (!$db->tableExists('verifactu_registros_eventos')) {
            return;
        }

        $where = [
            // Esta es la fecha de la actualización 0.80 que añadió el campo firma
            Where::lte('creation_date', '01-12-2025 23:59:59'),
            Where::eq('signature', false)
        ];
        foreach (VerifactuRegistroEvento::all($where, ['id' => 'ASC']) as $regEvent) {
            // Comprueba si el archivo existe
            if (!file_exists($regEvent->url('path_json'))) {
                continue;
            }

            // Leemos el contenido del archivo
            $fileContent = file_get_contents($regEvent->url('path_json'));
            if (false === $fileContent) {
                continue;
            }

            // Decodificamos el JSON
            $eventJson = json_decode($fileContent, true);
            if (null === $eventJson) {
                continue;
            }

            // si el JSON ya tiene firma, marcamos el registro como firmado
            if (isset($eventJson['RegistroEvento']['Evento']['Signature'])) {
                $regEvent->signature = true;
                $regEvent->save();
            }
        }
    }

    private function updateRegistroFacturaSignature(): void
    {
        $db = new DataBase();

        // si no existen las tablas, terminamos
        if (!$db->tableExists('verifactu_registros_facturas')) {
            return;
        }

        $where = [
            // Esta es la fecha de la actualización 0.79 que añadió el campo firma
            Where::lte('creation_date', '26-11-2025 23:59:59'),
            Where::eq('signature', false)
        ];
        foreach (VerifactuRegistroFactura::all($where, ['id' => 'ASC']) as $regInvoice) {
            // Comprueba si el archivo existe
            if (!file_exists($regInvoice->url('path_json'))) {
                continue;
            }

            // Leemos el contenido del archivo
            $fileContent = file_get_contents($regInvoice->url('path_json'));
            if (false === $fileContent) {
                continue;
            }

            // Decodificamos el JSON
            $invoiceJson = json_decode($fileContent, true);
            if (null === $invoiceJson) {
                continue;
            }

            // si el JSON ya tiene firma, marcamos el registro como firmado
            if (isset($invoiceJson['RegistroAlta']['Signature'])
                || isset($invoiceJson['RegistroAnulacion']['Signature'])) {
                $regInvoice->signature = true;
                $regInvoice->save();
            }
        }
    }
}
