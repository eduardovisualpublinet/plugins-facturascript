<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Verifactu\Lib\Verifactu;

use Exception;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\UploadedFile;
use FacturaScripts\Dinamic\Model\Empresa;
use FacturaScripts\Plugins\Verifactu\Lib\FiscalNumberValidator;
use SimpleXMLElement;

/**
 * Clase para manejar el certificado de Verifactu guardado en la empresa.
 *
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Certificate
{
    private const TSL_URL = 'https://sedediatid.mineco.gob.es/Prestadores/TSL/TSL.xml';
    private const CACHE_PATH = 'MyFiles/Tmp/Verifactu';
    private const CACHE_FILE = 'tsl_cache.xml';
    private const CACHE_TTL = 86400; // 24h

    /**
     * Comprueba el certificado de la empresa.
     */
    public static function checkCertificate(Empresa $company): void
    {
        // si no tiene certificado o ya tiene fecha de expiración, no hacemos nada
        if (empty($company->vf_certificate)) {
            return;
        }

        // obtenemos las rutas de los certificados actuales
        $certificate = self::getCertificate($company);
        $pem = self::getCertificatePem($company);

        // validamos que el certificado, si falla, lo eliminamos de la empresa
        if (!self::validateCertificate($certificate, $company)
            || !self::createCertificatePem($certificate, $company)) {
            self::cleanupTempFiles([$certificate, $pem]);
            $company->vf_certificate = null;
            $company->vf_password = null;
            $company->vf_certificate_representative_cif = null;
            $company->vf_certificate_representative_name = null;
            $company->vf_certificate_seal = false;
            $company->vf_certificate_expiration = null;
            $company->save();
            return;
        }

        // si la fecha de expiración cambió, la actualizamos
        if ($company->isDirty('vf_certificate_expiration')) {
            $company->save();
        }
    }

    /**
     * Devuelve la ruta del archivo del certificado de la empresa.
     */
    public static function getCertificate(Empresa $company): string
    {
        if (empty($company->vf_certificate)) {
            return '';
        }

        // cargamos la ruta de destino
        $destiny = self::getCertificateRoute($company);

        // creamos la ruta del archivo
        $filePath = $destiny . '/' . $company->vf_certificate;

        // devolvemos la ruta completa del archivo
        return file_exists($filePath)
            ? $filePath
            : '';
    }

    /**
     * Devuelve la ruta del archivo .pem del certificado de la empresa.
     */
    public static function getCertificatePem(Empresa $company): string
    {
        if (empty($company->vf_certificate)) {
            return '';
        }

        $destiny = self::getCertificateRoute($company);
        $base = pathinfo($company->vf_certificate, PATHINFO_FILENAME);
        $pemPath = $destiny . '/' . $base . '.pem';
        return file_exists($pemPath) ? $pemPath : '';
    }

    /**
     * Mueve el certificado subido desde el modal a MyFiles y luego lo valida.
     */
    public static function setCertificateModal(Empresa $company, UploadedFile $uploadFile): bool
    {
        // copiamos el archivo en MyFiles
        if (!$uploadFile->move(Tools::folder('MyFiles'), $uploadFile->getClientOriginalName())) {
            Tools::log()->warning('error-moving-file', [
                '%file%' => $uploadFile->getClientOriginalName(),
                '%folder%' => Tools::folder('MyFiles'),
            ]);
            return false;
        }

        // eliminamos el certificado anterior si existe
        self::cleanupTempFiles([self::getCertificate($company), self::getCertificatePem($company)]);

        // guardamos el nombre del archivo en la empresa
        $company->vf_certificate = $uploadFile->getClientOriginalName();
        return self::setCertificateMyFiles($company);
    }

    /**
     * Mueve el certificado desde MyFiles a la carpeta de Verifactu y lo valida.
     */
    public static function setCertificateMyFiles(Empresa $company): bool
    {
        if (empty($company->vf_certificate)) {
            Tools::log()->warning('no-certificate-to-set');
            return false;
        }

        // comprobamos si el archivo está en MyFiles, si no está, terminamos
        $filePath = Tools::folder('MyFiles', $company->vf_certificate);
        if (false === file_exists($filePath)) {
            Tools::log()->warning('certificate-file-not-found-in-myfiles', [
                '%file%' => $company->vf_certificate,
                '%folder%' => Tools::folder('MyFiles'),
            ]);
            return false;
        }

        // obtenemos la ruta de destino
        $destiny = self::getCertificateRoute($company);

        // si la carpeta no existe o no podemos crearla, terminamos
        if (false === Tools::folderCheckOrCreate($destiny)) {
            self::cleanupTempFiles([$filePath]);
            Tools::log()->warning('error-creating-certificate-folder', [
                '%folder%' => $destiny,
            ]);
            return false;
        }

        // formateamos el nombre del archivo manteniendo la extensión
        $newFileName = self::getFormatName($company->vf_certificate);
        $newFilePath = $destiny . '/' . $newFileName;

        // si no tiene extensión p12 o pfx, terminamos
        $ext = strtolower(pathinfo($newFileName, PATHINFO_EXTENSION));
        if ($ext !== 'p12' && $ext !== 'pfx') {
            self::cleanupTempFiles([$filePath]);
            Tools::log()->warning('error-invalid-certificate-extension', [
                '%file%' => $company->vf_certificate,
            ]);
            return false;
        }

        // lo movemos a la carpeta de Verifactu, si no podemos renombrarlo, devolvemos vacío
        if (false === rename($filePath, $newFilePath)) {
            self::cleanupTempFiles([$filePath]);
            Tools::log()->warning('verifactu-company-has-events', [
                '%file%' => $company->vf_certificate,
                '%folder%' => $destiny,
            ]);
            return false;
        }

        // validamos el certificado y creamos el archivo .pem
        if (false === self::validateCertificate($newFilePath, $company)
            || false === self::createCertificatePem($newFilePath, $company)) {
            self::cleanupTempFiles([$newFilePath]);
            $company->vf_certificate = null;
            $company->vf_password = null;
            $company->vf_certificate_representative_cif = null;
            $company->vf_certificate_representative_name = null;
            $company->vf_certificate_seal = false;
            $company->vf_certificate_expiration = null;
            $company->save();
            return false;
        }

        // actualizamos el nombre del archivo en la empresa
        $company->vf_certificate = $newFileName;
        if (false === $company->save()) {
            self::cleanupTempFiles([$newFilePath]);
            Tools::log()->warning('error-saving-certificate', [
                '%file%' => $newFileName,
                '%folder%' => $destiny,
            ]);
        }

        // comprobamos la conexión SSL/TLS
        if (!self::testPemConnection($company)) {
            Tools::log()->warning('ssl-connection-test-failed');
        }

        return true;
    }

    /**
     * Comprueba el estado de revocación del certificado: intenta OCSP y luego CRL.
     * Devuelve true solo si puede comprobar que no está revocado. Si no puede comprobarlo, devuelve false.
     */
    private static function checkRevocation(array $certInfo, string $filePath): bool
    {
        // Primero: intentar OCSP usando AIA
        if (!empty($certInfo['extensions']['authorityInfoAccess'])) {
            $aia = $certInfo['extensions']['authorityInfoAccess'];
            // buscar URL OCSP
            if (preg_match('#OCSP:(https?://[^,\s]+)#i', $aia, $m)) {
                $ocspUrl = trim($m[1]);
                if (self::opensslCliAvailable()) {
                    // intentamos usar openssl ocsp
                    // para ello necesitamos el issuer cert; intentamos extraerlo desde extras si existe
                    $issuerPem = null;
                    if (!empty($certInfo['issuer'])) {
                        // No siempre tenemos issuer PEM en certInfo; fallback a buscar en TSL
                        $issuers = self::getTrustedIssuers();
                        foreach ($issuers as $issuer) {
                            if (isset($issuer['CN']) && isset($certInfo['issuer']['CN']) && $issuer['CN'] === $certInfo['issuer']['CN']) {
                                // no tenemos el PEM completo aquí; saltar a CRL si OCSP no es posible
                                $issuerPem = null;
                                break;
                            }
                        }
                    }

                    // Si no podemos obtener issuer PEM de forma fiable, omitimos OCSP y probamos CRL
                }
            }
        }

        // Intentar CRL: buscar distributionPoints en extensiones
        if (!empty($certInfo['extensions']['crlDistributionPoints'])) {
            $crlDp = $certInfo['extensions']['crlDistributionPoints'];
            // extraer todas las URLs
            if (preg_match_all('#(https?://[^,\s)]+)#i', $crlDp, $m)) {
                foreach ($m[1] as $crlUrl) {
                    $crlUrl = trim($crlUrl);
                    try {
                        $crl = @file_get_contents($crlUrl);
                        if ($crl !== false) {
                            // intentar cargar CRL y comprobar serial
                            if (self::checkCrlContainsSerial($crl, $certInfo['serialNumber'])) {
                                Tools::log()->warning('error-cert-revoked-via-crl');
                                return false;
                            }
                            // si no está en la CRL, consideramos buen estado para este CRL
                            return true;
                        }
                    } catch (\Throwable $e) {
                        // ignorar y probar siguiente CRL
                    }
                }
            }
        }

        // Si no hemos podido comprobar revocación, fallamos la validación (requisito Verifactu: no revocado)
        Tools::log()->warning('error-cert-revocation-unknown');
        return false;
    }

    /**
     * Limpia los archivos temporales
     */
    private static function cleanupTempFiles(array $files): void
    {
        foreach ($files as $file) {
            if (file_exists($file)) {
                @unlink($file);
            }
        }
    }

    /**
     * Convierte certificado P12 legacy (Windows/RC2) a formato compatible con OpenSSL 3
     */
    private static function convertLegacy(string $certPath, string $certContent, string $password): string
    {
        // Intentar leer el certificado directamente primero
        $parsed = [];
        if (@openssl_pkcs12_read($certContent, $parsed, $password)) {
            // El certificado ya es compatible, devolver la ruta original
            return $certPath;
        }

        // Si no hay CLI disponible (Windows sin OpenSSL, hosting con exec deshabilitado, etc.)
        // devolvemos el path original en lugar de cadena vacía para evitar romper la ejecución.
        if (!self::opensslCliAvailable()) {
            Tools::log()->warning('openssl-cli-not-available-returning-original-path');
            return $certPath;
        }

        // Si falla, intentar con provider legacy usando openssl command
        // Esto es necesario para certificados p12/pfx exportados de Windows con RC2-40-CBC
        $tempDir = dirname($certPath);
        $tempPem = $tempDir . '/temp_cert_' . uniqid() . '.pem';
        $tempKey = $tempDir . '/temp_key_' . uniqid() . '.pem';
        $tempNew = $tempDir . '/temp_cert_new_' . uniqid() . '.p12';

        try {
            // Exportar certificado y clave, intentando primero con -legacy (OpenSSL 3.x)
            // y luego sin él para compatibilidad con versiones anteriores
            $legacyFlag = '-legacy';
            $exportCmd = sprintf(
                'openssl pkcs12 -in %s -passin pass:%s %s -nodes -out %s 2>&1',
                escapeshellarg($certPath),
                escapeshellarg($password),
                $legacyFlag,
                escapeshellarg($tempPem)
            );

            exec($exportCmd, $output, $returnCode);

            // Si falla con -legacy, intentar sin él
            if ($returnCode !== 0 || !file_exists($tempPem)) {
                $legacyFlag = '';
                $exportCmd = sprintf(
                    'openssl pkcs12 -in %s -passin pass:%s -nodes -out %s 2>&1',
                    escapeshellarg($certPath),
                    escapeshellarg($password),
                    escapeshellarg($tempPem)
                );

                exec($exportCmd, $output, $returnCode);

                if ($returnCode !== 0 || !file_exists($tempPem)) {
                    Tools::log()->warning('failed-to-export-certificate', [
                        '%error%' => implode(' ', $output)
                    ]);
                    self::cleanupTempFiles([$tempPem, $tempKey, $tempNew]);
                    return '';
                }
            }

            // Extraer solo la clave privada con el mismo flag que funcionó
            $keyCmd = sprintf(
                'openssl pkcs12 -in %s -passin pass:%s %s -nocerts -nodes -out %s 2>&1',
                escapeshellarg($certPath),
                escapeshellarg($password),
                $legacyFlag,
                escapeshellarg($tempKey)
            );

            exec($keyCmd, $keyOutput, $keyReturnCode);

            if ($keyReturnCode !== 0 || !file_exists($tempKey)) {
                Tools::log()->warning('failed-to-extract-private-key', [
                    '%error%' => implode(' ', $keyOutput)
                ]);
                self::cleanupTempFiles([$tempPem, $tempKey, $tempNew]);
                return '';
            }

            // Crear nuevo P12 con algoritmo moderno (sin -legacy)
            $createCmd = sprintf(
                'openssl pkcs12 -export -in %s -inkey %s -out %s -passout pass:%s -keypbe PBE-SHA1-3DES -certpbe PBE-SHA1-3DES 2>&1',
                escapeshellarg($tempPem),
                escapeshellarg($tempKey),
                escapeshellarg($tempNew),
                escapeshellarg($password)
            );

            exec($createCmd, $createOutput, $createReturnCode);

            if ($createReturnCode !== 0 || !file_exists($tempNew)) {
                Tools::log()->warning('failed-to-create-modern-certificate', [
                    '%error%' => implode(' ', $createOutput)
                ]);
                self::cleanupTempFiles([$tempPem, $tempKey, $tempNew]);
                return '';
            }

            // Verificar que el nuevo certificado funciona
            $newCertContent = file_get_contents($tempNew);
            if ($newCertContent === false || !@openssl_pkcs12_read($newCertContent, $testParsed, $password)) {
                Tools::log()->warning('converted-certificate-validation-failed');
                self::cleanupTempFiles([$tempPem, $tempKey, $tempNew]);
                return '';
            }

            // Limpiar archivos intermedios
            self::cleanupTempFiles([$tempPem, $tempKey]);

            // Reemplazar el certificado original con el convertido
            if (!@rename($tempNew, $certPath)) {
                Tools::log()->warning('failed-to-replace-original-certificate');
                self::cleanupTempFiles([$tempNew]);
                return '';
            }

            // Devolver la ruta al certificado original (ahora convertido)
            return $certPath;

        } catch (Exception $e) {
            Tools::log()->warning('exception-converting-certificate', [
                '%error%' => $e->getMessage()
            ]);
            self::cleanupTempFiles([$tempPem, $tempKey, $tempNew]);
            return '';
        }
    }

    private static function createCertificatePem(string $filePath, Empresa $company): bool
    {
        // obtenemos el nombre del archivo
        $fileName = basename($filePath);

        $destiny = self::getCertificateRoute($company);
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $pemPath = $destiny . '/' . str_replace('.' . $ext, '.pem', $fileName);

        $content = @file_get_contents($filePath);
        if ($content === false) {
            Tools::log()->error('verifactu-read-cert-file-failed', ['%file%' => $filePath]);
            return false;
        }

        // Intento 1: leer PKCS#12 directamente
        $certs = [];
        if (!@openssl_pkcs12_read($content, $certs, (string)$company->vf_password)) {
            // Intento 2: convertir contenedor legacy (RC2/Windows) y reintentar
            $convertedPath = self::convertLegacy($filePath, $content, (string)$company->vf_password);
            if (empty($convertedPath)) {
                Tools::log()->error('verifactu-pkcs12-read-failed', ['%file%' => $filePath]);
                return false;
            }

            $content = @file_get_contents($convertedPath);
            if ($content === false || !@openssl_pkcs12_read($content, $certs, (string)$company->vf_password)) {
                Tools::log()->error('verifactu-pkcs12-read-failed-after-convert', ['%file%' => $convertedPath]);
                return false;
            }
        }

        // Validaciones mínimas
        $leafCert = $certs['cert'] ?? '';
        $privKey = $certs['pkey'] ?? '';
        if ($leafCert === '' || $privKey === '') {
            Tools::log()->error('verifactu-missing-cert-or-key-in-pkcs12', ['%file%' => $filePath]);
            return false;
        }

        // Verificar que la clave y el certificado casan
        $x509 = @openssl_x509_read($leafCert);
        $pkey = @openssl_pkey_get_private($privKey, (string)$company->vf_password);
        if (!$x509 || !$pkey || !@openssl_x509_check_private_key($x509, $pkey)) {
            Tools::log()->error('verifactu-cert-key-mismatch-or-invalid');
            return false;
        }

        // Construir cadena intermedia (si existe)
        $chain = '';
        if (!empty($certs['extracerts'])) {
            if (is_array($certs['extracerts'])) {
                foreach ($certs['extracerts'] as $cacert) {
                    $chain .= rtrim(preg_replace("/\r\n?/", "\n", trim((string)$cacert))) . "\n";
                }
            } else {
                $chain = rtrim(preg_replace("/\r\n?/", "\n", trim((string)$certs['extracerts']))) . "\n";
            }
        }

        // Normalizar saltos de línea y ensamblar PEM: cert + key + chain
        $norm = static function (string $s): string {
            return rtrim(preg_replace("/\r\n?/", "\n", trim($s))) . "\n";
        };
        $pemContent = $norm($leafCert) . "\n" . $norm($privKey);
        if ($chain !== '') {
            $pemContent .= "\n" . $chain;
        }

        // Validación del PEM final en memoria
        $testX509 = @openssl_x509_read($pemContent);
        $testPkey = @openssl_pkey_get_private($pemContent, (string)$company->vf_password);
        if (!$testX509 || !$testPkey || !@openssl_x509_check_private_key($testX509, $testPkey)) {
            Tools::log()->error('verifactu-final-pem-validation-failed', ['%file%' => $pemPath]);
            return false;
        }

        // Escribir y fijar permisos
        if (@file_put_contents($pemPath, $pemContent) === false) {
            Tools::log()->error('verifactu-write-pem-failed', ['%file%' => $pemPath]);
            return false;
        }
        @chmod($pemPath, 0600);

        return true;
    }

    /**
     * Devuelve la ruta de la carpeta donde se guardan los certificados de la empresa.
     */
    private static function getCertificateRoute(Empresa $company): string
    {
        return Tools::folder('MyFiles', 'Verifactu', $company->id());
    }

    /**
     * Formatea el nombre del archivo para evitar caracteres no permitidos.
     */
    private static function getFormatName(string $fileName): string
    {
        return preg_replace('/[^a-zA-Z0-9\.\_\-]/', '', $fileName);
    }

    /**
     * Extrae todos los sujetos de los certificados raíz/intermedios autorizados.
     */
    private static function getTrustedIssuers(): array
    {
        $tsl = self::getTSL();
        if (empty($tsl)) {
            Tools::log()->warning('tsl-xml-is-empty');
            return [];
        }

        if (empty($tsl->TrustServiceProviderList->TrustServiceProvider)) {
            Tools::log()->warning('tsl-no-trust-service-providers');
            return [];
        }

        $issuers = [];
        foreach ($tsl->TrustServiceProviderList->TrustServiceProvider as $provider) {
            if (empty($provider->TSPServices->TSPService)) {
                continue;
            }

            foreach ($provider->TSPServices->TSPService as $service) {
                if (empty($service->ServiceInformation->ServiceDigitalIdentity)) {
                    continue;
                }

                foreach ($service->ServiceInformation->ServiceDigitalIdentity as $identity) {
                    if (empty($identity->DigitalId->X509Certificate)) {
                        continue;
                    }

                    foreach ($identity as $digital) {
                        if (empty($digital->X509Certificate)) {
                            continue;
                        }

                        // Certificado raíz/intermedio en base64
                        $certBase64 = (string)$digital->X509Certificate;

                        // Convertir a PEM
                        $pem = "-----BEGIN CERTIFICATE-----\n"
                            . chunk_split($certBase64, 64, "\n")
                            . "-----END CERTIFICATE-----\n";

                        $info = openssl_x509_parse($pem);
                        if (!$info) {
                            continue;
                        }

                        $issuers[] = $info['subject'];
                    }
                }
            }
        }

        return $issuers;
    }

    /**
     * Devuelve el XML de la TSL (desde cache o descargado).
     */
    private static function getTSL(): ?SimpleXMLElement
    {
        if (false === Tools::folderCheckOrCreate(self::CACHE_PATH)) {
            Tools::log()->warning('error-creating-tsl-cache-folder', [
                '%folder%' => Tools::folder(self::CACHE_PATH),
            ]);
            return null;
        }

        $filePath = Tools::folder(self::CACHE_PATH, self::CACHE_FILE);

        // Si existe en cache y no ha caducado → devolver cache
        if (file_exists($filePath)) {
            if ((time() - filemtime($filePath)) < self::CACHE_TTL) {
                return simplexml_load_file($filePath);
            }
        }

        // Descargar la TSL oficial
        $xml = @file_get_contents(self::TSL_URL);
        if (!$xml) {
            return file_exists($filePath)
                ? simplexml_load_file($filePath) // fallback
                : null;
        }

        // Guardar cache
        if (false === file_put_contents($filePath, $xml)) {
            Tools::log()->warning('error-saving-tsl-cache', [
                '%file%' => $filePath,
            ]);
        }

        return simplexml_load_string($xml);
    }

    /**
     * Comprueba si el certificado permite autenticación cliente (necesario para conectar con Hacienda).
     */
    private static function hasClientAuthCapability(array $certInfo): bool
    {
        // Verificar extendedKeyUsage para Client Authentication
        if (isset($certInfo['extensions']['extendedKeyUsage'])) {
            $eku = strtoupper($certInfo['extensions']['extendedKeyUsage']);

            // Client Authentication es el OID 1.3.6.1.5.5.7.3.2
            if (
                str_contains($eku, 'TLS WEB CLIENT AUTHENTICATION') ||
                str_contains($eku, 'CLIENT AUTH') ||
                str_contains($eku, '1.3.6.1.5.5.7.3.2')
            ) {
                return true;
            }
        }

        // Algunos certificados cualificados incluyen Client Auth implícitamente
        // mediante políticas específicas
        if (isset($certInfo['extensions']['certificatePolicies'])) {
            $policies = $certInfo['extensions']['certificatePolicies'];

            // OIDs de políticas que típicamente incluyen autenticación
            $authPolicies = [
                '1.3.6.1.4.1.18332.5.1.1.1', // FNMT Persona Física
                '1.3.6.1.4.1.5734.3.4',      // FNMT Componente Cualificado
                '0.4.0.194112.1.2',          // eIDAS Natural Person
            ];

            foreach ($authPolicies as $oid) {
                if (str_contains($policies, $oid)) {
                    return true;
                }
            }
        }

        Tools::log()->warning('error-cert-no-client-auth-capability', [
            '%extendedKeyUsage%' => $certInfo['extensions']['extendedKeyUsage'] ?? 'No definido',
        ]);
        return false;
    }

    /**
     * Comprueba si el certificado es un certificado cualificado según OIDs conocidos (eIDAS).
     */
    private static function isQualifiedCertificate(array $certInfo): bool
    {
        if (empty($certInfo['extensions']['certificatePolicies'])) {
            Tools::log()->warning('error-cert-no-certificate-policies');
            return false;
        }

        $policies = $certInfo['extensions']['certificatePolicies'];

        // OIDs asociados a certificados cualificados y QCStatements comunes
        $qualifiedOids = [
            // ETSI QCP-n
            '0.4.0.1862.1.1',

            // ETSI QCP-l
            '0.4.0.1862.1.4',

            // EU Qualified Seal Certificate
            '0.4.0.194112.1.0',

            // Camerfirma QCP OIDs
            '1.3.6.1.4.1.15096.10.3.3',
            '1.3.6.1.4.1.15096.10.3.5',
            '1.3.6.1.4.1.15096.10.3.8',

            // Firmaprofesional (QCStatements)
            '1.3.6.1.4.1.13177.10.1.6',
            '1.3.6.1.4.1.13177.10.1.8',

            // EADTrust Qualified Certificates
            '1.3.6.1.4.1.31495.3.1.1',
            '1.3.6.1.4.1.31495.3.1.2',

            // ACCV Qualified Certificates
            '1.3.6.1.4.1.18784.1.2.1',
            '1.3.6.1.4.1.18784.1.2.2',

            // Izenpe Qualified Certificates
            '1.3.6.1.4.1.14777.6.1.1',
            '1.3.6.1.4.1.14777.6.1.2',

            // FNMT — QCStatements additional identifiers
            '2.16.724.1.2.2.2.4',
            '2.16.724.1.2.2.2.5',
        ];

        foreach ($qualifiedOids as $oid) {
            if (str_contains($policies, $oid)) {
                return true;
            }
        }

        Tools::log()->warning('error-cert-not-qualified-policies', ['%policies%' => $policies]);
        return false;
    }

    /**
     * Comprueba si una CRL (en binario o PEM) contiene el serial dado.
     */
    private static function checkCrlContainsSerial(string $crlContent, string $serial): bool
    {
        // Normalizar serial: openssl_x509_parse devuelve hex sin 0x y puede tener mayúsculas
        $serialNorm = strtoupper(preg_replace('/[^A-F0-9]/', '', $serial));

        // Intentar usar openssl to parse CRL via temp file and `openssl crl -inform` if CLI disponible
        if (self::opensslCliAvailable()) {
            $tmp = sys_get_temp_dir() . '/crl_' . uniqid() . '.crl';
            @file_put_contents($tmp, $crlContent);
            @exec(sprintf('openssl crl -in %s -noout -text 2>&1', escapeshellarg($tmp)), $out, $ret);
            @unlink($tmp);
            if ($ret === 0 && !empty($out)) {
                $text = implode("\n", $out);
                // Buscar el serial en el texto de la CRL
                if (stripos($text, $serialNorm) !== false) {
                    return true;
                }
            }
        }

        // Fallback: buscar el serial tal cual en el contenido (útil si CRL en texto)
        if (stripos($crlContent, $serialNorm) !== false) {
            return true;
        }

        return false;
    }

    /**
     * Comprueba si el certificado permite firmar (keyUsage y extendedKeyUsage).
     */
    private static function hasSigningCapability(array $certInfo): bool
    {
        // Comprobación en keyUsage
        if (isset($certInfo['extensions']['keyUsage'])) {
            $keyUsage = strtoupper($certInfo['extensions']['keyUsage']);
            if (
                str_contains($keyUsage, 'DIGITAL SIGNATURE') ||
                str_contains($keyUsage, 'NON REPUDIATION')
            ) {
                return true;
            }
        }

        // Comprobación en extendedKeyUsage
        if (isset($certInfo['extensions']['extendedKeyUsage'])) {
            $eku = strtoupper($certInfo['extensions']['extendedKeyUsage']);
            if (
                str_contains($eku, 'CODE SIGNING') ||
                str_contains($eku, 'EMAIL PROTECTION') ||
                str_contains($eku, 'CLIENT AUTH') ||
                str_contains($eku, 'SERVER AUTH')
            ) {
                return true;
            }
        }

        Tools::log()->warning('error-cert-no-signing-capability');
        return false;
    }

    /**
     * Comprueba si un archivo es un certificado P12/PFX binario.
     */
    private static function isBinaryP12(string $certContent): bool
    {
        // 1) Detectar si contiene cabeceras PEM
        if (str_contains($certContent, '-----BEGIN')) {
            Tools::log()->info('certificate-is-pem-format');
            return false; // NO es binario, es PEM
        }

        // 2) Comprobar si los primeros bytes son ASN.1 SEQUENCE (0x30 ...)
        $bytes = unpack('C*', substr($certContent, 0, 2));
        if (empty($bytes)) {
            Tools::log()->warning('cannot-unpack-certificate-bytes');
            return false;
        }

        // A veces 0x30 0x81, o incluso 0x30 0x83, 0x30 0x84, 0x30 0x86
        if ($bytes[1] === 0x30 && in_array($bytes[2], [0x81, 0x82, 0x83, 0x84, 0x86])) {
            return true;
        }

        // Si llega aquí, probablemente NO es un P12 binario válido
        Tools::log()->info('certificate-is-not-binary-p12');
        return false;
    }

    /**
     * Comprueba si el certificado ha expirado, si no, guardamos la fecha de expiración.
     */
    private static function isExpiredCertificate(Empresa &$company, array $certInfo, string $filePath): bool
    {
        $currentTime = time();
        if ($currentTime < $certInfo['validFrom_time_t'] || $currentTime > $certInfo['validTo_time_t']) {
            Tools::log()->warning('error-cert-expired', [
                '%file%' => $filePath,
                '%valid_from%' => date('Y-m-d H:i:s', $certInfo['validFrom_time_t']),
                '%valid_to%' => date('Y-m-d H:i:s', $certInfo['validTo_time_t']),
            ]);
            return false;
        }

        // guardamos la fecha de expiración en la empresa, está como timestamp la pasamos a date
        $company->vf_certificate_expiration = date(Tools::DATE_STYLE, $certInfo['validTo_time_t']);
        return true;
    }

    /**
     * Comprueba si el emisor del certificado coincide con algún "subject" de la TSL.
     */
    private static function isIssuerTrusted(array $certInfo): bool
    {
        if (empty($certInfo['issuer'])) {
            Tools::log()->warning('error-cert-issuer-is-empty');
            return false;
        }

        $issuer = $certInfo['issuer'];
        $trustedSubjects = self::getTrustedIssuers();
        if (empty($trustedSubjects)) {
            Tools::log()->warning('tsl-trusted-issuers-empty');
            return false;
        }

        foreach ($trustedSubjects as $trusted) {
            // Construir DN completo del issuer y del trusted
            $issuerDn = '';
            foreach (['CN', 'O', 'OU', 'L', 'ST', 'C', 'serialNumber', 'organizationIdentifier'] as $field) {
                if (!empty($issuer[$field]) && !is_array($issuer[$field])) {
                    $issuerDn .= $field . '=' . $issuer[$field] . ',';
                }
            }
            $issuerDn = rtrim($issuerDn, ',');

            $trustedDn = '';
            foreach (['CN', 'O', 'OU', 'L', 'ST', 'C', 'serialNumber', 'organizationIdentifier'] as $field) {
                if (!empty($trusted[$field]) && !is_array($trusted[$field])) {
                    $trustedDn .= $field . '=' . $trusted[$field] . ',';
                }
            }
            $trustedDn = rtrim($trustedDn, ',');

            // Comparación completa del DN
            if (strcasecmp($issuerDn, $trustedDn) === 0) {
                return true;
            }

            // Comparación por CN, O y serialNumber como fallback
            if (
                (!empty($trusted['CN']) && !empty($issuer['CN']) && $trusted['CN'] === $issuer['CN']) ||
                (!empty($trusted['O']) && !empty($issuer['O']) && $trusted['O'] === $issuer['O']) ||
                (!empty($trusted['serialNumber']) && !empty($issuer['serialNumber']) && $trusted['serialNumber'] === $issuer['serialNumber'])
            ) {
                return true;
            }
        }

        Tools::log()->warning('issuer-not-allowed-tsl', [
            '%issuer%' => $certInfo['issuer']['CN'] ?? 'Desconocido',
        ]);
        return false;
    }

    /**
     * Comprueba si un certificado es de tipo representante.
     */
    private static function isRepresentativeCertificate(Empresa &$company, array $certInfo): bool
    {
        $nameRepresentative = null;
        $nifRepresentative = null;

        // Lista de patrones mejorada para detectar representantes
        $patterns = [
            // Formatos FNMT clásicos
            '/R:\s*([A-Z0-9]+)/i',
            '/REP:\s*([A-Z0-9]+)/i',

            // Variantes largas
            '/REPRESENTANTE:\s*([A-Z0-9]+)/i',
            '/REPRESENTANT:\s*([A-Z0-9]+)/i',

            // Formato usado por Camerfirma / Izenpe
            '/R\s*=\s*([A-Z0-9]+)/i',
            '/REPRESENTANTE\s*=\s*([A-Z0-9]+)/i',

            // Formatos con “ES” delante (VAT-style)
            '/R:\s*ES([A-Z0-9]+)/i',
            '/REP:\s*ES([A-Z0-9]+)/i',
            '/REPRESENTANTE:\s*ES([A-Z0-9]+)/i',

            // Certificados que incluyen el NIF del representante en serialNumber
            '/serialNumber=.*?([0-9]{7,8}[A-Z])/i',

            // Variantes informales encontradas en certificados antiguos
            '/REPRESENTANT\s*ID:\s*([A-Z0-9]+)/i',
            '/AGENT\s*ID:\s*([A-Z0-9]+)/i',
        ];

        // Extraer nombre y NIF del representante usando los patrones
        $subjectFields = [
            $certInfo['subject']['CN'] ?? '',
            $certInfo['subject']['serialNumber'] ?? '',
            $certInfo['subject']['O'] ?? '',
            $certInfo['subject']['OU'] ?? '',
            $certInfo['subject']['description'] ?? '',
        ];
        $subjectString = implode(' ', $subjectFields);

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $subjectString, $matches)) {
                $nifRepresentative = $matches[1];
                // Extraer nombre si es posible (buscar el texto antes del patrón)
                if (!empty($certInfo['subject']['CN'])) {
                    // Buscar nombre antes del patrón
                    if (preg_match('/^([A-Z0-9]+)\s+(.+?)\s*\(?.*' . str_replace('/', '\/', $pattern) . '/i', $certInfo['subject']['CN'], $nameMatches)) {
                        $nameRepresentative = trim($nameMatches[2]);
                    }
                }
                break;
            }
        }

        // Si no se detecta por patrones, intentar heurística previa (legacy)
        if ($nifRepresentative === null && !empty($certInfo['subject']['serialNumber'])) {
            if (preg_match('/([0-9]{7,8}[A-Z])/', $certInfo['subject']['serialNumber'], $matches)) {
                $nifRepresentative = $matches[1];
            }
        }

        $company->vf_certificate_representative_cif = $nifRepresentative;
        $company->vf_certificate_representative_name = $nameRepresentative;
        return true;
    }

    /**
     * Comprueba si un certificado es de tipo sello electrónico.
     */
    private static function isSealCertificate(array $certInfo): bool
    {
        // OIDs específicos para certificados de sello electrónico
        $sealOIDs = [
            '0.4.0.1862.1.4',   // QCP-l: Policy for EU qualified certificate for electronic seals
            '0.4.0.1862.1.5',   // QCP-l-qscd: Policy for EU qualified certificate for electronic seals on QSCD
            '1.3.6.1.4.1.5734.3.5', // FNMT Certificado de Sello Electrónico
        ];

        // Verificar si el certificado tiene algún OID de sello electrónico
        if (isset($certInfo['extensions']['certificatePolicies'])) {
            $policies = $certInfo['extensions']['certificatePolicies'];
            foreach ($sealOIDs as $oid) {
                if (str_contains($policies, $oid)) {
                    return true;
                }
            }
        }

        // Verificar en el subject o subject alternative name si contiene "SELLO ELECTRONICO" o similar
        $subjectFields = ['CN', 'OU', 'O', 'description'];
        foreach ($subjectFields as $field) {
            if (isset($certInfo['subject'][$field])) {
                $value = strtoupper($certInfo['subject'][$field]);
                if (str_contains($value, 'SELLO ELECTRONICO') ||
                    str_contains($value, 'SELLO ELECTRÓNICO') ||
                    str_contains($value, 'ELECTRONIC SEAL')) {
                    return true;
                }
            }
        }

        // Comprobar en extensiones específicas
        if (isset($certInfo['extensions']['subjectAltName'])) {
            $altName = strtoupper($certInfo['extensions']['subjectAltName']);
            if (str_contains($altName, 'SELLO ELECTRONICO') ||
                str_contains($altName, 'SELLO ELECTRÓNICO') ||
                str_contains($altName, 'ELECTRONIC SEAL')) {
                return true;
            }
        }

        return false;
    }

    /**
     * Comprueba si el CLI de OpenSSL está disponible.
     */
    private static function opensslCliAvailable(): bool
    {
        // si exec está deshabilitado, no podremos usar el CLI
        if (!function_exists('exec')) {
            return false;
        }

        // probar a ejecutar `openssl version`
        @exec('openssl version 2>&1', $output, $returnCode);
        if ($returnCode === 0 && !empty($output)) {
            return true;
        }

        // fallback: intentar localizar el binario con which (Unix) o where (Windows)
        if (stripos(PHP_OS_FAMILY, 'Windows') === 0) {
            @exec('where openssl 2>&1', $out2, $ret2);
            return ($ret2 === 0 && !empty($out2));
        }

        // Unix-like
        @exec('which openssl 2>&1', $out2, $ret2);
        return ($ret2 === 0 && !empty($out2));
    }

    /**
     * Comprueba que el subject del certificado coincide con la empresa (NIF/CIF) o que el certificado es representante/sello ya detectado.
     */
    private static function subjectMatchesCompany(Empresa $company, array $certInfo): bool
    {
        // Si está marcado como sello o representante ya, aceptamos
        if (!empty($company->vf_certificate_seal)) {
            return true;
        }
        // Extras: si ya extrajimos representante, aceptamos (suponemos que funcionó previamente)
        if (!empty($company->vf_certificate_representative_cif)) {
            return true;
        }

        if (empty($company->cifnif)) {
            Tools::log()->warning('company-cifnif-is-empty');
            return false;
        }

        $companyIdNorm = FiscalNumberValidator::normaliceCifNif($company->cifnif, '/^[A-Z0-9]{1,9}$/');

        // Buscar companyIdNorm en el subject CN, serialNumber u otros campos
        $subjectFields = ['CN', 'serialNumber', 'OU', 'O', 'DN'];
        foreach ($subjectFields as $field) {
            if (!empty($certInfo['subject'][$field])) {
                $value = FiscalNumberValidator::normaliceCifNif($certInfo['subject'][$field], '/^[A-Z0-9]{1,9}$/');
                if (str_contains($value, $companyIdNorm) || str_contains($companyIdNorm, $value)) {
                    return true;
                }
            }
        }

        Tools::log()->warning('error-cert-subject-does-not-match-company', [
            '%company_id%' => $companyIdNorm
        ]);
        return false;
    }

    /**
     * Prueba la conexión TLS con el certificado PEM generado.
     */
    public static function testPemConnection(Empresa $company): bool
    {
        $pemPath = self::getCertificatePem($company);
        if (empty($pemPath) || !is_readable($pemPath)) {
            Tools::log()->error('verifactu-pem-not-found', ['%file%' => $pemPath ?: 'N/A']);
            return false;
        }

        $host = $company->vf_debug_mode ? 'prewww2.aeat.es' : 'www2.agenciatributaria.gob.es';

        $context = stream_context_create([
            'ssl' => [
                'local_cert' => $pemPath,
                'passphrase' => (string)$company->vf_password,
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false,
                'SNI_server_name' => $host,
                'crypto_method' => STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT : 0),
            ]
        ]);

        $errno = 0;
        $errstr = '';
        $client = @stream_socket_client(
            'ssl://' . $host . ':443',
            $errno,
            $errstr,
            10,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!$client) {
            Tools::log()->error('verifactu-connection-failed', [
                '%host%' => $host,
                '%error%' => "[$errno] $errstr"
            ]);
            return false;
        }

        fclose($client);
        return true;
    }

    /**
     * Válida si el certificado cumple con los requisitos de la normativa española y europea.
     * Comprueba si el certificado ha sido emitido por un proveedor cualificado en la lista TSL.
     */
    private static function validateCertificate(string $filePath, Empresa &$company): bool
    {
        if (!file_exists($filePath)) {
            Tools::log()->warning('certificate-file-not-found', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        $certContent = file_get_contents($filePath);
        if (false === $certContent) {
            Tools::log()->warning('cannot-read-certificate-file', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        // Comprobar que el archivo realmente es un P12/PFX binario
        if (!self::isBinaryP12($certContent)) {
            return false;
        }

        $filePath = self::convertLegacy($filePath, $certContent, $company->vf_password);
        if (empty($filePath)) {
            Tools::log()->warning('error-convert-legacy-cert', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        // Extraer la información del certificado
        $certData = [];
        if (false === openssl_pkcs12_read(file_get_contents($filePath), $certData, $company->vf_password)) {
            Tools::log()->warning('error-read-cert', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        // Verificar el formato del certificado
        if (empty($certData['cert'])) {
            Tools::log()->warning('error-cert-no-data', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        // Obtener los detalles del certificado
        $certInfo = openssl_x509_parse($certData['cert']);
        if (false === $certInfo) {
            Tools::log()->warning('error-parse-cert', [
                '%file%' => $filePath,
            ]);
            return false;
        }

        // Validar el período de validez
        if (false === self::isExpiredCertificate($company, $certInfo, $filePath)) {
            return false;
        }

        // Validación contra la TSL oficial para comprobar el emisor
        if (false === self::isIssuerTrusted($certInfo)) {
            return false;
        }

        // Comprobar que es un certificado cualificado (eIDAS)
        if (false === self::isQualifiedCertificate($certInfo)) {
            return false;
        }

        // Comprobar revocación (OCSP/CRL)
        if (false === self::checkRevocation($certInfo, $filePath)) {
            return false;
        }

        // Comprobamos si es un certificado de sello electrónico
        $company->vf_certificate_seal = self::isSealCertificate($certInfo);

        // Comprobamos si es un certificado de representante
        if (false === self::isRepresentativeCertificate($company, $certInfo)) {
            return false;
        }

        // Comprobar que el subject coincide con la empresa (NIF/CIF) o que es representante/sello
        if (false === self::subjectMatchesCompany($company, $certInfo)) {
            return false;
        }

        // Comprobar que el certificado permite firmar
        if (false === self::hasSigningCapability($certInfo)) {
            return false;
        }

        // Comprobar que el certificado permite autenticación cliente (necesario para Hacienda)
        if (false === self::hasClientAuthCapability($certInfo)) {
            return false;
        }

        return true;
    }
}
