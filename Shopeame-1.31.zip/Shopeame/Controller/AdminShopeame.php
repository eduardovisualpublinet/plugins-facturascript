<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2024, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\CodeModel;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\ApiKey;
use FacturaScripts\Dinamic\Model\Empresa;
use FacturaScripts\Plugins\Shopeame\Lib\Shopeame\ApiClient;
use FacturaScripts\Plugins\Shopeame\Model\Shopeame;

/**
 * Description of AdminShopeame
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class AdminShopeame extends Controller
{
    /** @var string */
    public $adminLink = '';

    /** @var CodeModel */
    public $codeModel;

    /** @var array */
    public $setup = [];

    /** @var Shopeame[] */
    public $shops = [];

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'admin';
        $data['title'] = 'shopea.me';
        $data['icon'] = 'fa-solid fa-store';
        return $data;
    }

    public function privateCore(&$response, $user, $permissions)
    {
        parent::privateCore($response, $user, $permissions);

        $this->codeModel = new CodeModel();
        $this->loadShopeameSetup();
        $this->loadShops();

        $action = $this->request->get('action');
        switch ($action) {
            case 'list-shops':
                $this->listShops();
                break;

            case 'register':
                $this->registerAction();
                break;

            case 'unregister':
                $this->unregisterAction();
                break;
        }
    }

    public function publicCore(&$response)
    {
        parent::publicCore($response);

        $this->loadShops();

        $action = $this->request->get('action');
        if ($action == 'unregister') {
            $this->unregisterShopeameAction();
        }
    }

    private function getApiKey(): ApiKey
    {
        // enable API support
        Tools::settingsSet('default', 'enable_api', true);
        Tools::settingsSave();

        // get API key
        $apiKey = new ApiKey();
        $where = [new DataBaseWhere('description', 'shopea.me')];
        if (false === $apiKey->loadWhere($where)) {
            $apiKey->description = 'shopea.me';
            $apiKey->nick = $this->user->nick;
        }

        $apiKey->enabled = true;
        $apiKey->fullaccess = true;
        $apiKey->save();

        return $apiKey;
    }

    private function getSiteUrl(): string
    {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $url = $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        return substr($url, 0, strrpos($url, '/'));
    }

    private function loadShopeameSetup(): void
    {
        $this->setup['connid'] = Tools::settings('shopeame', 'connid');
        $this->setup['signkey'] = Tools::settings('shopeame', 'signkey');
        $this->adminLink = ApiClient::adminLink($this->setup);
    }

    private function listShops(): void
    {
        $this->setTemplate(false);

        $html = '';
        if (empty($this->shops)) {
            $this->response->setContent(json_encode(['html' => $html]));
            return;
        }

        $html = '<h2 class="h4 mt-5">'
            . '<i class="fa-solid fa-store fa-fw"></i> ' . Tools::lang()->trans('shops')
            . '</h2>'
            . '<ul>';

        foreach ($this->shops as $shop) {
            $html .= '<li>' . $shop->title . '</li>';
        }

        $html .= '</ul>';

        $this->response->setContent(json_encode(['shops' => $html]));
    }

    private function loadShops(): void
    {
        $shopeame = new Shopeame();
        $this->shops = $shopeame->all();
    }

    private function registerAction(): void
    {
        if (false === $this->validateFormToken()) {
            return;
        }

        $company = new Empresa();
        $idempresa = $this->request->request->get('idempresa');
        if (false === $company->load($idempresa)) {
            Tools::log()->warning('no-company');
            return;
        }

        $results = ApiClient::register($this->getSiteUrl(), $this->getApiKey()->apikey, $company);
        if (isset($results['error'])) {
            Tools::log()->warning($results['error']);
            return;
        } elseif (ApiClient::getHttpCode() !== 200) {
            Tools::log()->warning('ERROR: ' . ApiClient::getHttpCode());
            return;
        }

        Tools::settingsSet('shopeame', 'connid', $results['newid']);
        Tools::settingsSet('shopeame', 'signkey', $results['signkey']);
        Tools::settingsSave();

        $this->loadShopeameSetup();
    }

    private function unregisterAction(): void
    {
        $confirm = (bool)$this->request->request->get('confirm', 0);
        if (false === $confirm) {
            Tools::log()->warning('are-you-sure');
            return;
        } elseif (false === $this->validateFormToken()) {
            return;
        }

        // send
        $results = ApiClient::unregister($this->setup['connid'], $this->setup['signkey']);
        if (isset($results['error']) && $results['error'] !== 'connection-not-found') {
            Tools::log()->warning($results['error']);
            return;
        }

        // remove shops
        foreach ($this->shops as $shop) {
            $shop->delete();
        }

        // remove shopeame id
        Tools::settingsSet('shopeame', 'connid', null);
        Tools::settingsSet('shopeame', 'signkey', null);
        Tools::settingsSave();

        // remove API key
        $this->getApiKey()->delete();

        Tools::log()->notice('record-deleted-correctly');
        $this->loadShopeameSetup();
    }

    private function unregisterShopeameAction(): void
    {
        $conn_id = $this->request->get('id', '');
        $sign_key = $this->request->get('key', '');

        if ($conn_id != Tools::settings('shopeame', 'connid') ||
            $sign_key != Tools::settings('shopeame', 'signkey')) {
            return;
        }

        // remove shops
        foreach ($this->shops as $shop) {
            $shop->delete();
        }

        // remove shopeame id
        Tools::settingsSet('shopeame', 'connid', null);
        Tools::settingsSet('shopeame', 'signkey', null);
        Tools::settingsSave();

        // remove API key
        $this->getApiKey()->delete();
    }
}
