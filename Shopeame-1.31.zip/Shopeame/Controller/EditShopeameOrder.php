<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2024, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\Shopeame\DeployOrder;
use FacturaScripts\Dinamic\Model\CodeModel;
use FacturaScripts\Plugins\Shopeame\Model\ShopeameOrder;

/**
 * Description of EditShopeameOrder
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class EditShopeameOrder extends Controller
{
    /** @var ShopeameOrder */
    public $order;

    public function getAllOrderStatus(): array
    {
        $codeModel = new CodeModel();
        $status = $codeModel->all('shopeame_orders', 'status', 'status', false);
        foreach ($status as $key => $value) {
            if ($value->code) {
                $status[$key]->description = Tools::lang()->trans($value->description);
            }
        }

        return $status;
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'order';
        $data['icon'] = 'fa-solid fa-store';
        $data['showonmenu'] = false;
        return $data;
    }

    public function privateCore(&$response, $user, $permissions)
    {
        parent::privateCore($response, $user, $permissions);

        $this->loadOrder();

        $action = $this->request->get('action');
        switch ($action) {
            case 'generate-invoice':
                $this->generateInvoiceAction();
                break;

            case 'native-order':
                $this->generateNativeOrderAction();
                break;
        }
    }

    private function generateInvoiceAction(): void
    {
        if (false === $this->order->exists() || $this->order->getInvoice()->exists()) {
            return;
        }

        if (DeployOrder::invoice($this->order, $this->user->nick)) {
            // force order status check
            $this->order->save();
            Tools::log()->notice('record-updated-correctly');
            return;
        }

        Tools::log()->warning('record-save-error');
    }

    private function generateNativeOrderAction(): void
    {
        if (false === $this->order->exists() || $this->order->getNativeOrder()->exists()) {
            return;
        }

        if (DeployOrder::nativeOrder($this->order, $this->user->nick)) {
            // force order status check
            $this->order->save();
            Tools::log()->notice('record-updated-correctly');
            return;
        }

        Tools::log()->warning('record-save-error');
    }

    private function loadOrder(): void
    {
        $this->order = new ShopeameOrder();
        $code = $this->request->query->get('code');
        if (empty($code) || false === $this->order->load($code)) {
            Tools::log()->warning('record-not-found');
        }
    }
}
