<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\Model\Base;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Variante;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;

/**
 * Description of ShopeameOrderLine
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class ShopeameOrderLine extends ModelClass
{
    use ModelTrait;

    /** @var string */
    public $description;

    /** @var int */
    public $id;

    /** @var int */
    public $idorder;

    /** @var float */
    public $price;

    /** @var float */
    public $quantity;

    /** @var float */
    public $pcttax;

    /** @var string */
    public $reference;

    /** @var float */
    public $totaltaxex;

    /** @var float */
    public $totaltaxin;

    public function clear(): void
    {
        parent::clear();
        $this->price = 0.0;
        $this->quantity = 0.0;
        $this->totaltaxex = 0.0;
        $this->totaltaxin = 0.0;
        $this->pcttax = 0.0;
    }

    public function getOrder(): ShopeameOrder
    {
        $order = new ShopeameOrder();
        $order->load($this->idorder);
        return $order;
    }

    public function getVariant(): ?Variante
    {
        $variant = new Variante();
        $where = [new DataBaseWhere('referencia', $this->reference)];
        return $variant->loadWhere($where) ? $variant : null;
    }

    public function install(): string
    {
        // dependencias
        new ShopeameOrder();

        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return 'id';
    }

    public static function tableName(): string
    {
        return 'shopeame_orders_lines';
    }

    public function test(): bool
    {
        // escapamos el html
        $this->description = Tools::noHtml($this->description);

        // si no tenemos un porcentaje de IVA, lo calculamos
        if (empty($this->pcttax)) {
            $this->setPctTax();
        }

        return parent::test();
    }

    private function setPctTax(): void
    {
        // si el precio sin IVA es igual al precio con IVA, no hay IVA
        if (abs($this->totaltaxex - $this->totaltaxin) < 0.01) {
            $this->pcttax = 0.0;
            return;
        }

        // si el precio con IVA es cero, no hay IVA
        if (empty($this->totaltaxin)) {
            $this->pcttax = 0.0;
            return;
        }

        // calculamos el porcentaje de IVA
        $subtotalTax = $this->totaltaxin - $this->totaltaxex;
        $this->pcttax = round(($subtotalTax / $this->totaltaxex) * 100, 2);

        // buscamos el impuesto más similar de entre los que tenemos
        foreach (Impuestos::all() as $tax) {
            if (abs($this->pcttax - $tax->iva) < 0.1) {
                $this->pcttax = $tax->iva;
                return;
            }
        }

        // si hay una referencia, comparamos con el IVA de la variante
        if ($this->reference) {
            $variant = $this->getVariant();
            if ($variant) {
                $iva = $variant->getProducto()->getTax()->iva;
                if (abs($this->totaltaxin - ($this->totaltaxex * (100 + $iva) / 100)) < 0.1) {
                    $this->pcttax = $iva;
                    return;
                }
            }
        }
    }
}
