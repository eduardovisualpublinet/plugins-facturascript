<?php
/**
 * @copyright 2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Extension\Model;

use Closure;
use FacturaScripts\Plugins\Shopeame\Model\ShopeameOrder;

/**
 * @author Daniel fernández Giménez <hola@danielfg.es>
 */
class FacturaCliente
{
    public function delete(): Closure
    {
        return function() {
            $so = $this->getShopeameOrder();
            if (!empty($so->id())) {
                $so->status = ShopeameOrder::STATUS_PENDING;
                $so->save();
            }
        };
    }

    public function getShopeameOrder(): Closure
    {
        return function(): ShopeameOrder {
            $so = new ShopeameOrder();
            $so->load($this->idshopeameorder);
            return $so;
        };
    }
}
