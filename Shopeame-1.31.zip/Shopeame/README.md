# Shopeame
Conector con tiendas online a través del servicio web shopea.me
- https://facturascripts.com/plugins/shopeame

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **Shopeame**.

### Pruebas
Para probar contra el servidor de pruebas de shopeame, se debe definir las constantes SHOPEAME_URL y
SHOPEAME_URL_INTERNAL en el fichero **config.php**.