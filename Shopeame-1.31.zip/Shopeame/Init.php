<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\ApiKey;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\PedidoCliente;
use FacturaScripts\Plugins\Shopeame\Lib\Shopeame\ApiClient;

/**
 * Description of Init
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Controller\EditFacturaCliente());
        $this->loadExtension(new Extension\Model\FacturaCliente());
        $this->loadExtension(new Extension\Model\AlbaranCliente());
        $this->loadExtension(new Extension\Model\PedidoCliente());
    }

    public function uninstall(): void
    {
        $this->disabledApi();
    }

    public function update(): void
    {
        new Model\Shopeame();

        // Verificamos y limpiamos duplicados antes de crear la tabla para evitar error en la restricción única
        $this->checkAndRemoveDuplicateOrders();

        new Model\ShopeameOrder();
        new FacturaCliente();
        new PedidoCliente();

        $this->enabledApi();
    }

    private function checkAndRemoveDuplicateOrders(): void
    {
        $db = new DataBase();
        $db->connect();

        // Verificamos si la tabla existe
        if (false === $db->tableExists('shopeame_orders')) {
            return;
        }

        // Verificamos si hay duplicados
        $sqlCheckDuplicates = "SELECT idshop, idorder, COUNT(*) as total "
            . "FROM shopeame_orders "
            . "GROUP BY idshop, idorder "
            . "HAVING COUNT(*) > 1";

        $duplicates = $db->select($sqlCheckDuplicates);
        if (empty($duplicates)) {
            // No hay duplicados
            return;
        }

        // Reportamos los duplicados encontrados
        $totalDuplicates = count($duplicates);
        Tools::log('shopeame')->warning("Se encontraron {$totalDuplicates} combinaciones duplicadas de (idshop, idorder) en shopeame_orders");

        // Eliminamos los duplicados, manteniendo solo el registro con el id más bajo
        // (el registro original) para cada combinación de idshop e idorder
        $sql = "DELETE FROM shopeame_orders "
            . "WHERE id IN ( "
            . "    SELECT so1.id FROM shopeame_orders so1 "
            . "    INNER JOIN ( "
            . "        SELECT idshop, idorder, MIN(id) as min_id "
            . "        FROM shopeame_orders "
            . "        GROUP BY idshop, idorder "
            . "        HAVING COUNT(*) > 1 "
            . "    ) so2 ON so1.idshop = so2.idshop AND so1.idorder = so2.idorder "
            . "    WHERE so1.id > so2.min_id"
            . ")";

        if ($db->exec($sql)) {
            Tools::log()->notice("Se eliminaron los pedidos duplicados de shopeame_orders, manteniendo solo el registro original de cada combinación");
        } else {
            Tools::log()->error('Error al eliminar pedidos duplicados de shopeame_orders');
        }
    }

    private function disabledApi(): void
    {
        // buscamos la clave de la api
        $api = new ApiKey();
        $where = [new DataBaseWhere('description', 'shopea.me')];
        if (false === $api->loadWhere($where)) {
            // no hay, no hacemos nada
            return;
        }

        $api->enabled = false;
        $api->save();
    }

    private function enabledApi(): void
    {
        // buscamos la clave de la api
        $api = new ApiKey();
        $where = [new DataBaseWhere('description', 'shopea.me')];
        if (false === $api->loadWhere($where)) {
            // no hay, no hacemos nada
            return;
        }

        // la habilitamos
        $api->enabled = true;
        $api->fullaccess = true;
        $api->save();

        // actualizamos los datos de conexión
        ApiClient::update(
            Tools::settings('shopeame', 'connid', ''),
            Tools::settings('shopeame', 'signkey', '')
        );
    }
}
