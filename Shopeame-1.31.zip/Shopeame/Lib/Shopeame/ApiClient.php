<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Lib\Shopeame;

use FacturaScripts\Core\Kernel;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Session;
use FacturaScripts\Dinamic\Model\Empresa;

/**
 * Description of ApiClient
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class ApiClient extends ApiCore
{
    const VERSION = 1;

    public static function adminLink(array $setup): string
    {
        $num = mt_rand();
        $hash = sha1($setup['signkey'] . $num);
        $admin_url = defined('SHOPEAME_URL') ? SHOPEAME_URL : 'https://shopea.me';

        return $admin_url . '/EditErpLink?code=' . $setup['connid']
            . '&hash=' . $hash
            . '&num=' . $num
            . '&user_email=' . urlencode(Session::user()->email);
    }

    public static function apiUrl(): string
    {
        return defined('SHOPEAME_URL_INTERNAL') ? SHOPEAME_URL_INTERNAL : 'https://shopea.me';
    }

    /**
     * @param string $url
     * @param string $apikey
     * @param Empresa $company
     *
     * @return ?array
     */
    public static function register(string $url, string $apikey, $company): ?array
    {
        $plugin_list = [];
        foreach (Plugins::list() as $plugin) {
            if ($plugin->enabled) {
                $plugin_list[] = $plugin->name . '|' . $plugin->version;
            }
        }

        $input = [
            'action' => 'register',
            'apikey' => $apikey,
            'company' => $company->nombre,
            'coreversion' => Kernel::version(),
            'idcompany' => $company->idempresa,
            'phpversion' => phpversion(),
            'pluginlist' => implode(',', $plugin_list),
            'url' => $url,
            'version' => self::VERSION
        ];

        return static::doPost('erp', $input);
    }

    public static function update(?string $connid, ?string $signkey): ?array
    {
        if (empty($connid) || empty($signkey)) {
            return null;
        }

        $plugin_list = [];
        foreach (Plugins::list() as $plugin) {
            $plugin_list[] = $plugin->name . '|' . $plugin->version;
        }

        $input = [
            'action' => 'update',
            'connid' => $connid,
            'coreversion' => Kernel::version(),
            'hash' => '',
            'phpversion' => phpversion(),
            'pluginlist' => implode(',', $plugin_list),
            'random' => mt_rand(),
            'version' => self::VERSION
        ];

        // calculate hash
        $input['hash'] = sha1($signkey . $input['random']);
        return static::doPost('erp', $input);
    }

    /**
     * @param int $connid
     * @param string $signkey
     *
     * @return ?array
     */
    public static function unregister($connid, $signkey): ?array
    {
        $input = [
            'action' => 'unregister',
            'connid' => $connid,
            'hash' => '',
            'random' => mt_rand(),
            'version' => self::VERSION
        ];

        // calculate hash
        $input['hash'] = sha1($signkey . $input['random']);
        return static::doPost('erp', $input);
    }
}
