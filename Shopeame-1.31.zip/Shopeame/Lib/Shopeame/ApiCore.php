<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2024, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Lib\Shopeame;

/**
 * Description of ApiCore
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
abstract class ApiCore
{
    const USERAGENT = 'shopeame-client';
    const TIMEOUT = 30;

    /** @var int */
    private static $httpCode = 0;

    public static function apiUrl(): string
    {
        return '';
    }

    /**
     * @param string $what
     * @param string $idItem
     *
     * @return array
     */
    protected function doDelete($what, $idItem): ?array
    {
        $resource = curl_init();
        curl_setopt($resource, CURLOPT_URL, static::apiUrl() . '/' . $what . '/' . $idItem);
        curl_setopt($resource, CURLOPT_CUSTOMREQUEST, 'DELETE');
        return static::processApiCall($resource);
    }

    /**
     * @param string $what
     * @param string $idItem
     *
     * @return array
     */
    public static function doGet($what, $idItem = ''): ?array
    {
        $resource = curl_init();
        $url = empty($idItem) ? static::apiUrl() . '/' . $what : static::apiUrl() . '/' . $what . '/' . $idItem;
        curl_setopt($resource, CURLOPT_URL, $url);
        return static::processApiCall($resource);
    }

    /**
     * @param string $what
     * @param array $value
     *
     * @return array
     */
    public static function doPost(string $what, array $value = []): ?array
    {
        $resource = curl_init();
        curl_setopt($resource, CURLOPT_URL, static::apiUrl() . '/' . $what);
        curl_setopt($resource, CURLOPT_POST, true);
        curl_setopt($resource, CURLOPT_POSTFIELDS, http_build_query($value));
        return static::processApiCall($resource);
    }

    /**
     * @param string $what
     * @param array $value
     *
     * @return array
     */
    protected function doPut(string $what, array $value = []): ?array
    {
        $resource = curl_init();
        curl_setopt($resource, CURLOPT_URL, static::apiUrl() . '/' . $what);

        // don't change for CURLOPT_PUT
        curl_setopt($resource, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($resource, CURLOPT_POSTFIELDS, http_build_query($value));
        return static::processApiCall($resource);
    }

    /**
     * @return int
     */
    public static function getHttpCode()
    {
        return self::$httpCode;
    }

    /**
     * @param mixed $resource
     *
     * @return array
     */
    private static function processApiCall(&$resource): ?array
    {
        curl_setopt($resource, CURLOPT_USERAGENT, self::USERAGENT);
        curl_setopt($resource, CURLOPT_TIMEOUT, self::TIMEOUT);
        curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);

        $data = curl_exec($resource);
        self::$httpCode = curl_getinfo($resource, CURLINFO_HTTP_CODE);
        curl_close($resource);

        return json_decode($data, true);
    }
}
