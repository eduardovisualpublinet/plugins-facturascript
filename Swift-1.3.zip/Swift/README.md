# SWIFT Plugin

Plugin que permite visualizar el codigo Swift asociado a las cuentas bancarias en Facturas y resto de documentos donde se especifica el IBAN de la cuenta.
En caso de que no exista el código Swift en la cuenta no se visualiza nada.

## Issues / Feedback

https://www.aumentium.com/contacto/
