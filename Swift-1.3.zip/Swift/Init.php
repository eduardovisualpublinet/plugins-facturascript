<?php

namespace FacturaScripts\Plugins\Swift;

use FacturaScripts\Core\Template\InitClass;

class Init extends InitClass {

    public function init(): void {
        /// No need initialization task
    }

    public function update(): void {
        /// No need update task
    }

    public function uninstall(): void {
        
    }
}
