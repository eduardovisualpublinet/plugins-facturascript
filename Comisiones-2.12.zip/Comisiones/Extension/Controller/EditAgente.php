<?php
/**
 * This file is part of Comisiones plugin for FacturaScripts
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Plugins\Comisiones\Extension\Controller;

use Closure;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Where;

/**
 * Description of EditAgente
 *
 * @author Carlos Garcia Gomez           <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez      <hola@danielfg.es>
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditAgente
{
    public function createViews(): Closure
    {
        return function () {
            $this->createCommissionsView();
            $this->createSettlementView();
            $this->createPenalizeView();
        };
    }

    protected function createCommissionsView(): Closure
    {
        return function (string $viewName = 'ListComision') {
            $this->addListView($viewName, 'Comision', 'commissions', 'fa-solid fa-percentage')
                ->addOrderBy(['prioridad'], 'priority', 2)
                ->addOrderBy(['porcentaje'], 'percentage')
                ->disableColumn('agent', true);
        };
    }

    protected function createPenalizeView(): Closure
    {
        return function (string $viewName = 'EditComisionPenalizacion') {
            $this->addEditListView($viewName, 'ComisionPenalizacion', 'penalize', 'fa-solid fa-minus-circle')
                ->setInline(true);

            // disable company column if there is only one company
            if (count(Empresas::all()) < 2) {
                $this->tab($viewName)->disableColumn('company');
            }
            $this->tab($viewName)->disableColumn('agent');
        };
    }

    protected function createSettlementView(): Closure
    {
        return function (string $viewName = 'ListLiquidacionComision') {
            $this->addListView($viewName, 'LiquidacionComision', 'settlements', 'fa-solid fa-chalkboard-teacher')
                ->addOrderBy(['fecha'], 'date', 2)
                ->addOrderBy(['total'], 'amount');
        };
    }

    protected function loadData(): Closure
    {
        return function ($viewName, $view) {
            switch ($viewName) {
                case 'ListComision':
                case 'ListLiquidacionComision':
                    $codagente = $this->getViewModelValue('EditAgente', 'codagente');
                    $where = [Where::column('codagente', $codagente)];
                    $view->loadData('', $where);
                    break;

                case 'EditComisionPenalizacion':
                    $codagente = $this->getViewModelValue('EditAgente', 'codagente');
                    $where = [Where::column('codagente', $codagente)];
                    $order = ['COALESCE(idempresa, 9999999)' => 'ASC', 'dto_desde' => 'ASC'];
                    $view->loadData('', $where, $order);
                    break;
            }
        };
    }
}
