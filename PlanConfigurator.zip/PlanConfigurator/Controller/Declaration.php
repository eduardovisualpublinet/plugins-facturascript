<?php
namespace FacturaScripts\Plugins\PlanConfigurator\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\PanelController;

class Declaration extends PanelController
{
    
    public function getPageData(): array
    {
        $page = parent::getPageData();
        
        $page['title'] = 'Declaración responsable';
        $page['menu'] = 'admin';
        $page['icon'] = 'fas fa-id-card';
        $page['showonmenu'] = true;
        return $page;
    }

    protected function createViews() {
        
        //$this->addHtmlView('Declaration', 'Settings', 'Declaración', 'fas fa-tools');
        $this->addHtmlView('Declaration', 'Declaration', 'Settings', 'Declaración','fas fa-code-branch');
         // desactivamos el botón nuevo
         $this->setSettings('Declaration', 'btnNew', false);

    }

    protected function loadData($viewName, $view) {
   
            $code = $this->request->get('code');
            $view->loadData($code);
        
    }
}