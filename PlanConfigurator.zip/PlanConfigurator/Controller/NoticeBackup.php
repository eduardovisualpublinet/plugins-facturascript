<?php
namespace FacturaScripts\Plugins\PlanConfigurator\Controller;

use FacturaScripts\Core\Lib\ExtendedController\PanelController;

class NoticeBackup extends PanelController
{
    
    public function getPageData(): array
    {
        $page = parent::getPageData();
        
        $page['title'] = 'Info Backup';
        $page['menu'] = 'admin';
        $page['icon'] = 'fas fa-solid fa-shield-halved';
        $page['showonmenu'] = true;
        return $page;
    }

    protected function createViews() {
        
        //$this->addHtmlView('Declaration', 'Settings', 'Declaración', 'fas fa-tools');
        $this->addHtmlView('NoticeBackup', 'NoticeBackup', 'Settings', 'Info Backup','fas fa-code-branch');

    }

    protected function loadData($viewName, $view) {
   
            $code = $this->request->get('code');
            $view->loadData($code);
        
    }
}