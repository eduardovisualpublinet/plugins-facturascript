<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\Base\ControllerPermissions;
use FacturaScripts\Core\KernelException;
use FacturaScripts\Core\Lib\AssetManager;
use FacturaScripts\Core\Response;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Attendance;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\EmployeeTools;

/**
 * Controller for employee attendances with numeric keyboard.
 *
 * @author Raul Jimenez <raul.jimenez@nazcanetworks.com>
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class AttendancePanel extends Controller
{
    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'attendance-panel';
        $pageData['icon'] = 'fa-solid fa-table';
        $pageData['menu'] = 'rrhh';
        $pageData['ordernum'] = -1;
        return $pageData;
    }

    /**
     * Runs the controller's private logic.
     *
     * @param Response $response
     * @param User $user
     * @param ControllerPermissions $permissions
     * @throws KernelException
     */
    public function privateCore(&$response, $user, $permissions): void
    {
        parent::privateCore($response, $user, $permissions);
        $action = $this->request->inputOrQuery('action', '');
        if (false === $this->execPreviousAction($action)) {
            return;
        }
    }

    /**
     * Exec special actions before load data.
     *
     * @param ?string $action
     * @return bool
     */
    protected function execPreviousAction(?string $action): bool
    {
        if ($action == 'insert-attendance') {
            $this->setTemplate(False);
            $this->response->setContent(json_encode($this->insertAttendanceAction()));
            return false;
        }
        return true;
    }

    /**
     * Inserts an attendance record with form data.
     *
     * @return array
     */
    private function insertAttendanceAction(): array
    {
        if (false === $this->validateFormToken()) {
            return [
                'error' => true,
                'message' => Tools::trans('invalid-token'),
                'newtoken' => $this->multiRequestProtection->newToken(),
            ];
        }

        $data = $this->request->request->all();
        $kind = (int)$data['kind'] ?? null;
        $credentialId = $data['credencial'] ?? 0;
        if (empty($credentialId)
            || false === in_array($kind, [Attendance::KIND_INPUT, Attendance::KIND_OUTPUT], true)
        ) {
            return [
                'error' => true,
                'message' => Tools::trans('form-data-error'),
                'newtoken' => $this->multiRequestProtection->newToken(),
            ];
        }

        $employeeId = EmployeeTools::getIdEmployeeFromCredential($credentialId);
        if (empty($employeeId)) {
            return [
                'error' => true,
                'message' => Tools::trans('credential-id-error'),
                'newtoken' => $this->multiRequestProtection->newToken(),
            ];
        }

        $attendance = new Attendance();
        $attendance->origin = Attendance::ORIGIN_EXTERNAL;
        $attendance->idemployee = (int)$employeeId;
        $attendance->kind = $kind;
        $attendance->location = $data['location'] ?? '';
        $attendance->setAdjustToWordPeriod(true);
        if (false === $attendance->save()) {
            return [
                'error' => true,
                'message' => Tools::trans('record-save-error'),
                'newtoken' => $this->multiRequestProtection->newToken(),
            ];
        }

        return [
            'error' => false,
            'message' => Tools::trans('record-updated-correctly'),
            'newtoken' => $this->multiRequestProtection->newToken(),
        ];
    }
}
