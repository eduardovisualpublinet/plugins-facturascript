<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\EditController;

/**
 * Controller to edit Employee Pay Roll.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditEmployeePayRoll extends EditController
{
    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'EmployeePayRoll';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'rrhh';
        $pageData['title'] = 'employee-salary';
        $pageData['icon'] = 'fa-solid fa-money-bill-alt';
        return $pageData;
    }

    /**
     * Create the view to display.
     */
    protected function createViews()
    {
        // Add Views
        parent::createViews();
        $this->setTabsPosition('bottom');

        $this->views['EditEmployeePayRoll']->setReadOnly(true)
            ->setSettings('btnNew', false);

        $this->addEditListView('EditEmployeePayRollSalary', 'EmployeePayRollSalary', 'payroll-salary')
            ->setInline(true);
    }

    /**
     * Loads the data to display.
     *
     * @param string   $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'EditEmployeePayRollSalary':
                $this->loadDataPayRollSalary($view);
                break;

            default:
                parent::loadData($viewName, $view);
                $view->disableColumn('code', true);
                break;
        }
    }

    /**
     * Loads the data to display in the Employee Pay Roll Salary view.
     *
     * @param BaseView $view
     */
    private function loadDataPayRollSalary($view): void
    {
        $where = [new DataBaseWhere('idemployeepayroll', $this->getModel()->id)];
        $view->loadData(false, $where, ['channel' => 'ASC', 'calculation' => 'ASC', 'id' => 'ASC']);
        $view->disableColumn('code', true);
        $view->disableColumn('employeepayroll', true);
        $view->disableColumn('employee', true);
    }
}
