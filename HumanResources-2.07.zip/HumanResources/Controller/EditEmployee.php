<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\EmployeeSalary;
use FacturaScripts\Dinamic\Model\TotalModel;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\EmployeeControllerTrait;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\EmployeeFilesTrait;
use FacturaScripts\Plugins\HumanResources\Model\Attendance;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeHoliday;
use FacturaScripts\Dinamic\Model\Employee;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeHolidayMax;

/**
 * Controller to edit Employee.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditEmployee extends EditController
{
    private const VIEW_HOLIDAY = 'ListEmployeeHoliday2';
    private const VIEW_ATTENDANCE = 'ListAttendance';
    private const VIEW_ADDRESS = 'EditDireccionContacto';
    private const VIEW_CONTRACT = 'EditEmployeeContract';
    private const VIEW_COURSES = 'EditEmployeeCourse';
    private const VIEW_LEAVE = 'EditEmployeeLeave';
    private const VIEW_NOTE = 'EditEmployeeNote';
    private const VIEW_SALARY = 'EditEmployeeSalary';
    private const VIEW_SANCTION = 'EditEmployeeSanction';
    private const VIEW_VOURCHER = 'ListEmployeeVoucher';
    private const VIEW_WORKSHIFT = 'ListEmployeeWorkShift';
    private const VIEW_EMPLOYEE = 'EditEmployee';

    use EmployeeFilesTrait;
    use EmployeeControllerTrait;

    /**
     * Gets the employee's total holiday days by years.
     *
     * @return array
     */
    public function holidaySummary(): array
    {
        $where = [
            new DataBaseWhere('idemployee', $this->getModel()->id),
            new DataBaseWhere('applyto', (int)date('Y') - 5, '>=')
        ];
        $totals = TotalModel::all(
            EmployeeHoliday::tableName(),
            $where,
            ['total' => 'SUM(totaldays)'],
            'COALESCE(applyto, EXTRACT(YEAR FROM startdate))'
        );

        $result = [];
        foreach (array_reverse($totals, true) as $year) {
            $result[$year->code] = [
                'used' => $year->totals['total'],
                'max' => EmployeeHolidayMax::maxForEmployee($this->getModel()->id, $year->code),
            ];
        }
        return array_slice($result, 0, 6, true);;
    }

    /**
     * Returns the model name
     *
     * @return string
     */
    public function getModelClassName(): string
    {
        return 'Employee';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'rrhh';
        $pageData['title'] = 'employee';
        $pageData['icon'] = 'fa-solid fa-id-card';
        return $pageData;
    }

    /**
     * Create views to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->addEditView(self::VIEW_NOTE, 'Employee', 'notes', 'fa-solid fa-sticky-note')
            ->setSettings('btnDelete', false);

        $this->createViewEdit(self::VIEW_ADDRESS, 'Contacto', 'addresses', 'fa-solid fa-address-book');
        $this->createViewEdit(self::VIEW_CONTRACT, 'EmployeeContract', 'contracts', 'fa-solid fa-handshake');
        $this->createViewEmployeeWorkShift();
        $this->createViewEdit(self::VIEW_SALARY, 'EmployeeSalary', 'employee-salary', 'fa-solid fa-money-bill-alt');
        $this->createViewEdit(self::VIEW_LEAVE, 'EmployeeLeave', 'employee-leaves', 'fa-solid fa-wheelchair');
        $this->createViewEmployeeHoliday();
        $this->createViewCourses();
        $this->createViewEmployeeVoucher();
        $this->createViewEdit(self::VIEW_SANCTION, 'EmployeeSanction', 'sanctions', 'fa-solid fa-gavel');
        $this->createViewAttendance();
        $this->createViewEmployeeFiles();
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'add-file':
            case 'delete-file':
            case 'edit-file':
            case 'unlink-file':
                return $this->execFileAction($action);

            case 'discharge':
                return $this->execActionDischargeEmployee();

            case 'clone-salary':
                $fromemployee = $this->request->input('fromemployee');
                $toemployee = $this->request->input('code');
                $employeeSalary = new EmployeeSalary();
                $employeeSalary->cloneSalaryToEmployee($fromemployee, $toemployee);
                return true;

            case 'justified':
                $data = $this->request->request->all();
                $attendance = new Attendance();
                $attendance->justifiedFromData($data);
                return true;

            case 'save-max-holidays':
                $this->setTemplate(false);
                $this->response->setContent(json_encode($this->saveMaxHolidaysAction()));
                return false;
        }
        return parent::execPreviousAction($action);
    }

    /**
     * Load view data procedure
     *
     * @param string $viewName
     * @param BaseView $view
     * @throws Exception
     */
    protected function loadData($viewName, $view)
    {
        $mainViewName = $this->getMainViewName();
        if ($viewName === $mainViewName) {
            parent::loadData($viewName, $view);
            $this->loadAddressContact();
            if (false === empty($view->model->id)
                && empty($view->model->dischargedate)
            ) {
                $this->addButton($mainViewName, [
                    'type' => 'modal',
                    'action' => 'discharge',
                    'label' => 'discharge',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-sign-out-alt',
                ]);
                $view->model->discharge_date = date(Tools::DATE_STYLE);
            }
            return;
        }

        $idemployee = $this->getModel()->id;
        $where = [new DataBaseWhere('idemployee', $idemployee)];
        switch ($viewName) {
            case 'EmployeeFiles':
                $this->loadDataEmployeeFiles($view, $idemployee);
                break;

            case self::VIEW_NOTE:
                $view->loadData($idemployee);
                $view->count = -1;
                break;

            case self::VIEW_ATTENDANCE:
                $where[] = new DataBaseWhere('checkdate', date('Y-m-d', strtotime('-1 month')), '>');
                $view->loadData(false, $where);
                $this->loadDataAttendanceAfter($idemployee);
                break;

            default:
                $view->loadData(false, $where, $this->orderByForView($viewName));
                break;
        }
    }

    /**
     * Create Employee Courses view.
     */
    private function createViewCourses(): void
    {
        $this->addEditListView(self::VIEW_COURSES, 'EmployeeCourse', 'courses', 'fa-solid fa-graduation-cap')
            ->setInLine(true)
            ->disableColumn('employee');
    }

    /**
     * Create Employee Holidays view.
     */
    private function createViewEmployeeHoliday(): void
    {
        $i18n = Tools::lang();
        $this->createViewList(self::VIEW_HOLIDAY, 'EmployeeHoliday', 'holidays', 'fa-solid fa-sun')
            ->addOrderBy(['startdate'], 'start-date' ,2)
            ->addFilterPeriod('startdate', 'start-date', 'startdate')
            ->addFilterNumber('totaldays', 'totaldays')
            ->addFilterSelectWhere('status', [
                    ['label' => $i18n->trans('this-year'), 'where' => [new DataBaseWhere('startdate', $this->getDate(), '>=')]],
                    ['label' => '2 ' . $i18n->trans('years'), 'where' => [new DataBaseWhere('startdate', $this->getDate(1), '>=')]],
                    ['label' => $i18n->trans('only-pending'), 'where' => [new DataBaseWhere('enddate', null, 'IS'), new DataBaseWhere('enddate', date('Y-m-d'), '>=', 'OR')]],
                    ['label' => $i18n->trans('all'), 'where' => []]
                ]);
    }

    /**
     * Create Attendance view.
     */
    private function createViewAttendance(): void
    {
        $lang = Tools::lang();
        $absenceConceptValues = $this->codeModel->all('rrhh_absencesconcepts', 'id', 'name');
        $this->createViewList(self::VIEW_ATTENDANCE, 'Attendance', 'attendances-last', 'fa-solid fa-clock', ['code', 'credential', 'employee'])
            ->addSearchFields(['checkdate', 'checktime', 'note'])
            ->addOrderBy(['checkdate', 'checktime'], 'date', 2)
            // Filters
            ->addFilterPeriod('checkdate', 'date', 'checkdate')
            ->addFilterSelect('origin', 'origin', 'origin', [
                    ['code' => '1', 'description' => $lang->trans('manual')],
                    ['code' => '2', 'description' => $lang->trans('justified')],
                    ['code' => '3', 'description' => $lang->trans('external')],
                ])
            ->addFilterSelect('kind', 'type', 'kind', [
                    ['code' => Attendance::KIND_INPUT, 'description' => $lang->trans('input')],
                    ['code' => Attendance::KIND_OUTPUT, 'description' => $lang->trans('output')],
                ])
            ->addFilterSelect('idabsenceconcept', 'absence-concept', 'idabsenceconcept', $absenceConceptValues);
    }

    /**
     * Create Employee Voucher view.
     */
    private function createViewEmployeeVoucher(): void
    {
        $this->createViewList(self::VIEW_VOURCHER, 'EmployeeVoucher', 'vouchers', 'fa-solid fa-coins')
            ->addSearchFields(['name', 'startdate', 'checktime', 'note'])
            ->addOrderBy(['startdate', 'pending'], 'date', 2)
            // Filters
            ->addFilterPeriod('startdate', 'start-date', 'startdate')
            ->addFilterNumber('pending');
    }

    /**
     * Create Employee WorkShift view.
     */
    private function createViewEmployeeWorkShift(): void
    {
        $this->createViewList(self::VIEW_WORKSHIFT, 'EmployeeWorkShift', 'work-shifts-short', 'fa-solid fa-business-time')
            ->addOrderBy(['idemployee', 'startdate'], 'date', 2);
    }

    /**
     * Get date from start year.
     *
     * @param int $regression
     * @return string
     */
    private function getDate(int $regression = 0): string
    {
        $year = (int) date('Y') - $regression;
        $startDate = strtotime('01-01-' . $year);
        return date('Y-m-d', $startDate);
    }

    /**
     * Set Address list to column from contact table.
     */
    private function loadAddressContact(): void
    {
        $idemployee = $this->getModel()->id;
        if (empty($idemployee)) {
            return;
        }

        $viewName = $this->getMainViewName();
        $columnAddress = $this->views[$viewName]->columnForName('address');
        if ($columnAddress) {
            $where = [new DataBaseWhere('idemployee', $idemployee)];
            $contacts = $this->codeModel->all('contactos', 'idcontacto', 'descripcion', false, $where);
            $columnAddress->widget->setValuesFromCodeModel($contacts);
        }
    }

    /**
     * Set value and readonly to employee modal column.
     *
     * @param int $idemployee
     */
    private function loadDataAttendanceAfter(int $idemployee): void
    {
        $view = $this->views[self::VIEW_ATTENDANCE];
        $view->model->employee_id = $idemployee;

        $employeeCol = $view->columnModalForName('employee');
        if (isset($employeeCol)) {
            $employeeCol->widget->readonly = 'true';
        }
    }

    /**
     * Import new attendances from biometric device.
     *
     * @return bool
     */
    private function execActionDischargeEmployee(): bool
    {
        $data = $this->request->request->all();
        if(empty($data['code'])
         || empty($data['discharge_date'])
         || empty($data['discharge_description'])
         || false === $this->validateFormToken()
        ){
            return true;
        }

        $employee = new Employee();
        if (false === $employee->load($data['code'])) {
           return true;
        }

        $employee->dischargeEmployee(
            $data['discharge_date'],
            $data['discharge_description']
        );
        return true;
    }

    /**
     * Save max holidays for employee/year.
     *
     * @return array
     */
    private function saveMaxHolidaysAction(): array
    {
        $idemploye = $this->request->input('code', 0);
        $maxDays = $this->request->request->getArray('maxdays');
        if (empty($idemploye) || empty($maxDays)) {
            return [
                'error' => true,
                'message' => Tools::lang()->trans('data-form-error'),
            ];
        }

        $employeeMaxHoliday = new EmployeeHolidayMax();
        foreach ($maxDays as $year => $days) {
            $where = [
                new DataBaseWhere('idemployee', $idemploye),
                new DataBaseWhere('applyto', $year)
            ];
            if (false === $employeeMaxHoliday->loadWhere($where)) {
                $employeeMaxHoliday->idemployee = $idemploye;
                $employeeMaxHoliday->applyto = $year;
            }
            $employeeMaxHoliday->maxdays = (int)$days;
            $employeeMaxHoliday->save();
        }

        return [
            'error' => false,
            'message' => Tools::lang()->trans('record-updated-correctly'),
        ];
    }
}
