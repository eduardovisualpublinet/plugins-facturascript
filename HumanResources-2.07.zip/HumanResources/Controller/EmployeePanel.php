<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Base\Controller;
use FacturaScripts\Core\Base\ControllerPermissions;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\KernelException;
use FacturaScripts\Core\Lib\AssetManager;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Attendance;
use FacturaScripts\Dinamic\Model\Employee;
use FacturaScripts\Dinamic\Model\EmployeeHoliday;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Plugins\HumanResources\Lib\DateTimeTools;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\PanelAttendance;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\PanelDocument;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\PanelHoliday;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\PanelVoucher;
use FacturaScripts\Plugins\HumanResources\Model\Report\Data\AttendanceWeeklyData;
use FacturaScripts\Core\Response;

/**
 * Controller to show data for one employee.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EmployeePanel extends Controller
{
    /** @var ?PanelAttendance */
    public ?PanelAttendance $attendances;

    /** @var ?PanelDocument */
    public ?PanelDocument $documents;

    /** @var ?Employee */
    public ?Employee $employee;

    /** @var ?PanelHoliday */
    public ?PanelHoliday $holidays;

    /** @var ?PanelVoucher */
    public ?PanelVoucher $vouchers;

    /** @var ?AttendanceWeeklyData */
    public ?AttendanceWeeklyData $weekwork = null;

    /**
     * Format amount value to string with divisa symbol.
     *
     * @param float $value
     * @return string
     */
    public function getMoney(float $value): string
    {
        return Tools::money($value);
    }

    /**
     * Return time into string with days, hours and minutes format.
     *
     * @param float $time
     * @return string
     */
    public function getTime(float $time): string
    {
        $timeStr = DateTimeTools::decimalTimeToString($time);
        $days = $timeStr['days'] > 0
            ? $timeStr['days'] . 'd '
            : '';
        return $days
            . sprintf("%02d", $timeStr['hours'])
            . ':'
            . sprintf("%02d", $timeStr['minutes']);
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'employee-panel';
        $pageData['icon'] = 'fa-solid fa-solar-panel';
        $pageData['menu'] = 'rrhh';
        $pageData['ordernum'] = -1;
        return $pageData;
    }

    /**
     * Runs the controller's private logic.
     *
     * @param Response $response
     * @param User $user
     * @param ControllerPermissions $permissions
     * @throws KernelException
     */
    public function privateCore(&$response, $user, $permissions)
    {
        parent::privateCore($response, $user, $permissions);
        AssetManager::add('js', Tools::config('route') . '/Dinamic/Assets/JS/geolocation.js');

        $this->employee = new Employee();
        $this->attendances = new PanelAttendance();
        $this->documents = new PanelDocument();
        $this->holidays = new PanelHoliday();
        $this->vouchers = new PanelVoucher();

        if ($this->loadEmployee()) {
            $this->execPreviousAction($this->request->inputOrQuery('action', ''));

            // load data for panels/cards
            $this->attendances->load($this->employee->id, $this->getSelectDate());
            $this->documents->load($this->employee->id);
            $this->holidays->load($this->employee->id);
            $this->vouchers->load($this->employee->id);
            $this->weekwork = $this->attendances->getWeekWork();
        }
    }

    /**
     * Exec special actions before load data.
     *
     * @param ?string $action
     * @return bool
     */
    protected function execPreviousAction(?string $action): bool
    {
        $idemployee = (int)$this->request->inputOrQuery('idemployee') ?? 0;
        if (empty($action)
            || $this->employee->id !== $idemployee
            || false === $this->validateFormToken()
        ) {
            return true;
        }

        return match ($action) {
            'insert-attendance' => $this->execInsertAttendance(),
            'insert-holidays' => $this->execInsertHolidays(),
            'delete-attendance' => $this->execDeleteAttendance(),
            'delete-holidays' => $this->execDeleteHolidays(),
            default => true,
        };
    }

    /**
     * Insert a new attendance for employee.
     * Check that the date is equal to or less than today's date.
     *
     * @return bool
     */
    private function execInsertAttendance(): bool
    {
        $data = $this->request->request->all();
        if (DateTimeTools::greaterCurrentDateTime($data['date'], $data['time'])) {
            Tools::log()->notice('date-must-be-less');
            return true;
        }

        $adjust = $data['adjust'] === 'true' ?? false;
        $attendance = new Attendance();
        $attendance->idemployee = (int)$data['idemployee'];
        $attendance->origin = (int)$data['origin'];
        $attendance->kind = (int)$data['kind'];
        $attendance->location = $data['location'] ?? '';
        if ($attendance->origin == Attendance::ORIGIN_MANUAL) {
            $attendance->authorized = false;
            $attendance->checkdate = $data['date'];
            $attendance->checktime = $data['time'];
            $attendance->note = $data['note'];
        }
        $attendance->setAdjustToWordPeriod($adjust);
        $attendance->save();
        return true;
    }

    /**
     * Insert a new holidays period for employee.
     *
     * @return bool
     */
    private function execInsertHolidays(): bool
    {
        $data = $this->request->request->all();
        if (DateTimeTools::dateLessThan($data['startdate'])) {
            Tools::log()->notice('date-must-be-greater');
            return true;
        }

        $holidays = new EmployeeHoliday();
        $holidays->authorized = false;
        $holidays->idemployee = $data['idemployee'];
        $holidays->startdate = $data['startdate'];
        $holidays->enddate = $data['enddate'];
        $holidays->note = $data['notes'];
        $holidays->save();
        return true;
    }

    /**
     * Delete indicate attendance of the employee.
     *
     * @return bool
     */
    private function execDeleteAttendance(): bool
    {
        $id = (int)$this->request->get('idmodel') ?? 0;
        if (empty($id)) {
            return true;
        }
        $attendance = new Attendance();
        if ($attendance->load($id)) {
            $attendance->delete();
        }
        return true;
    }

    /**
     * Delete indicate holidays period of the employee.
     *
     * @return bool
     */
    private function execDeleteHolidays(): bool
    {
        $id = $this->request->get('idmodel', 0);
        if (empty($id)) {
            return true;
        }
        $holidays = new EmployeeHoliday();
        if ($holidays->load($id)) {
            $holidays->delete();
        }
        return true;
    }

    /**
     * Get date for process attendances.
     *
     * @return string
     */
    private function getSelectDate(): string
    {
        $date = $this->request->inputOrQuery("selectDate", date('Y-m-d'));
        $action = $this->request->inputOrQuery('action', '');
        return match ($action) {
            "next-attendance" => date("d-m-Y", strtotime($date . "+1 days")),
            "previous-attendance" => date("d-m-Y", strtotime($date . "-1 days")),
            default => $date,
        };
    }

    /**
     * Load employee data structure for user logged.
     */
    private function loadEmployee(): bool
    {
        $where = [ new DataBaseWhere('nick', $this->user->nick) ];
        return $this->employee->loadWhere($where);
    }
}
