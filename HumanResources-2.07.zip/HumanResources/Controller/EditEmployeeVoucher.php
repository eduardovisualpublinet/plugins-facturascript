<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeVoucherPaid;

/**
 * Controller to edit Employee Contract.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditEmployeeVoucher extends EditController
{
    const VIEWNAME_EMPLOYEEVOUCHERPAID = 'ListEmployeeVoucherPaid';
    const ACTION_INSERTPAID = 'insertpaid';

    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'EmployeeVoucher';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'rrhh';
        $pageData['title'] = 'voucher';
        $pageData['icon'] = 'fa-solid fa-hand-holding-usd';
        return $pageData;
    }

    /**
     * Create the view to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->addVoucherPaidView();
        $this->setTabsPosition('bottom');
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            self::ACTION_INSERTPAID => $this->insertVoucherPaid(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Loads the data to display.
     *
     * @param string   $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case self::VIEWNAME_EMPLOYEEVOUCHERPAID:
                $this->loadEmployeeVoucherPaid($view);
                break;

            default:
                parent::loadData($viewName, $view);
                $readOnly = $view->model->paid && ($view->model->pending <= 0);
                $view->setReadOnly($readOnly);
                break;
        }
    }

    /**
     * Add voucher paid view
     */
    private function addVoucherPaidView(): void
    {
        $this->addListView(self::VIEWNAME_EMPLOYEEVOUCHERPAID, 'EmployeeVoucherPaid', 'payments')
            ->setSettings('modalInsert', self::ACTION_INSERTPAID)
            ->setSettings('clickable', false);
    }

    /**
     * Inset a new payment to voucher employee
     *
     * @return bool
     */
    private function insertVoucherPaid(): bool
    {
        $idvoucher = $this->request->request->get('modalVoucher', 0);
        $amount = $this->request->request->get('modalAmount', 0.00);
        if (empty($idvoucher) || empty($amount)) {
            return true;
        }

        $date = $this->request->request->get('modalDate');
        $payment = new EmployeeVoucherPaid();
        $payment->idvoucher = $idvoucher;
        $payment->amount = $amount;
        $payment->nick = $this->user->nick;
        if (false === empty($date)) {
            $payment->startdate = $date;
            $payment->starttime = '00:00:00';
        }

        if ($payment->save()) {
            Tools::log()->notice('record-updated-correctly');
        }
        return true;
    }

    /**
     * Load data to view with paid for voucher employee
     *
     * @param BaseView $view
     */
    private function loadEmployeeVoucherPaid($view): void
    {
        // Set master values to insert modal view
        $view->model->modalVoucher = $this->getModel()->id;
        $view->model->modalAmount = $this->getModel()->pending;

        // Load view data
        $where = [new DataBaseWhere('idvoucher', $this->getModel()->id)];
        $view->loadData(false, $where, ['startdate' => 'DESC', 'starttime' => 'DESC']);
    }
}
