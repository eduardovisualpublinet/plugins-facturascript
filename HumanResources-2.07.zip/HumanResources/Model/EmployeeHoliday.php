<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model;

use FacturaScripts\Core\Lib\Email\MailNotifier;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Validator;
use FacturaScripts\Plugins\HumanResources\Lib\DateTimeTools;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\ModelExtended;
use PHPMailer\PHPMailer\Exception;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

/**
 * List of holidays for employee
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EmployeeHoliday extends ModelExtended
{
    use ModelTrait;

    /**
     * Year to which the holiday applies.
     *
     * @var int
     */
    public $applyto;

    /**
     * indicates if the record is authorized.
     *
     * @var bool
     */
    public $authorized;

    /**
     * Indicates if the calculation of days is automatic
     * or the user has entered the value
     *
     * @var boolean
     */
    public $automatic;

    /**
     * Indicates if the record can be deleted
     * (if the start date is greater than today)
     *
     * @var bool
     */
    public $canDelete = false;

    /**
     * Employee relation field
     *
     * @var int
     */
    public $idemployee;

    /**
     * Date start
     *
     * @var string
     */
    public $startdate;

    /**
     * Date end
     *
     * @var string
     */
    public $enddate;

    /**
     * Total days
     *
     * @var int
     */
    public $totaldays;

    /**
     * Note and long descriptions
     *
     * @var string
     */
    public $note;

    /**
     * Returns the employee object related to this holiday.
     *
     * @return Employee
     */
    public function getEmployee(): Employee
    {
        $employee = new Employee();
        $employee->load($this->idemployee);
        return $employee;
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new Employee();
        return parent::install();
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'rrhh_employeesholidays';
    }

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->totaldays = 0;
        $this->authorized = true;
        $this->automatic = true;
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        if ($this->errorInPeriod($this->startdate, $this->enddate)) {
            return false;
        }

        if (empty($this->applyto)) {
            $this->applyto = date('Y', strtotime($this->startdate));
        } else {
            $startYear = (int)date('Y', strtotime($this->startdate)) - 1;
            $endYear = (int)date('Y', strtotime($this->enddate)) + 1;
            if ($this->applyto < $startYear || $this->applyto > $endYear) {
                Tools::log()->error(
                    'employee-holiday-applyto-error',
                    ['%start%' => $startYear,  '%end%' => $endYear]
                );
                return false;
            }
        }

        if (is_null($this->automatic)) {
            $this->automatic = true;
        }

        if ($this->automatic) {
            $this->totaldays = DateTimeTools::daysBetween($this->startdate, $this->enddate, true);
        }
        return parent::test();
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListEmployee?activetab=' . $list);
    }

    /**
     * Insert the model data in the database.
     *
     * @return bool
     * @throws Exception
     * @throws LoaderError
     * @throws RuntimeError
     * @throws SyntaxError
     */
    protected function saveInsert(): bool
    {
        if (false === parent::saveInsert()) {
            return false;
        }

        $notificationEmail = Tools::settings('rrhh', 'notificationemail', '');
        if (false === $this->authorized
            && Validator::email($notificationEmail)
        ) {
            MailNotifier::send('notify-rrhh-default', $notificationEmail, Session::user()->nick, [
                'employee' => $this->getEmployee()->nombre,
                'event' => Tools::lang()->trans('request-vacation'),
                'url' => Tools::siteUrl() . '/EditEmployeeHoliday?code=' . $this->id
            ]);
        }
        return true;
    }
}
