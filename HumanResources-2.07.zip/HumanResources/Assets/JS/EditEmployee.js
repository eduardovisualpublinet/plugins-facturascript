/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
"use strict";

/**
 * Save maximum holiday days for an employee.
 */
function saveMaxHolidayDays() {
    const btn = document.getElementById('save-maxdays-btn');
    const container = document.getElementById('holiday-summary');
    if (!container || !btn) return;

    const labelSave = btn.dataset.labelSave;
    const labelSaving = btn.dataset.labelSaving + '...';
    const formData = new FormData();
    formData.append('action', 'save-max-holidays');
    container.querySelectorAll('input[name]').forEach(input => {
        formData.append(input.name, input.value);
    });

    btn.disabled = true;
    btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${labelSaving}`;

    try {
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        }).then(function (response) {
            return response.ok ? response.json() : Promise.reject(response);
        }).then(function (result) {
            if (result.error) {
                setToast(result.message, 'danger', labelSaving, 8000);
                return;
            }
            setToast(result.message, 'completed', labelSaving, 5000);
            updateHolidayBars(container);
        }).catch(error => console.warn(error));
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<i class="fas fa-save"></i> ${labelSave}`;
    }
}

/**
 * Update progress bars based on current used and max values.
 */
function updateHolidayBars(container) {
    container.querySelectorAll('.holiday-used').forEach(span => {
        const year = span.dataset.year;
        const used = parseFloat(span.textContent) || 0;
        const input = container.querySelector(`#maxdays_${year}`);
        const bar = container.querySelector(`.progress-bar[data-year="${year}"]`);
        if (!input || !bar) return;

        const max = parseFloat(input.value) || 0;
        const pct = max > 0 ? Math.min((used / max) * 100, 100) : 0;

        // Update width and color of the progress bar
        bar.classList.remove('bg-info', 'bg-warning', 'bg-danger');
        if (pct < 70) bar.classList.add('bg-info');
        else if (pct < 100) bar.classList.add('bg-warning');
        else bar.classList.add('bg-danger');

        bar.style.width = pct.toFixed(1) + '%';
        bar.setAttribute('aria-valuemax', max);
        bar.setAttribute('aria-valuenow', used);
    });
}

document.addEventListener('input', event => {
    if (event.target.classList.contains('holiday-max')) {
        updateHolidayBars(document.getElementById('holiday-summary'));
    }
});
