<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\BiometricAnviz;
use FacturaScripts\Plugins\HumanResources\Model\BiometricDevice;

/**
 * Description of Cron
 *
 * @author Jose Antonio Cuello <yopli2000@gmail.com>
 */
class Cron extends CronClass
{
    private const JOB_NAME = 'rrhh-devices-autoimport';
    private const JOB_PERIOD = '2 hours';

    /**
     * Cron to import all attendances from devices marked with automatic.
     */
    public function run(): void
    {
        $this->job(self::JOB_NAME)
            ->every(self::JOB_PERIOD)
            ->run(function () {
                $this->importAttendances();
            });
    }

    /**
     * Perform an import of the biometric devices marked as auto import.
     */
    private function importAttendances(): void
    {
        $where = [ new DataBaseWhere('auto_import', true) ];
        $model = new BiometricDevice();
        $biometric = new BiometricAnviz();

        foreach ($model->all($where) as $device) {
            if ($device->type !== BiometricDevice::DEVICE_TYPE_ANVIZ) {
                continue;
            }
            $biometric->import($device);
        }
    }
}
