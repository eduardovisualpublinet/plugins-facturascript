<?php
namespace FacturaScripts\Plugins\fsrettotal\Lib\Accounting;
use FacturaScripts\Core\Lib\Accounting\InvoiceToAccounting as ITA;
use FacturaScripts\Plugins\fsrettotal\Mod\CalculatorMod;

class InvoiceToAccounting extends ITA
{
    protected function loadSubtotalsNO(): bool
    {
        $this->subtotals = CalculatorMod::getSubtotals($this->document, $this->document->getLines());
        return !empty($this->document->total);
    }

}