<?php
/**
 * @author      : Juan Moreno Lavado  -- @jmoreno_2610
 * @author      : Raul Jimenez Jimenez <raljopa@gmail.com>
 * @author      : Raljopa Desarrollos  <contacto@raljopa.es>
 */
namespace FacturaScripts\Plugins\fsrettotal\Controller;

use FacturaScripts\Core\Controller\ReportTaxes as ParentClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Model\Impuesto;
use FacturaScripts\Core\Lib\InvoiceOperation;

class ReportTaxes extends ParentClass
{
    public $codimpuesto;
    public $impuesto;
    public function privateCore(&$response,$user,$permissions){
        parent::privateCore($response,$user,$permissions);
        $this->impuesto = new Impuesto();

    }
    protected function initFilters(): void
    {
        $this->coddivisa = $this->request->request->get(
            'coddivisa',
            Tools::settings('default', 'coddivisa')
        );

        $this->codpais = $this->request->request->get('codpais', '');
        $this->codserie = $this->request->request->get('codserie', '');
        $this->datefrom = $this->request->request->get('datefrom', $this->getQuarterDate(true));
        $this->dateto = $this->request->request->get('dateto', $this->getQuarterDate(false));
        $this->codimpuesto = $this->request->request->get('codimpuesto');

        $this->idempresa = (int)$this->request->request->get(
            'idempresa',
            Tools::settings('default', 'idempresa')
        );

        $this->format = $this->request->request->get('format');
        $this->source = $this->request->request->get('source');
        $this->typeDate = $this->request->request->get('type-date');
    }
    protected function exportAction(): void
    {
        $i18n = Tools::lang();
        $data = $this->getReportData();
        if (empty($data)) {
            Tools::log()->warning('no-data');
            return;
        }

        // prepare lines
        $lastCode = '';
        $lines = [];
        foreach ($data as $row) {
            $hide = $row['codigo'] === $lastCode && $this->format === 'PDF';
            $num2title = $this->source === 'sales' ? 'number2' : 'numproveedor';

            $lines[] = [
                $i18n->trans('serie') => $hide ? '' : $row['codserie'],
                $i18n->trans('code') => $hide ? '' : $row['codigo'],
                $i18n->trans($num2title) => $hide ? '' : $row['numero2'],
                $i18n->trans('date') => $hide ? '' : Tools::date($row['fecha']),
                $i18n->trans('date-supplier') => $row['fechaprov'] ? Tools::date($row['fechaprov']) : '',
                $i18n->trans('name') => $hide ? '' : Tools::fixHtml($row['nombre']),
                $i18n->trans('cifnif') => $hide ? '' : $row['cifnif'],
                $i18n->trans('country') => $hide ? '' : ($row['codpais'] ? Paises::get($row['codpais'])->nombre : ''),
                $i18n->trans('net') => $this->exportFieldFormat('number', $row['neto']),
                $i18n->trans('tax-type') => $row['codimpuesto'],
                $i18n->trans('pct-tax') => $this->exportFieldFormat('number', $row['iva']),
                $i18n->trans('tax') => $this->exportFieldFormat('number', $row['totaliva']),
                $i18n->trans('pct-surcharge') => $this->exportFieldFormat('number', $row['recargo']),
                $i18n->trans('surcharge') => $this->exportFieldFormat('number', $row['totalrecargo']),
                $i18n->trans('pct-irpf') => $this->exportFieldFormat('number', $row['irpf']),
                $i18n->trans('irpf') => $this->exportFieldFormat('number', $row['totalirpf']),
                $i18n->trans('supplied-amount') => $this->exportFieldFormat('number', $row['suplidos']),
                $i18n->trans('total') => $hide ? '' : $this->exportFieldFormat('number', $row['total'])
            ];

            $lastCode = $row['codigo'];
        }
        if (empty($this->codimpuesto)) {
            $totalsData = $this->getTotals($data);
            if (false === $this->validateTotals($totalsData)) {
                return;
            }
        }

        // prepare totals
        $totals = [];
        foreach ($totalsData as $row) {
            $total = $row['neto'] + $row['totaliva'] + $row['totalrecargo'] - $row['totalirpf'] - $row['suplidos'];
            $totals[] = [
                $i18n->trans('tax-type') => $row['codimpuesto'],
                $i18n->trans('net') => $this->exportFieldFormat('number', $row['neto']),
                $i18n->trans('pct-tax') => $this->exportFieldFormat('percentage', $row['iva']),
                $i18n->trans('tax') => $this->exportFieldFormat('number', $row['totaliva']),
                $i18n->trans('pct-surcharge') => $this->exportFieldFormat('percentage', $row['recargo']),
                $i18n->trans('surcharge') => $this->exportFieldFormat('number', $row['totalrecargo']),
                $i18n->trans('pct-irpf') => $this->exportFieldFormat('percentage', $row['irpf']),
                $i18n->trans('irpf') => $this->exportFieldFormat('number', $row['totalirpf']),
                $i18n->trans('supplied-amount') => $this->exportFieldFormat('number', $row['suplidos']),
                $i18n->trans('total') => $this->exportFieldFormat('number', $total)
            ];
        }

        $this->setTemplate(false);
        $this->processLayout($lines, $totals);
    }
    protected function getReportData(): array
    {
        $sql = '';
        $numCol = strtolower(FS_DB_TYPE) == 'postgresql' ? 'CAST(f.numero as integer)' : 'CAST(f.numero as unsigned)';
        $columnDate = $this->typeDate === 'create' ? 'f.fecha' : 'COALESCE(f.fechadevengo, f.fecha)';
        switch ($this->source) {
            case 'purchases':
                //$sql .= 'SELECT f.codserie, f.codigo, f.numproveedor AS numero2, f.fecha, f.fechadevengo, f.nombre, f.cifnif, l.pvptotal,'
                $sql .= 'SELECT f.codserie, f.codigo, f.numproveedor AS numero2, f.fecha, f.fechadevengo, f.fechaprov, f.nombre, f.cifnif, f.totalirpf, l.pvptotal,'
                    //. ' l.iva, l.recargo, l.irpf, l.suplido, f.dtopor1, f.dtopor2, f.total, f.operacion'
                    . ' l.iva, l.recargo, l.irpf, l.suplido, l.codimpuesto, f.dtopor1, f.dtopor2, f.total, f.operacion'
                    . ' FROM lineasfacturasprov AS l'
                    . ' LEFT JOIN facturasprov AS f ON l.idfactura = f.idfactura '
                    . ' WHERE f.idempresa = ' . $this->dataBase->var2str($this->idempresa)
                    . ' AND ' . $columnDate . ' >= ' . $this->dataBase->var2str($this->datefrom)
                    . ' AND ' . $columnDate . ' <= ' . $this->dataBase->var2str($this->dateto)
                    . ' AND (l.pvptotal <> 0.00 OR l.iva <> 0.00)'
                    . ' AND f.coddivisa = ' . $this->dataBase->var2str($this->coddivisa);
                break;

            case 'sales':
                $sql .= 'SELECT f.codserie, f.codigo, f.numero2, f.fecha, f.fechadevengo, f.nombrecliente AS nombre, f.cifnif, l.pvptotal,'
                    //. ' l.iva, l.recargo, l.irpf, l.suplido, f.dtopor1, f.dtopor2, f.total, f.operacion'
                    . ' l.iva, l.recargo, l.irpf, l.suplido, l.codimpuesto, f.dtopor1, f.dtopor2, f.total, f.operacion'
                    . ' FROM lineasfacturascli AS l'
                    . ' LEFT JOIN facturascli AS f ON l.idfactura = f.idfactura '
                    . ' WHERE f.idempresa = ' . $this->dataBase->var2str($this->idempresa)
                    . ' AND ' . $columnDate . ' >= ' . $this->dataBase->var2str($this->datefrom)
                    . ' AND ' . $columnDate . ' <= ' . $this->dataBase->var2str($this->dateto)
                    . ' AND (l.pvptotal <> 0.00 OR l.iva <> 0.00)'
                    . ' AND f.coddivisa = ' . $this->dataBase->var2str($this->coddivisa);
                if ($this->codpais) {
                    $sql .= ' AND codpais = ' . $this->dataBase->var2str($this->codpais);
                }
                break;

            default:
                Tools::log()->warning('wrong-source');
                return [];
        }
        if ($this->codserie) {
            $sql .= ' AND codserie = ' . $this->dataBase->var2str($this->codserie);
        }

        //juan
        if ($this->codimpuesto) {
            $sql .= ' AND codimpuesto = ' . $this->dataBase->var2str($this->codimpuesto);
        }

        $sql .= ' ORDER BY ' . $columnDate . ', ' . $numCol . ' ASC;';

        $data = [];
        foreach ($this->dataBase->select($sql) as $row) {
            $pvpTotal = floatval($row['pvptotal']) * (100 - floatval($row['dtopor1'])) * (100 - floatval($row['dtopor2'])) / 10000;

            //$code = $row['codigo'] . '-' . $row['iva'] . '-' . $row['recargo'] . '-' . $row['irpf'] . '-' . $row['suplido'];
            $code = $row['codigo'] . '-' . $row['codimpuesto'] . '-' . $row['recargo'] . '-' . $row['irpf'] . '-' . $row['suplido'];

            if (isset($data[$code])) {
                $data[$code]['neto'] += $row['suplido'] ? 0 : $pvpTotal;
                $data[$code]['totaliva'] += $row['suplido'] || $row['operacion'] === InvoiceOperation::INTRA_COMMUNITY ? 0 : (float)$row['iva'] * $pvpTotal / 100;
                $data[$code]['totalrecargo'] += $row['suplido'] ? 0 : (float)$row['recargo'] * $pvpTotal / 100;

                //juan. Si tiene plugin fsrettotal, no se calcula irpf, se coge de la bbdd
                //$data[$code]['totalirpf'] += $row['suplido'] ? 0 : (float)$row['irpf'] * $pvpTotal / 100;

                $data[$code]['suplidos'] += $row['suplido'] ? $pvpTotal : 0;
                continue;
            }

            $data[$code] = [
                'codserie' => $row['codserie'],
                'codigo' => $row['codigo'],
                'numero2' => $row['numero2'],
                'fecha' => $this->typeDate == 'create' ?
                    $row['fecha'] :
                    $row['fechadevengo'] ?? $row['fecha'],
                'nombre' => $row['nombre'],
                'cifnif' => $row['cifnif'],
                'neto' => $row['suplido'] ? 0 : $pvpTotal,
                'iva' => $row['suplido'] ? 0 : (float)$row['iva'],
                'totaliva' => $row['suplido'] || $row['operacion'] === InvoiceOperation::INTRA_COMMUNITY ? 0 : (float)$row['iva'] * $pvpTotal / 100,
                'recargo' => $row['suplido'] ? 0 : (float)$row['recargo'],
                'totalrecargo' => $row['suplido'] ? 0 : (float)$row['recargo'] * $pvpTotal / 100,
                'irpf' => $row['suplido'] ? 0 : (float)$row['irpf'],

                //juan. Si tiene plugin fsrettotal, no se calcula irpf, se coge de la bbdd
                //'totalirpf' => $row['suplido'] ? 0 : (float)$row['irpf'] * $pvpTotal / 100,
                'totalirpf' => $row['suplido'] ? 0 : (float)$row['totalirpf'],

                'suplidos' => $row['suplido'] ? $pvpTotal : 0,
                'total' => (float)$row['total'],
                'codimpuesto' => $row['codimpuesto'],
                'fechaprov' => $row['fechaprov']
            ];
        }

        // round
        foreach ($data as $key => $value) {
            $data[$key]['neto'] = round($value['neto'], FS_NF0);
            $data[$key]['totaliva'] = round($value['totaliva'], FS_NF0);
            $data[$key]['totalrecargo'] = round($value['totalrecargo'], FS_NF0);
            $data[$key]['totalirpf'] = round($value['totalirpf'], FS_NF0);
            $data[$key]['suplidos'] = round($value['suplidos'], FS_NF0);
        }

        return $data;
    }
    protected function getTotals(array $data): array
    {
        $totals = [];
        foreach ($data as $row) {

            //$code = $row['iva'] . '-' . $row['recargo'] . '-' . $row['irpf'];
            $code = $row['codimpuesto'] . '-' . $row['recargo'] . '-' . $row['irpf'];

            if (isset($totals[$code])) {
                $totals[$code]['neto'] += $row['neto'];
                $totals[$code]['totaliva'] += $row['totaliva'];
                $totals[$code]['totalrecargo'] += $row['totalrecargo'];
                $totals[$code]['totalirpf'] += $row['totalirpf'];
                $totals[$code]['suplidos'] += $row['suplidos'];
                continue;
            }

            $totals[$code] = [

                //juan
                'codimpuesto' => $row['codimpuesto'],

                'neto' => $row['neto'],
                'iva' => $row['iva'],
                'totaliva' => $row['totaliva'],
                'recargo' => $row['recargo'],
                'totalrecargo' => $row['totalrecargo'],
                'irpf' => $row['irpf'],
                'totalirpf' => $row['totalirpf'],
                'suplidos' => $row['suplidos']
            ];
        }

        return $totals;
    }
}