<?php
/**
 * Load Extension and mods 
 * @author Raúl Jiménez <raljopa@gmail.com>
 */
namespace FacturaScripts\Plugins\fsrettotal;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;

use FacturaScripts\Core\Lib\Calculator;

class Init extends InitClass
{
    public function init(): void
    {
        Calculator::addMod(new Mod\CalculatorMod());
    }

    public function update(): void
    {
    }

    public function uninstall(): void
    {
    }
}