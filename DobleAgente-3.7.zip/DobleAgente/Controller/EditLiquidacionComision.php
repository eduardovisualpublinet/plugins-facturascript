<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Controller;

use Exception;
use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Dinamic\Model\LineaLiquidacionComision;

/**
 * Description of EditLiquidacionComision
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class EditLiquidacionComision extends EditController
{
    const INSERT_DOMICILED_ALL = 'ALL';
    const INSERT_DOMICILED_DOMICILED = 'DOMICILED';
    const INSERT_DOMICILED_WITHOUT = 'WITHOUT';
    const INSERT_STATUS_ALL = 'ALL';
    const INSERT_STATUS_CHARGED = 'CHARGED';

    public function getModelClassName(): string
    {
        return 'LiquidacionComision';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'settlement';
        $data['icon'] = 'fa-solid fa-chalkboard-teacher';
        return $data;
    }

    /**
     * Calculate the commission percentage for each of the selected invoices
     */
    protected function calculateCommission(): bool
    {
        $data = $this->request->request->all();
        $docs = $this->getInvoicesFromDataForm($data);
        if (empty($docs)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        $this->dataBase->beginTransaction();

        try {
            // recalculate all business documents
            foreach ($docs as $invoice) {
                $lines = $invoice->getLines();
                Calculator::calculate($invoice, $lines, false);
                $invoice->save();
            }

            // update total to settlement commission
            $this->calculateTotalCommission();

            // confirm changes
            $this->dataBase->commit();

            Tools::log()->notice('record-updated-correctly');
        } catch (Exception $exc) {
            $this->dataBase->rollback();
            Tools::log()->error($exc->getMessage());
        }

        return true;
    }

    /**
     * Calculate the total commission amount for the settlement
     */
    protected function calculateTotalCommission(): void
    {
        $code = $this->request->query->get('code');
        $this->getModel()->calculateTotalCommission($code);
    }

    /**
     * Create views
     */
    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');
        $this->createViewLineasLiquidacion();
    }

    /**
     * Add view with Invoices included
     *
     * @param string $viewName
     */
    protected function createViewLineasLiquidacion(string $viewName = 'ListLineaLiquidacionComision'): void
    {
        $this->addListView($viewName, 'LineaLiquidacionComision', 'invoices', 'fa-solid fa-file-invoice')
            ->addOrderBy(['fecha', 'idfactura'], 'date', 2)
            ->addOrderBy(['neto'], 'amount')
            ->addOrderBy(['totalcomision'], 'commission')
            ->setSettings('modalInsert', 'insertinvoices');
    }

    /**
     * Run the controller after actions.
     *
     * @param string $action
     */
    protected function execAfterAction($action)
    {
        if ($action == 'generateinvoice') {
            $this->generateInvoice();
            return;
        }

        parent::execAfterAction($action);
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'calculatecommission' => $this->calculateCommission(),
            'insertinvoices' => $this->insertInvoicesAction(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Create the invoice for the payment to the agent
     */
    protected function generateInvoice(): bool
    {
        if ($this->views[$this->getMainViewName()]->model->generateInvoice()) {
            Tools::log()->notice('record-updated-correctly');

            // redireccionamos a la factura
            $invoice = new FacturaProveedor();
            if ($invoice->load($this->views[$this->getMainViewName()]->model->idfactura)) {
                $this->redirect($invoice->url() . '&action=save-ok');
            }

            return true;
        }

        Tools::log()->error('record-save-error');
        return false;
    }

    /**
     * Insert Invoices in the settled
     */
    protected function insertInvoicesAction(): bool
    {
        $data = $this->request->request->all();
        $where = [
            new DataBaseWhere('idempresa', $data['idempresa']),
            new DataBaseWhere('codserie', $data['codserie']),
            new DataBaseWhere('codagente|codagente2', $data['codagente'])
        ];

        // Date from
        if (!empty($data['datefrom'])) {
            $where[] = new DataBaseWhere('fecha', $data['datefrom'], '>=');
        }

        // Date to
        if (!empty($data['dateto'])) {
            $where[] = new DataBaseWhere('fecha', $data['dateto'], '<=');
        }

        // exclude
        $notInSql = 'SELECT idfactura FROM lineasliquidacionescom WHERE codagente = ' . $this->dataBase->var2str($data['codagente']);
        $where[] = new DataBaseWhere('idfactura', $notInSql, 'NOT IN');

        $num = 0;
        $facturaModel = new FacturaCliente();
        foreach ($facturaModel->all($where, [], 0, 0) as $factura) {
            // recalculate commissions
            $lines = $factura->getLines();
            Calculator::calculate($factura, $lines, false);

            $newLinea = new LineaLiquidacionComision();
            $newLinea->codagente = $data['codagente'];
            $newLinea->codcliente = $factura->codcliente;
            $newLinea->codigo = $factura->codigo;
            $newLinea->fecha = $factura->fecha;
            $newLinea->idfactura = $factura->idfactura;
            $newLinea->idliquidacion = $data['idliquidacion'];
            $newLinea->neto = $factura->neto;
            $newLinea->pagada = $factura->pagada;

            if ($factura->codagente == $data['codagente']) {
                $newLinea->totalcomision = $factura->totalcomision;
            } elseif ($factura->codagente2 == $data['codagente']) {
                $newLinea->totalcomision = $factura->totalcomision2;
            }

            if ($newLinea->save()) {
                $num++;
            }
        }

        // update total
        $this->getModel()->calculateTotalCommission($data['idliquidacion']);

        Tools::log()->notice('items-added-correctly', ['%num%' => $num]);
        return true;
    }

    /**
     * Get the list of invoices selected by the user
     *
     * @param array $data
     *
     * @return FacturaCliente[]
     */
    protected function getInvoicesFromDataForm(array $data): array
    {
        if (!isset($data['code'])) {
            return [];
        }

        $selected = implode(',', $data['code']);
        if (empty($selected)) {
            return [];
        }

        $invoice = new FacturaCliente();
        $where = [new DataBaseWhere('idfactura', $selected, 'IN')];
        return $invoice->all($where, ['idfactura' => 'ASC'], 0, 0);
    }

    /**
     * Loads the data to display.
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'ListLineaLiquidacionComision':
                $this->loadDataLineas($viewName, $view);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadDataLineas($viewName, $view): void
    {
        $mainViewName = $this->getMainViewName();
        $where = [new DataBaseWhere('idliquidacion', $this->getViewModelValue($mainViewName, 'idliquidacion'))];
        $view->loadData('', $where);

        // Set master values to insert modal view
        $view->model->codagente = $this->getViewModelValue($mainViewName, 'codagente');
        $view->model->codserie = $this->getViewModelValue($mainViewName, 'codserie');
        $view->model->idempresa = $this->getViewModelValue($mainViewName, 'idempresa');
        $view->model->idliquidacion = $this->getViewModelValue($mainViewName, 'idliquidacion');

        if ($view->count === 0) {
            $this->setSettings($viewName, 'btnDelete', false);
            return;
        }

        // disable some fields in the main view
        $this->views[$mainViewName]->disableColumn('company', false, 'true');
        $this->views[$mainViewName]->disableColumn('serie', false, 'true');
        $this->views[$mainViewName]->disableColumn('agent', false, 'true');

        // Is there an invoice created?
        $canInvoice = empty($this->getViewModelValue($mainViewName, 'idfactura'));

        // Update insert/delete buttons status
        $this->setSettings($viewName, 'btnNew', $canInvoice);
        $this->setSettings($viewName, 'btnDelete', $canInvoice);

        if ($canInvoice) {
            $this->addButton($viewName, [
                'action' => 'calculatecommission',
                'confirm' => 'true',
                'icon' => 'fa-solid fa-percentage',
                'label' => 'calculate'
            ]);
        }

        $total = $this->getViewModelValue($mainViewName, 'total');
        if ($canInvoice && $total > 0.0) {
            $this->addButton($mainViewName, [
                'action' => 'generateinvoice',
                'color' => 'info',
                'confirm' => true,
                'icon' => 'fa-solid fa-file-invoice',
                'label' => 'generate-invoice'
            ]);
        }
    }
}
