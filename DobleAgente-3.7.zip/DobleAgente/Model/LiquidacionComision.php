<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Model;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Plugins\Comisiones\Model\LiquidacionComision as ParentModel;

/**
 * Description of LiquidacionComision
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class LiquidacionComision extends ParentModel
{
    /**
     * @param string $code
     */
    public function calculateTotalCommission($code): bool
    {
        $sql = 'UPDATE ' . self::tableName()
            . ' SET total = COALESCE('
            . '(SELECT SUM(totalcomision)'
            . ' FROM lineasliquidacionescom WHERE idliquidacion = ' . self::$dataBase->var2str($code) . ')'
            . ',0)'
            . ' WHERE idliquidacion = ' . self::$dataBase->var2str($code);

        return self::$dataBase->exec($sql);
    }

    public function generateInvoice(): bool
    {
        if (null !== $this->idfactura) {
            return true;
        }

        $agent = $this->getAgent();
        $contact = $agent->getContact();
        if (empty($contact->codproveedor)) {
            Tools::log()->warning('agent-dont-have-associated-supplier');
            return false;
        }

        $invoice = new FacturaProveedor();
        $invoice->setSubject($contact->getSupplier());
        $invoice->codserie = $this->codserie;
        $invoice->fecha = $this->fecha;

        if ($invoice->save()) {
            $product = $agent->getProducto();
            $newLine = $product->exists() ? $invoice->getNewProductLine($product->referencia) : $invoice->getNewLine();
            $newLine->cantidad = 1;
            $newLine->descripcion = Tools::lang()->trans('commission-settlement', ['%code%' => $this->idliquidacion]);
            $newLine->pvpunitario = $this->total;
            $newLine->save();

            $lines = $invoice->getLines();
            if (Calculator::calculate($invoice, $lines, true)) {
                $this->idfactura = $invoice->idfactura;
                return $this->save();
            }

            $invoice->delete();
        }

        return false;
    }
}
