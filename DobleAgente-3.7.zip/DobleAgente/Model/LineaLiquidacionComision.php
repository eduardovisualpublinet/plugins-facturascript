<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\DobleAgente\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\FacturaCliente;

/**
 * Description of LineaLiquidacionComision
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class LineaLiquidacionComision extends ModelClass
{
    use ModelTrait;

    /**
     * @var string
     */
    public $codagente;

    /**
     * @var string
     */
    public $codcliente;

    /**
     * @var string
     */
    public $codigo;

    /**
     * @var string
     */
    public $fecha;

    /**
     * @var int
     */
    public $id;

    /**
     * @var int
     */
    public $idfactura;

    /**
     * @var int
     */
    public $idliquidacion;

    /**
     * @var float
     */
    public $neto;

    /**
     * @var bool
     */
    public $pagada;

    /**
     * @var float
     */
    public $totalcomision;

    public function clear(): void
    {
        parent::clear();
        $this->totalcomision = 0.0;
    }

    public function getFactura(): FacturaCliente
    {
        $factura = new FacturaCliente();
        $factura->load($this->idfactura);
        return $factura;
    }

    public function install(): string
    {
        // dependencias
        new LiquidacionComision();
        new FacturaCliente();

        return parent::install();
    }

    public static function tableName(): string
    {
        return 'lineasliquidacionescom';
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return $this->getFactura()->url();
    }
}
