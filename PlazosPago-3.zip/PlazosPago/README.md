# PlazosPago
Plugin para FacturaScripts que permite estableces plazos en las formas de pago y aplicar estos plazos en la generación de recibos.
- https://facturascripts.com/plugin/plazospago

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PlazosPago**.