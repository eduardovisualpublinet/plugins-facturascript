# PlantillaDetallada
Añade una nueva plantilla de facturas al plugin PlantillasPDF.

- https://facturascripts.com/plugins/plantilladetallada

Requiere el plugin PlantillasPDF:

- https://facturascripts.com/plugins/plantillaspdf 

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PlantillaDetallada**.

## Ayuda
Para cualquier duda o sugerencia, por favor, utiliza la web del plugin:

- [Cómo imprimir albaranes sin valorar](https://facturascripts.com/publicaciones/imprimir-albaranes-sin-valorar)
- [Cómo cambiar los decimales en las cantidades](https://facturascripts.com/publicaciones/como-cambiar-los-decimales-de-cantidad)
- [Opciones de maquetación del PDF](https://facturascripts.com/publicaciones/opciones-de-maquetacion)
- [Cómo crear una plantilla PDF personalizada](https://facturascripts.com/publicaciones/crear-una-plantilla-personalizada-698)
