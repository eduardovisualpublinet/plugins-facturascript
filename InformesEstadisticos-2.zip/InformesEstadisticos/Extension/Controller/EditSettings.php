<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Extension\Controller;

use Closure;
use FacturaScripts\Core\Tools;

/**
 * Add views to EditSettings controller.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * @method addListView(string $viewName, string $model, string $title, string $icon)
 */
class EditSettings
{
    public function createViews(): Closure
    {
        return function () {
            $i18n = Tools::lang();
            $this->addListView('ListStatisticReport', 'StatisticReport', 'statistic-formats', 'fa-solid fa-print')
                ->addOrderBy(['grouptype', 'name'], 'type')
                ->addOrderBy(['name'], 'name')
                ->addFilterSelect('grouptype', 'type', 'grouptype', [
                    '0' => $i18n->trans('customers'),
                    '1' => $i18n->trans('agents'),
                    '2' => $i18n->trans('suppliers'),
                    '3' => $i18n->trans('products'),
                ]);
        };
    }

    public function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName === 'ListStatisticReport') {
                $view->loadData('');
            }
        };
    }
}
