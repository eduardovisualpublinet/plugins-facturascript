<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Controller;

use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Lib\ExtendedController\ListView;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;

/**
 * Controller for Statistic models.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ListStatistic extends ListController
{
    protected const VIEW_AGENT = 'ListStatisticAgent';
    protected const VIEW_CUSTOMER = 'ListStatisticCustomer';
    protected const VIEW_PRODUCT = 'ListStatisticProduct';
    protected const VIEW_SUPPLIER = 'ListStatisticSupplier';

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'statistics';
        $pageData['icon'] = 'fa-solid fa-ranking-star';
        $pageData['menu'] = 'reports';
        return $pageData;
    }

    /**
     * Load views
     */
    protected function createViews()
    {
        $this->createViewCustomer();
        $this->createViewAgent();
        $this->createViewSupplier();
        $this->createViewProduct();
    }

    /**
     * Add a statistic agent view.
     */
    protected function createViewAgent(): void
    {
        $this->createViewStatistic(self::VIEW_AGENT, 'StatisticAgent', 'agents', 'fa-solid fa-user-tie');
        $this->addFilterDocTypeCustomer(self::VIEW_AGENT);
    }

    /**
     * Add a statistic customer view.
     */
    protected function createViewCustomer(): void
    {
        $this->createViewStatistic(self::VIEW_CUSTOMER, 'StatisticCustomer', 'customers', 'fa-solid fa-users');
        $this->addFilterDocTypeCustomer(self::VIEW_CUSTOMER);
    }

    /**
     * Add a statistic product view.
     */
    protected function createViewProduct(): void
    {
        $this->createViewStatistic(self::VIEW_PRODUCT, 'StatisticProduct', 'products', 'fa-solid fa-cubes');
        $this->addFilterDocTypeCustomer(self::VIEW_PRODUCT);
    }

    /**
     * Add a statistic supplier view.
     */
    protected function createViewSupplier(): void
    {
        $lang = Tools::lang();
        $this->createViewStatistic(self::VIEW_SUPPLIER, 'StatisticSupplier', 'suppliers', 'fa-solid fa-users')
            ->addFilterSelect('data-source', 'data-source', 'doctype', [
                ['code' => ModelStatistic::DOCTYPE_INVOICES, 'description' => $lang->trans('supplier-invoice')],
                ['code' => ModelStatistic::DOCTYPE_DELIVERIES, 'description' => $lang->trans('supplier-delivery-note')],
                ['code' => ModelStatistic::DOCTYPE_ORDERS, 'description' => $lang->trans('supplier-order')],
                ['code' => ModelStatistic::DOCTYPE_ESTIMATION, 'description' => $lang->trans('supplier-estimation')],
            ]);
    }

    /**
     * Add a filter for customer document type.
     *
     * @param string $viewName
     */
    private function addFilterDocTypeCustomer(string $viewName): void
    {
        $lang = Tools::lang();
        $this->addFilterSelect($viewName, 'data-source', 'data-source', 'doctype', [
            ['code' => ModelStatistic::DOCTYPE_INVOICES, 'description' => $lang->trans('customer-invoice')],
            ['code' => ModelStatistic::DOCTYPE_DELIVERIES, 'description' => $lang->trans('customer-delivery-note')],
            ['code' => ModelStatistic::DOCTYPE_ORDERS, 'description' => $lang->trans('customer-order')],
            ['code' => ModelStatistic::DOCTYPE_ESTIMATION, 'description' => $lang->trans('customer-estimation')],
        ]);
    }

    /**
     * Add a standard view for a statistic view.
     *
     * @param string $viewName
     * @param string $modelName
     * @param string $title
     * @param string $icon
     * @return ListView
     */
    private function createViewStatistic(string $viewName, string $modelName, string $title, string $icon): ListView
    {
        $view = $this->addView($viewName, $modelName, $title, $icon)
            ->addSearchFields(['name'])
            ->addOrderBy(['name'], 'description')
            ->addOrderBy(['id'], 'code');

        // disable company column if there is only one company
        $companies = Empresas::codeModel();
        if (count($companies) > 2) {
            $view->addFilterSelect('idcompany', 'company', 'idcompany', $companies);
            $view->disableColumn('company', false);
        }

        // show createuser column only for admin users
        if (Session::user()->admin) {
            $view->disableColumn('createuser', false);
        }
        return $view;
    }
}
