<?php
/**
 * This file is part of InformesEstadísticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadísticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Controller;

use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\EditStatisticController;
use FacturaScripts\Plugins\InformesEstadisticos\Model\StatisticReport;

/**
 * Controller to edit statistic of customer.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditStatisticCustomer extends EditStatisticController
{
    /**
     * Get the group type for get the format reports.
     *
     * @return int
     */
    public function getGroupTypeFormat(): int
    {
        return StatisticReport::GROUPTYPE_CUSTOMER;
    }

    /**
     * Returns the class name of the model to use in the editView.
     */
    public function getModelClassName(): string
    {
        return 'StatisticCustomer';
    }

    /**
     * Return the basic data for this page.
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'statistic-customer';
        $pageData['icon'] = 'fa-solid fa-ranking-star';
        $pageData['menu'] = 'reports';
        return $pageData;
    }
}
