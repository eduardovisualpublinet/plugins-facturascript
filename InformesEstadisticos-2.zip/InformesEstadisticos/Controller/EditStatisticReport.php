<?php
/**
 * This file is part of InformesEstadísticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadísticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\StatisticTool;

/**
 * Controller to edit statistic of report formats.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditStatisticReport extends EditController
{
    /**
     * Returns the class name of the model to use in the editView.
     */
    public function getModelClassName(): string
    {
        return 'StatisticReport';
    }

    /**
     * Return the basic data for this page.
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'statistic-report';
        $pageData['icon'] = 'fa-solid fa-print';
        $pageData['menu'] = 'admin';
        return $pageData;
    }

    /**
     * Run the autocomplete action.
     * Returns a JSON string for the searched values.
     *
     * @return array
     */
    protected function autocompleteAction(): array {
        $field = $this->request->get('field', '');
        if (empty($field)) {
            return [];
        }

        return match ($field) {
            'format' => $this->getFormatsAction(),
            'model' => $this->getModelsAction(),
            default => parent::autocompleteAction(),
        };
    }

    /**
     * Get XMLViews with term into model name.
     *
     * @return array
     */
    private function getFormatsAction(): array
    {
        $term = strtolower($this->request->request->get('term'));
        if (empty($term)) {
            return [];
        }

        return StatisticTool::getFormatViews($term, 5);
    }

    /**
     * Get ModelReports with term into model name.
     *
     * @return array
     */
    private function getModelsAction(): array
    {
        $term = strtolower($this->request->request->get('term'));
        if (empty($term)) {
            return [];
        }

        return StatisticTool::getModels($term, 5);
    }
}
