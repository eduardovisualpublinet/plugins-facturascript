<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model;

use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;

/**
 * Statistic Agent data model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticAgent extends ModelStatistic
{
    use ModelTrait;

    /** @var int */
    public $channel;

    /** @var string */
    public $endagent;

    /** @var string */
    public $startagent;

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'statistics_agents';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListStatistic?activetab=' . $list);
    }
}
