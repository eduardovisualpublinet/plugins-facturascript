<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model;

use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;

/**
 * Statistic Product data model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticProduct extends ModelStatistic
{
    public const ACTIVE_ALL = 0;
    public const ACTIVE_ACTIVE = 1;
    public const ACTIVE_BLOCKED = 2;

    public const ACTIVITY_ALL = 0;
    public const ACTIVITY_PURCHASED = 1;
    public const ACTIVITY_SALES = 2;

    public const ORDER_QUANTITY = 2;
    public const ORDER_AMOUNT = 3;
    public const ORDER_BENEFIT = 4;

    use ModelTrait;

    /** @var int */
    public $active;

    /** @var int */
    public $activity;

    /** @var int */
    public $channel;

    /** @var string */
    public $endreference;

    /**
     * Link to Customer Model.
     *
     * @var string
     */
    public $idcustomer;

    /**
     * Link to Family Model.
     *
     * @var string
     */
    public $idfamily;

    /**
     * Link to Customer Group Model.
     *
     * @var string
     */
    public $idgroup;

    /**
     * Link to Manufacturer Model.
     *
     * @var string
     */
    public $idmanufacturer;

    /** @var string */
    public $startreference;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->active = self::ACTIVE_ALL;
        $this->activity = self::ACTIVITY_ALL;
    }

    /**
     * Return the table name for the source document.
     *
     * @param bool $forCustomer
     * @return string
     */
    public function getSourceTableName(bool $forCustomer): string
    {
        $suffix = $forCustomer ? 'cli' : 'prov';
        return match ($this->doctype) {
            self::DOCTYPE_DELIVERIES => 'albaranes' . $suffix,
            self::DOCTYPE_ORDERS => 'pedidos' . $suffix,
            self::DOCTYPE_ESTIMATION => 'presupuestos' . $suffix,
            default => 'facturas' . $suffix,
        };
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'statistics_products';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListStatistic?activetab=' . $list);
    }
}
