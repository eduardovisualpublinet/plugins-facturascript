<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model;

use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;

/**
 * Statistic Customer data model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticCustomer extends ModelStatistic
{
    use ModelTrait;

    /** @var int */
    public $channel;

    /** @var string */
    public $endcustomer;

    /**
     * Link to Agent Model.
     *
     * @var string
     */
    public $idagent;

    /**
     * Link to Customer Groups Model.
     *
     * @var string
     */
    public $idgroup;

    /** @var string */
    public $startcustomer;

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'statistics_customers';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListStatistic?activetab=' . $list);
    }
}
