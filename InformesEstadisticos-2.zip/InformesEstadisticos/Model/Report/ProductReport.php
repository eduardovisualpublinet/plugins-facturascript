<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report;

use Exception;
use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelReport;
use FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data\ProductData;
use FacturaScripts\Plugins\InformesEstadisticos\Model\StatisticProduct;

/**
 * Class to calculate statistic of product.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ProductReport extends ModelReport
{
    use ExtensionsTrait;

    /** @var StatisticProduct */
    protected $statistic;

    /**
     * Load report data into array data property.
     *
     * @throws Exception
     */
    public function loadData(): void
    {
        $decimals = Tools::settings('default', 'decimals');
        $data = self::$dataBase->select($this->getSQL());
        foreach ($data as $row) {
            $record = new ProductData();
            $record->code = $row['code'];
            $record->name = $row['name'];

            // Load values for months
            for ($x = 0; $x <= 12; $x++) {
                $amount = ($x === 0) ? 'pvptotal' : 'pvptotal' . $x;
                $record->amount[$x] = round($row[$amount], $decimals);

                $benefit = ($x === 0) ? 'beneficio' : 'beneficio' . $x;
                $record->benefit[$x] = round($row[$benefit], $decimals);

                $cost = ($x === 0) ? 'coste' : 'coste' . $x;
                $record->cost[$x] = round($row[$cost], $decimals);

                $quantity = $x === 0 ? 'cantidad' : 'cantidad' . $x;
                $record->quantity[$x] = round($row[$quantity], $decimals);
            }
            $this->data[] = $record;
        }
    }

    /**
     * Returns the ORDER BY clause for SQL to get the data.
     *
     * @return string
     */
    protected function getOrderBySQL(): string
    {
        $dir = $this->statistic->orderdesc ? ' DESC' : ' ASC';
        $limit = $this->statistic->orderlimit ? ' LIMIT ' . $this->statistic->orderlimit : '';
        return match ($this->statistic->orderfield) {
            $this->statistic::ORDER_QUANTITY => 'statistic.cantidad' . $dir . $limit,
            $this->statistic::ORDER_AMOUNT => 'statistic.pvptotal' . $dir . $limit,
            $this->statistic::ORDER_BENEFIT => 'statistic.beneficio' . $dir . $limit,
            default => parent::getOrderBySQL(),
        };
    }

    /**
     * Return the SQL to get the data.
     *
     * @throws Exception
     * @return string
     */
    protected function getSQL(): string
    {
        $baseSQL = $this->getSQLBase();
        return "SELECT statistic.*"
            . " FROM (" . $baseSQL . ") statistic"
            . " ORDER BY " . $this->getOrderBySQL();
    }

    /**
     * Return the base SQL to get the data.
     *
     * @throws Exception
     */
    protected function getSQLBase(): string
    {
        $curPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
        );

        return "SELECT line.referencia code, productos.descripcion name,"
            . $this->getSQLColumns($curPeriod, 'cantidad') . ","
            . " SUM(line.cantidad) cantidad,"
            . $this->getSQLColumns($curPeriod, 'pvptotal') . ","
            . " SUM(line.pvptotal) pvptotal,"
            . $this->getSQLColumns($curPeriod, 'coste') . ","
            . " SUM(variantes.coste * line.cantidad) coste,"
            . $this->getSQLColumns($curPeriod, 'beneficio') . ","
            . " SUM(line.pvptotal - (variantes.coste * line.cantidad)) beneficio"
            . " FROM " . $this->getSQLFrom()
            . " INNER JOIN series ON series.codserie = document.codserie"
            . " INNER JOIN clientes ON clientes.codcliente = document.codcliente"
            . " INNER JOIN productos ON productos.idproducto = line.idproducto"
            . " INNER JOIN variantes ON variantes.idproducto = line.idproducto AND variantes.referencia = line.referencia"
            . " WHERE " . $this->getWhere()
            . " GROUP BY line.referencia, productos.descripcion";
    }

    /**
     * Return the SQL columns for each month plus total.
     *
     * @param string $period
     * @param int $month
     * @param string $column
     * @return string
     */
    protected function getSQLColumn(string $period, int $month, string $column): string
    {
        return " SUM("
            . "CASE WHEN document.fecha BETWEEN " . $period
            . " AND EXTRACT(MONTH from document.fecha) = " . $month
            . " THEN " . $this->getSQLColumnCalculation($column)
            . " ELSE 0.00 "
            . "END) " . $column . $month;
    }

    /**
     * Return the where clause for SQL from a statistic model.
     *
     * @throws Exception
     * @return string
     */
    protected function getWhere(): string
    {
        $curPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
        );

        $result = "document.fecha BETWEEN " . $curPeriod;

        if (false === empty($this->statistic->idcompany)) {
            $result .= " AND document.idempresa = " . $this->statistic->idcompany;
        }

        if (false === empty($this->statistic->idcustomer)) {
            $result .= " AND document.codcliente = '" . $this->statistic->idcustomer . "'";
        }

        if (false === empty($this->statistic->idgroup)) {
            $result .= " AND clientes.codgrupo = '" . $this->statistic->idgroup . "'";
        }

        if (false === empty($this->statistic->channel)) {
            $result .= " AND series.canal = " . $this->statistic->channel;
        }

        if (false === empty($this->statistic->idfamily)) {
            $result .= " AND productos.codfamilia = '" . $this->statistic->idfamily . "'";
        }

        if (false === empty($this->statistic->idmanufacturer)) {
            $result .= " AND productos.codfabricante = '" . $this->statistic->idmanufacturer . "'";
        }

        if ($this->statistic->active > 0) {
            $result .= ($this->statistic->active === 1)
                ? ' AND productos.bloqueado = FALSE'
                : ' AND productos.bloqueado = TRUE';
        }

        if ($this->statistic->activity > 0) {
            $fieldName = $this->statistic->activity === 1 ? 'secompra' : 'sevende';
            $result .= ' AND productos.' . $fieldName . ' = TRUE ';
        }

        if (false === empty($this->statistic->startreference)) {
            $result .= " AND line.referencia >= '" . $this->statistic->startreference . "'";
        }

        if (false === empty($this->statistic->endreference)) {
            $result .= " AND line.referencia <= '" . $this->statistic->endreference . "'";
        }

        $additionalWhere = $this->pipe('getWhere');
        if ($additionalWhere) {
            $result .= $additionalWhere;
        }

        return $result;
    }

    /**
     * Return the SQL calculation for a column.
     *
     * @param string $column
     * @return string
     */
    private function getSQLColumnCalculation(string $column): string
    {
        return match ($column) {
            'cantidad' => 'line.cantidad',
            'coste' => 'line.cantidad * variantes.coste',
            default => 'line.pvptotal * COALESCE(document.tasaconv, 1)',
        };
    }

    /**
     * Return the FROM clause for SQL from a statistic model.
     *
     * @return string
     */
    private function getSQLFrom(): string
    {
        return match ($this->statistic->doctype) {
            $this->statistic::DOCTYPE_DELIVERIES => 'albaranescli document INNER JOIN lineasalbaranescli line ON line.idalbaran = document.idalbaran',
            $this->statistic::DOCTYPE_ORDERS => 'pedidoscli document INNER JOIN lineaspedidoscli line ON line.idpedido = document.idpedido',
            $this->statistic::DOCTYPE_ESTIMATION => 'presupuestoscli document INNER JOIN lineaspresupuestoscli line ON line.idpresupuesto = document.idpresupuesto',
            default => 'facturascli document INNER JOIN lineasfacturascli line ON line.idfactura = document.idfactura',
        };
    }
}
