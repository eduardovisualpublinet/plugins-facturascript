<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report;

use Exception;
use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelReport;
use FacturaScripts\Plugins\InformesEstadisticos\Model\StatisticSupplier;

/**
 * Class to calculate statistic of supplier.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class SupplierReport extends ModelReport
{
    use ExtensionsTrait;

    /** @var StatisticSupplier */
    protected $statistic;

    /**
     * Return the SQL to get the data.
     *
     * @throws Exception
     * @return string
     */
    protected function getSQL(): string
    {
        $baseSQL = $this->getSQLBase();
        return "SELECT statistic.current_neto - statistic.previous_neto difference_neto,"
                . "CASE WHEN statistic.previous_neto > 0"
                    . " THEN round((statistic.current_neto - statistic.previous_neto) * 100 / statistic.previous_neto, 3)"
                    . " ELSE 100.00"
                . " END variation_neto,"
                . "statistic.*"
                . " FROM (" . $baseSQL . ") statistic"
                . " ORDER BY " . $this->getOrderBySQL();
    }

    /**
     * Return the subquery to get the base data.
     *
     * @throws Exception
     * @return string
     */
    protected function getSQLBase(): string
    {
        $curPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
        );

        $prevPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
            1
        );

        $innerSeries = empty($this->statistic->channel)
            ? ''
            : ' INNER JOIN series ON series.codserie = document.codserie';

        return "SELECT document.codproveedor code, proveedores.nombre name,"
            . $this->getSQLColumns($curPeriod, 'current_neto') . ","
            . " SUM(CASE WHEN document.fecha BETWEEN " . $curPeriod . " THEN document.neto / COALESCE(document.tasaconv, 1.00) ELSE 0.00 END) current_neto,"
            . $this->getSQLColumns($prevPeriod, 'previous_neto') . ","
            . " SUM(CASE WHEN document.fecha BETWEEN " . $prevPeriod . " THEN document.neto / COALESCE(document.tasaconv, 1.00) ELSE 0.00 END) previous_neto"
            . " FROM " . $this->statistic->getSourceTableName(false) . " document"
            . " INNER JOIN proveedores ON proveedores.codproveedor = document.codproveedor"
            . $innerSeries
            . " WHERE " . $this->getWhere()
            . " GROUP BY document.codproveedor, proveedores.nombre";
    }

    /**
     * Return the where clause for SQL from statistic model.
     *
     * @throws Exception
     * @return string
     */
    protected function getWhere(): string
    {
        $result = parent::getWhere();

        if (false === empty($this->statistic->startsupplier)) {
            $result .= " AND document.codproveedor >= '" . $this->statistic->startsupplier . "'";
        }

        if (false === empty($this->statistic->endsupplier)) {
            $result .= " AND document.codproveedor <= '" . $this->statistic->endsupplier . "'";
        }

        switch ($this->statistic->suppliertype) {
            case StatisticSupplier::SUPPLIER_TYPE_SUPPLIERS:
                $result .= " AND NOT proveedores.acreedor";
                break;

            case StatisticSupplier::SUPPLIER_TYPE_CREDITORS:
                $result .= " AND proveedores.acreedor";
                break;
        }

        $additionalWhere = $this->pipe('getWhere');
        if ($additionalWhere) {
            $result .= $additionalWhere;
        }

        return $result;
    }
}
