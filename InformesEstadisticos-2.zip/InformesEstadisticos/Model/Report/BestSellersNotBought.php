<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report;

use Exception;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelReport;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;
use FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data\CustomerNotBoughtData;
use FacturaScripts\Plugins\InformesEstadisticos\Model\StatisticCustomer;

/**
 * Class to calculate the list of best-selling products that a customer
 * has not purchased.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class BestSellersNotBought extends ModelReport
{

    /** @var StatisticCustomer */
    protected $statistic;

    /**
     * List of best-selling products (by amount).
     *
     * @var array
     */
    protected array $productAmountList;

    /**
     * List of best-selling products (by quantity).
     *
     * @var array
     */
    protected array $productQuantityList;

    /**
     * Class constructor.
     * Need a statistic model and a statistic id from give filter and report configuration.
     *
     * @param $statisticModel
     */
    public function __construct($statisticModel)
    {
        parent::__construct($statisticModel);
        $this->productAmountList = [];
        $this->productQuantityList = [];
    }

    /**
     * Load report data into array data property.
     *   - Load the more best-selling products list.
     *   - From customer list:
     *      - get the list of purchased products (by amount and quantity).
     *      - calculate the not purchased products list (by amount and quantity).
     *
     * @throws Exception
     */
    public function loadData(): void
    {
        if (false === $this->loadProductList()) {
            return;
        }

        $clients = self::$dataBase->select($this->getSQL());
        foreach ($clients as $client) {
            $purchasedAmountList = $this->getProducts('pvptotal', $client['code'], 0);
            $notBoughtAmountList = $this->getNoBoughtItems($purchasedAmountList, false);

            $purchasedQuantityList = $this->getProducts('cantidad', $client['code'], 0);
            $notBoughtQuantityList = $this->getNoBoughtItems($purchasedQuantityList, true);

            $row = new CustomerNotBoughtData();
            $row->code = $client['code'];
            $row->name = $client['name'];
            $row->productAmountList = array_slice($purchasedAmountList, 0, 10);
            $row->productQuantityList = array_slice($purchasedQuantityList, 0, 10);
            $row->notBoughtAmountList = array_values($notBoughtAmountList);
            $row->notBoughtQuantityList = array_values($notBoughtQuantityList);
            $this->data[] = $row;
        }
    }

    /**
     * Returns the list of best-selling products by the indicated field.
     *   - The list can be filtered by customer.
     *   - The list can be limited to the indicated number of products.
     *
     * @param string $field
     * @param string $idclient
     * @param int $limit
     * @return array
     * @throws Exception
     */
    protected function getProducts(string $field, string $idclient, int $limit): array
    {
        $curPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
        );

        $whereCompany = empty($this->statistic->idcompany) ? '' : ' AND document.idempresa = ' . $this->statistic->idcompany;
        $whereClient = empty($idclient) ? '' : " AND document.codcliente = '" . $idclient . "'";
        $whereLimit = $limit > 0 ? ' LIMIT ' . $limit : '';

        $sql = 'SELECT productos.referencia, productos.descripcion, SUM(line.' . $field . ') total'
            . ' FROM ' . $this->getSQLFrom()
            . ' INNER JOIN productos ON productos.idproducto = line.idproducto'
            . ' WHERE document.fecha BETWEEN ' . $curPeriod
            . $whereClient
            . $whereCompany
            . ' GROUP BY 1, 2 ORDER BY 3 DESC'
            . $whereLimit;

        $result = [];
        foreach (self::$dataBase->select($sql) as $row) {
            $result[$row['referencia']] = [
                'code' => $row['referencia'],
                'description' => $row['descripcion'],
                'total' => (float)$row['total'] ?? 0.00,
            ];
        }
        return $result;
    }

    /**
     * Returns the ORDER BY clause for SQL to get the data.
     *
     * @return string
     */
    protected function getOrderBySQL(): string
    {
        $dir = $this->statistic->orderdesc ? ' DESC' : ' ASC';
        $limit = $this->statistic->orderlimit ? ' LIMIT ' . $this->statistic->orderlimit : '';
        return $this->statistic->orderfield === ModelStatistic::ORDER_NAME
            ? 'clientes.nombre' . $dir . $limit
            : 'clientes.codcliente' . $dir . $limit;
    }

    /**
     * Return the SQL to get the data.
     *
     * @throws Exception
     * @return string
     */
    protected function getSQL(): string
    {
        return 'SELECT codcliente code, nombre name, codagente idagent, codgrupo idgroup'
            . ' FROM clientes'
            . ' WHERE ' . $this->getWhere()
            . ' ORDER BY ' . $this->getOrderBySQL();
    }

    /**
     * Return the where clause for SQL from statistic model.
     *
     * @throws Exception
     * @return string
     */
    protected function getWhere(): string
    {
        $result = '1 = 1';

        if (false === empty($this->statistic->idgroup)) {
            $result .= " AND clientes.codgrupo = '" . $this->statistic->idgroup . "'";
        }

        if (false === empty($this->statistic->startcustomer)) {
            $result .= " AND clientes.codcliente >= '" . $this->statistic->startcustomer . "'";
        }

        if (false === empty($this->statistic->endcustomer)) {
            $result .= " AND clientes.codcliente <= '" . $this->statistic->endcustomer . "'";
        }

        if (false === empty($this->statistic->idagent)) {
            $result .= " AND clientes.codagente = '" . $this->statistic->idagent . "'";
        }

        return $result;
    }

    /**
     * Returns the list of best-selling products that the customer has not purchased.
     *
     * @param array $boughtProducts
     * @param bool $isQuantity
     * @return array
     */
    private function getNoBoughtItems(array $boughtProducts, bool $isQuantity): array
    {
        $result = $isQuantity ? $this->productQuantityList : $this->productAmountList;
        foreach ($boughtProducts as $reference => $data) {
            if (isset($result[$reference])) {
                unset($result[$reference]);
                if (empty($result)) {
                    break;
                }
            }
        }
        return $result;
    }

    /**
     * Return the FROM clause for SQL to get the data.
     *
     * @return string
     */
    private function getSQLFrom(): string
    {
        return match ($this->statistic->doctype) {
            $this->statistic::DOCTYPE_DELIVERIES => 'albaranescli document INNER JOIN lineasalbaranescli line ON line.idalbaran = document.idalbaran',
            $this->statistic::DOCTYPE_ORDERS => 'pedidoscli document INNER JOIN lineaspedidoscli line ON line.idpedido = document.idpedido',
            $this->statistic::DOCTYPE_ESTIMATION => 'presupuestoscli document INNER JOIN lineaspresupuestoscli line ON line.idpresupuesto = document.idpresupuesto',
            default => 'facturascli document INNER JOIN lineasfacturascli line ON line.idfactura = document.idfactura',
        };
    }

    /**
     * Load the best-selling products list and sort by reference.
     *
     * @return bool
     * @throws Exception
     */
    private function loadProductList(): bool
    {
        $this->productAmountList = $this->getProducts('pvptotal', '', 20);
        if (empty($this->productAmountList)) {
            return false;
        }

        $this->productQuantityList = $this->getProducts('cantidad', '', 20);
        return false === empty($this->productQuantityList);
    }
}
