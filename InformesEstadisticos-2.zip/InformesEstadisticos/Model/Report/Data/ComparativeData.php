<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data;

use FacturaScripts\Core\Tools;

/**
 * Class to manage statistic data for extended report
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ComparativeData
{
    /** @var string */
    public $code;

    /** @var string */
    public $coddivisa;

    /** @var float[] */
    public $current_value;

    /** @var float[] */
    public $difference;

    /** @var string */
    public $name;

    /** @var float[] */
    public $percentage;

    /** @var float[] */
    public $previous_value;

    /**
     * Class constructor.
     * Initialize arrays values with total + 12 months.
     *   - current_value: have the values for solicited period.
     *   - previous_value: have the values for previous period.
     *   - difference: have the difference between solicited (current) and previous period.
     */
    public function __construct()
    {
        //     0,       1,        2,     3,     4,   5,    6,    7,      8,         9,      10,       11,       12
        // Total, January, February, March, April, May, June, July, August, September, October, November, December
        $this->current_value = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->difference = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->previous_value = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->percentage = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];

        $this->coddivisa = Tools::settings('default', 'coddivisa', '');
    }

    /*
     * General methods
     */
    public function hasData(): bool
    {
        foreach ($this->current_value as $value) {
            if ($value !== 0.00) {
                return true;
            }
        }

        foreach ($this->previous_value as $value) {
            if ($value !== 0.00) {
                return true;
            }
        }
        return false;
    }

    /*
     * Semester methods
     */
    public function currentSemesterFirst(): float
    {
        return (float)round($this->currentQuarterFirst() + $this->currentQuarterSecond(), FS_NF0);
    }

    public function currentSemesterSecond(): float
    {
        return (float)round($this->currentQuarterThird() + $this->currentQuarterFourth(), FS_NF0);
    }

    public function previousSemesterFirst(): float
    {
        return (float)round($this->previousQuarterFirst() + $this->previousQuarterSecond(), FS_NF0);
    }

    public function previousSemesterSecond(): float
    {
        return (float)round($this->previousQuarterThird() + $this->previousQuarterFourth(), FS_NF0);
    }

    public function differenceSemesterFirst(): float
    {
        return (float)round($this->differenceQuarterFirst() + $this->differenceQuarterSecond(), FS_NF0);
    }

    public function differenceSemesterSecond(): float
    {
        return (float)round($this->differenceQuarterThird() + $this->differenceQuarterFourth(), FS_NF0);
    }

    public function percentageSemesterFirst(): float
    {
        $previous = $this->previousSemesterFirst();
        if ($previous > 0) {
            $difference = array_sum(array_slice($this->difference, 1, 6));
            return (float)round($difference * 100.00 / $previous, FS_NF0);
        }
        $current = $this->currentSemesterFirst();
        return $current > 0.00 ? 100.00 : 0.00;
    }

    public function percentageSemesterSecond(): float
    {
        $previous = $this->previousSemesterSecond();
        if ($previous > 0) {
            $difference = array_sum(array_slice($this->difference, 7, 6));
            return (float)round($difference * 100.00 / $previous, FS_NF0);
        }
        $current = $this->currentSemesterSecond();
        return $current > 0.00 ? 100.00 : 0.00;
    }

    /*
     * Quarter methods
     */
    public function currentQuarterFirst(): float
    {
        $result = array_sum(array_slice($this->current_value, 1, 3));
        return (float)round($result, FS_NF0);
    }

    public function currentQuarterSecond(): float
    {
        $result = array_sum(array_slice($this->current_value, 4, 3));
        return (float)round($result, FS_NF0);
    }

    public function currentQuarterThird(): float
    {
        $result = array_sum(array_slice($this->current_value, 7, 3));
        return (float)round($result, FS_NF0);
    }

    public function currentQuarterFourth(): float
    {
        $result = array_sum(array_slice($this->current_value, 10, 3));
        return (float)round($result, FS_NF0);
    }

    public function previousQuarterFirst(): float
    {
        $result = array_sum(array_slice($this->previous_value, 1, 3));
        return (float)round($result, FS_NF0);
    }

    public function previousQuarterSecond(): float
    {
        $result = array_sum(array_slice($this->previous_value, 4, 3));
        return (float)round($result, FS_NF0);
    }

    public function previousQuarterThird(): float
    {
        $result = array_sum(array_slice($this->previous_value, 7, 3));
        return (float)round($result, FS_NF0);
    }

    public function previousQuarterFourth(): float
    {
        $result = array_sum(array_slice($this->previous_value, 10, 3));
        return (float)round($result, FS_NF0);
    }

    public function differenceQuarterFirst(): float
    {
        $result = array_sum(array_slice($this->difference, 1, 3));
        return (float)round($result, FS_NF0);
    }

    public function differenceQuarterSecond(): float
    {
        $result = array_sum(array_slice($this->difference, 4, 3));
        return (float)round($result, FS_NF0);
    }

    public function differenceQuarterThird(): float
    {
        $result = array_sum(array_slice($this->difference, 7, 3));
        return (float)round($result, FS_NF0);
    }

    public function differenceQuarterFourth(): float
    {
        $result = array_sum(array_slice($this->difference, 10, 3));
        return (float)round($result, FS_NF0);
    }
}
