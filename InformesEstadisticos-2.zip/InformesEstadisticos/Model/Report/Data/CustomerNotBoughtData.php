<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data;

use FacturaScripts\Core\Tools;

/**
 * Class to manage statistic of best-selling products that a customer has not purchased.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class CustomerNotBoughtData
{
    /**
     * Customer code.
     *
     * @var string
     */
    public $code;

    /**
     * Customer name.
     *
     * @var string
     */
    public $name;

    /**
     * List of the more sellers products (by amount) that the customer has not purchased.
     *
     * @var array
     */
    public $notBoughtAmountList;

    /**
     * List of the more sellers products (by quantity) that the customer has not purchased.
     *
     * @var array
     */
    public $notBoughtQuantityList;

    /**
     * List of the products that the customer has purchased (by amount).
     *
     * @var array
     */
    public $productAmountList;

    /**
     * List of the products that the customer has purchased (by quantity).
     *
     * @var array
     */
    public $productQuantityList;

    /**
     * Class constructor.
     * Initialize reference array to empty array.
     */
    public function __construct()
    {
        $this->notBoughtAmountList = [];
        $this->notBoughtQuantityList = [];
        $this->productAmountList = [];
        $this->productQuantityList = [];
    }

    /**
     * Return the not bought amount for a product.
     * If the list is empty, return "no data" string.
     *
     * @param array $params
     * @return string
     */
    public function getNotBoughtAmount(array $params): string
    {
        $result = $this->notBoughtAmountList[$params[0]][$params[1]] ?? '';
        if (empty($result) && $params[0] === '0' && $params[1] === 'description') {
            $result = Tools::lang()->trans('no-data');
        }
        return $result;
    }

    /**
     * Return the not bought quantity for a product.
     * If the list is empty, return "no data" string.
     *
     * @param array $params
     * @return string
     */
    public function getNotBoughtQuantity(array $params): string
    {
        $result = $this->notBoughtQuantityList[$params[0]][$params[1]] ?? '';
        if (empty($result) && $params[0] === '0' && $params[1] === 'description') {
            $result = Tools::lang()->trans('no-data');
        }
        return $result;
    }

    /**
     * Return the customer purchased amount for a product.
     * If the list is empty, return "no data" string.
     *
     * @param array $params
     * @return string
     */
    public function getProductAmount(array $params): string
    {
        $result = $this->productAmountList[$params[0]][$params[1]] ?? '';
        if (empty($result) && $params[0] === '0' && $params[1] === 'description') {
            $result = Tools::lang()->trans('no-data');
        }
        return $result;
    }

    /**
     * Return the customer purchased quantity for a product.
     * If the list is empty, return "no data" string.
     *
     * @param array $params
     * @return string
     */
    public function getProductQuantity(array $params): string
    {
        $result = $this->productQuantityList[$params[0]][$params[1]] ?? '';
        if (empty($result) && $params[0] === '0' && $params[1] === 'description') {
            $result = Tools::lang()->trans('no-data');
        }
        return $result;
    }
}
