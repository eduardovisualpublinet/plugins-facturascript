<?php

namespace FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data;

class ProductData
{
    /** @var float[] */
    public $amount;

    /** @var float[] */
    public $benefit;

    /** @var string */
    public $code;

    /** @var float[] */
    public $cost;

    /** @var string */
    public $name;

    /** @var float[] */
    public $quantity;

    /**
     * Class constructor.
     * Initialize arrays values with total + 12 months.
     *   - cantidad: have the values for quantity into period.
     *   - pvptotal: have the values for amount into period.
     */
    public function __construct()
    {
        //     0,       1,        2,     3,     4,   5,    6,    7,      8,         9,      10,       11,       12
        // Total, January, February, March, April, May, June, July, August, September, October, November, December
        $this->amount = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->benefit = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->cost = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
        $this->quantity = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];
    }

    /*
     * Semester methods
     */
    public function amountSemesterFirst(): float
    {
        return (float)round($this->amountQuarterFirst() + $this->amountQuarterSecond(), FS_NF0);
    }

    public function amountSemesterSecond(): float
    {
        return (float)round($this->amountQuarterThird() + $this->amountQuarterFourth(), FS_NF0);
    }

    public function quantitySemesterFirst(): float
    {
        return (float)round($this->quantityQuarterFirst() + $this->quantityQuarterSecond(), FS_NF0);
    }

    public function quantitySemesterSecond(): float
    {
        return (float)round($this->quantityQuarterThird() + $this->quantityQuarterFourth(), FS_NF0);
    }

    /*
     * Quarter methods
     */
    public function amountQuarterFirst(): float
    {
        $result = array_sum(array_slice($this->amount, 1, 3));
        return (float)round($result, FS_NF0);
    }

    public function amountQuarterSecond(): float
    {
        $result = array_sum(array_slice($this->amount, 4, 3));
        return (float)round($result, FS_NF0);
    }

    public function amountQuarterThird(): float
    {
        $result = array_sum(array_slice($this->amount, 7, 3));
        return (float)round($result, FS_NF0);
    }

    public function amountQuarterFourth(): float
    {
        $result = array_sum(array_slice($this->amount, 10, 3));
        return (float)round($result, FS_NF0);
    }

    public function quantityQuarterFirst(): float
    {
        $result = array_sum(array_slice($this->quantity, 1, 3));
        return (float)round($result, FS_NF0);
    }

    public function quantityQuarterSecond(): float
    {
        $result = array_sum(array_slice($this->quantity, 4, 3));
        return (float)round($result, FS_NF0);
    }

    public function quantityQuarterThird(): float
    {
        $result = array_sum(array_slice($this->quantity, 7, 3));
        return (float)round($result, FS_NF0);
    }

    public function quantityQuarterFourth(): float
    {
        $result = array_sum(array_slice($this->quantity, 10, 3));
        return (float)round($result, FS_NF0);
    }
}