<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model;

use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Template\ModelClass;

/**
 * Statistic Report data model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticReport extends ModelClass
{
    /**
     * Constants for the manage the group of the reports.
     */
    public const GROUPTYPE_CUSTOMER = 0;
    public const GROUPTYPE_AGENT = 1;
    public const GROUPTYPE_SUPPLIER = 2;
    public const GROUPTYPE_PRODUCT = 3;

    use ModelTrait;

    /**
     * Name of the xml file with the report format.
     *
     * @var string
     */
    public $format;

    /**
     * @var int
     */
    public $grouptype;

    /**
     * Primary key.
     *
     * @var int
     */
    public $id;

    /**
     * Name of the ModelReport class for load data of the report.
     *
     * @var string
     */
    public $model;

    /**
     * Description of the report type for humans.
     *
     * @var string
     */
    public $name;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->grouptype = self::GROUPTYPE_CUSTOMER;
    }

    /**
     * Returns the name of the column that is the model's primary key.
     *
     * @return string
     */
    public static function primaryColumn(): string
    {
        return 'id';
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'statistics_reports';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'EditSettings?activetab=' . $list);
    }
}
