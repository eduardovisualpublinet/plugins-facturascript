<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Model;

use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos\ModelStatistic;

/**
 * Statistic Supplier data model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticSupplier extends ModelStatistic
{
    use ModelTrait;

    public const SUPPLIER_TYPE_ALL = 0;
    public const SUPPLIER_TYPE_SUPPLIERS = 1;
    public const SUPPLIER_TYPE_CREDITORS = 2;

    /** @var int */
    public $channel;

    /** @var string */
    public $endsupplier;

    /** @var int */
    public $suppliertype;

    /** @var string */
    public $startsupplier;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->suppliertype = self::SUPPLIER_TYPE_ALL;
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'statistics_suppliers';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListStatistic?activetab=' . $list);
    }
}
