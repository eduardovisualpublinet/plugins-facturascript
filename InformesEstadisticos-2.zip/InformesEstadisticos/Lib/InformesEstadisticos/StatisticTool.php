<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos;

use Exception;

/**
 * Tools for statistics reports.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class StatisticTool
{
    protected const NAMESPACE = '\\FacturaScripts\\Dinamic\\Model\\Report\\';

    protected const DIR_MODELS = FS_FOLDER
        . DIRECTORY_SEPARATOR . 'Dinamic'
        . DIRECTORY_SEPARATOR . 'Model'
        . DIRECTORY_SEPARATOR . 'Report';

    protected const DIR_VIEWS = FS_FOLDER
    . DIRECTORY_SEPARATOR . 'Dinamic'
    . DIRECTORY_SEPARATOR . 'XMLView'
    . DIRECTORY_SEPARATOR . 'Report';

    protected const MAX_RECORDS = 20;

    /**
     * Get array with format views installed.
     *
     * @param string $term
     * @param int $count
     * @return array
     */
    public static function getFormatViews(string $term = '', int $count = self::MAX_RECORDS): array
    {
        $result = [];
        $folderSearch = self::DIR_VIEWS . DIRECTORY_SEPARATOR . self::globPattern($term) . '*.xml';
        foreach(glob($folderSearch) as $filename) {
            $value = basename($filename, '.xml');
            $result[] = [ 'key' => $value, 'value' => $value];
            if (count($result) > $count) {
                return $result;
            }
        }

        return $result;
    }

    /**
     * Get an instance of a model report.
     *
     * @param ModelStatistic $model
     * @param string $modelReportName
     * @return ?ModelReport
     */
    public static function getModelInstance(ModelStatistic $model, string $modelReportName): ?ModelReport
    {
        $modelReportName = self::NAMESPACE . $modelReportName;
        try {
            return new $modelReportName($model);
        } catch (Exception $ex) {
        }
        return null;
    }

    /**
     * Get array with model report installed.
     *
     * @param string $term
     * @param int $count
     * @return array
     */
    public static function getModels(string $term = '', int $count = self::MAX_RECORDS): array
    {
        $result = [];
        $folderSearch = self::DIR_MODELS . DIRECTORY_SEPARATOR . self::globPattern($term) . '*.php';
        foreach(glob($folderSearch) as $filename) {
            $value = basename($filename, '.php');
            $result[] = [ 'key' => $value, 'value' => $value];
            if (count($result) > $count) {
                return $result;
            }
        }

        return $result;
    }

    /**
     * Get a case-insensitive pattern for a glob instruction.
     *
     * @param string $term
     * @return string
     */
    private static function globPattern(string $term): string
    {
        $result = '';
        foreach(str_split($term) as $char) {
            $result .= '[' . strtoupper($char) . strtolower($char) . ']';
        }
        return $result;
    }
}
