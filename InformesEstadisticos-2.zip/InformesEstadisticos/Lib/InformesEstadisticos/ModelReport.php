<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos;

use DateTime;
use Exception;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\ExtendedReport\Lib\ExtendedReport\ModelReport as ExtendedModelReport;
use FacturaScripts\Plugins\InformesEstadisticos\Model\Report\Data\ComparativeData;

/**
 * Class with common parts for statistic reports models.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
abstract class ModelReport extends ExtendedModelReport
{
    /** @var ModelStatistic */
    protected $statistic;

    /**
     * Return the SQL to get the data.
     *
     * @return string
     */
    abstract protected function getSQL(): string;

    /**
     * Class constructor.
     * Need a statistic model and a statistic id from give filter and report configuration.
     *
     * @param $statisticModel
     */
    public function __construct($statisticModel)
    {
        parent::__construct();
        $this->statistic = $statisticModel;
    }

    /**
     * Load report data into array data property.
     */
    public function loadData(): void
    {
        $data = self::$dataBase->select($this->getSQL());
        foreach ($data as $row) {
            $record = new ComparativeData();
            $record->code = $row['code'];
            $record->name = $row['name'];

            // Load values for months
            for ($x = 0; $x <= 12; $x++) {
                $cur = $x === 0 ? 'current_neto' : 'current_neto' . $x;
                $prev = ($x === 0) ? 'previous_neto' : 'previous_neto' . $x;

                $decimals = Tools::settings('default', 'decimals');
                $record->current_value[$x] = round($row[$cur], $decimals);
                $record->previous_value[$x] = round($row[$prev], $decimals);
                $record->difference[$x] = round($record->current_value[$x] - $record->previous_value[$x], $decimals);
                $record->percentage[$x] = 0.00;
                $previous = $record->previous_value[$x];
                if ($previous > 0.00) {
                    $record->percentage[$x] = round($record->difference[$x] * 100.00 / $previous, $decimals);
                } else if ($record->current_value[$x] > 0.00) {
                    $record->percentage[$x] = 100.00;
                } else {
                    $record->percentage[$x] = 0.00;
                }
            }
            if (empty($this->statistic->withdata) || $record->hasData()) {
                $this->data[] = $record;
            }
        }
    }

    /**
     * Returns the ORDER BY clause for SQL to get the data.
     *
     * @return string
     */
    protected function getOrderBySQL(): string
    {
        $dir = $this->statistic->orderdesc ? ' DESC' : ' ASC';
        $limit = $this->statistic->orderlimit ? ' LIMIT ' . $this->statistic->orderlimit : '';
        return match ($this->statistic->orderfield) {
            ModelStatistic::ORDER_NAME => 'statistic.name' . $dir . $limit,
            ModelStatistic::ORDER_CURRENT => 'statistic.current_neto' . $dir . $limit,
            ModelStatistic::ORDER_PREVIOUS => 'statistic.previous_neto' . $dir . $limit,
            ModelStatistic::ORDER_DIFFERENCE => 'statistic.difference_neto' . $dir . $limit,
            default => 'statistic.code' . $dir . $limit,
        };
    }

    /**
     * Return sql for each month with the name of indicated column.
     *
     * @param string $period
     * @param string $column
     * @return string
     */
    protected function getSQLColumns(string $period, string $column): string
    {
        $result = '';
        for ($x = 1; $x <= 12; $x++) {
            if (false === empty($result)) {
                $result .= ',';
            }
            $result .= $this->getSQLColumn($period, $x, $column);
        }
        return $result;
    }

    /**
     * Return sql for a month with the name of indicated column.
     *
     * @param string $period
     * @param int $month
     * @param string $column
     * @return string
     */
    protected function getSQLColumn(string $period, int $month, string $column): string
    {
        return " SUM("
            . "CASE WHEN document.fecha BETWEEN " . $period
            . " AND EXTRACT(MONTH from document.fecha) = " . $month
            . " THEN document.neto * COALESCE(document.tasaconv, 1.00)"
            . " ELSE 0.00 "
            . "END) " . $column . $month;
    }

    /**
     * Return the where clause for SQL from statistic model.
     *
     * @return string
     * @throws Exception
     */
    protected function getWhere(): string
    {
        $curPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
        );

        $prevPeriod = $this->periodBetween(
            $this->statistic->startdate,
            $this->statistic->enddate,
            1
        );

        $result = "(document.fecha BETWEEN " . $curPeriod . " OR document.fecha BETWEEN " . $prevPeriod . ")";

        if (false === empty($this->statistic->idcompany)) {
            $result .= " AND document.idempresa = " . $this->statistic->idcompany;
        }

        if (false === empty($this->statistic->channel)) {
            $result .= " AND series.canal = " . $this->statistic->channel;
        }

        return $result;
    }

    /**
     * Return the dates for make a period between two dates.
     *  - If $back is 0, return the current period.
     *  - If $back is 1, return the previous period.
     *
     * @param string $startDate
     * @param string $endDate
     * @param int $back
     * @return string
     * @throws Exception
     */
    protected function periodBetween(string $startDate, string $endDate, int $back = 0): string
    {
        $start = new DateTime($startDate);
        $end = new DateTime($endDate);
        return "'" . $start->modify('-' . $back . ' year')->format('Y-m-d') . "'"
            . " AND "
            . "'" . $end->modify('-' . $back . ' year')->format('Y-m-d') . "'";
    }
}
