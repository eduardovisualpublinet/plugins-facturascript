<?php
/**
 * This file is part of InformesEstadísticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadísticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Empresa;
use FacturaScripts\Plugins\ExtendedReport\Lib\ExtendedReport\PDFTemplate;

/**
 * Class with common parts for statistic edit view controller.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
abstract class EditStatisticController extends EditController
{
    /**
     * Get the group type for get the format reports.
     *
     * @return int
     */
    abstract public function getGroupTypeFormat(): int;

    /**
     * Create the view to display.
     *   - Adds the list of reports of the indicated type to the format column.
     *   - The report type is obtained from the getGroupTypeFormat method.
     *
     * @return void
     */
    protected function createViews()
    {
        parent::createViews();

        // load reports formats
        $mvn = $this->getMainViewName();
        $formatColumn = $this->views[$mvn]->columnForName('format');
        if (isset($formatColumn) && $formatColumn->widget->getType() === 'select') {
            $where = [ new DataBaseWhere('grouptype', $this->getGroupTypeFormat()) ];
            $values = $this->codeModel->all('statistics_reports', 'id', 'name', false, $where);
            $formatColumn->widget->setValuesFromCodeModel($values);
        }

        if (Session::user()->admin) {
            $this->views[$mvn]->disableColumn('createuser', false);
        }
    }

    /**
     * Generate the PDF report.
     * TODO: generate XLS|CSV report.
     */
    protected function exportAction(): void
    {
        if (false === $this->views[$this->active]->settings['btnPrint']
            || false === $this->permissions->allowExport)
        {
            Tools::log()->warning('no-print-permission');
            return;
        }

        $model = $this->getModel();
        $company = new Empresa();
        if (false === empty($model->idcompany)
            && false === $company->load($model->idcompany))
        {
            Tools::log()->warning('no-company');
            return;
        }

        $statisticReport = $model->getStatisticReport();
        $pdfTemplate = new PDFTemplate($this->user, $company, ['filters' => $model]);
        if (false === $pdfTemplate->loadTemplate($statisticReport->format)) {
            return;
        }

        // create a model report
        $modelReport = StatisticTool::getModelInstance($model, $statisticReport->model);
        $modelReport->loadData();
        if (empty($modelReport->data)) {
            Tools::log()->warning('no-data');
            return;
        }

        $pdfTemplate->addDataset('main', $modelReport);
        $pdf = $pdfTemplate->render();

        // send pdf to browser
        $this->setTemplate(false);
        $this->response->headers->set('Content-type', 'application/pdf');
        $this->response->headers->set('Content-Disposition', 'inline;filename=' . $statisticReport->format . '.pdf');
        $this->response->setContent($pdf);
    }
}
