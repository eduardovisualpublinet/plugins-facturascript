<?php
/**
 * This file is part of InformesEstadisticos plugin for FacturaScripts.
 * FacturaScripts        Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * InformesEstadisticos  Copyright (C) 2023-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\InformesEstadisticos\Lib\InformesEstadisticos;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\InformesEstadisticos\Model\StatisticReport;

/**
 * Model base for statistics models.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
abstract class ModelStatistic extends ModelClass
{
    /**
     * Constants for the manage the source of the reports.
     */
    public const DOCTYPE_INVOICES = 0;
    public const DOCTYPE_DELIVERIES = 1;
    public const DOCTYPE_ORDERS = 2;
    public const DOCTYPE_ESTIMATION = 3;

    /**
     * Constants for the manage the order of the reports.
     */
    public const ORDER_CODE = 0;
    public const ORDER_NAME = 1;
    public const ORDER_CURRENT = 2;
    public const ORDER_PREVIOUS = 3;
    public const ORDER_DIFFERENCE = 4;

    /**
     * Indicates the type of source document to be used for calculate the statistics.
     *   - 0 = invoice
     *   - 1 = delivery note
     *   - 2 = order
     *   - 3 = estimation
     *
     * @var ?int
     */
    public ?int $doctype;

    /** @var ?string */
    public ?string $enddate;

    /**
     * Primary key.
     *
     * @var ?int
     */
    public ?int $id;

    /**
     * Link to Empresa Model.
     *
     * @var ?int
     */
    public ?int $idcompany;

    /**
     * Link to Report Model and Report View.
     *
     * @var ?int
     */
    public ?int $idreport;

    /** @var ?string */
    public ?string $name;

    /** @var ?string */
    public ?string $nick;

    /**
     * Indicates the order of the results.
     * If true, the results are ordered in descending order.
     *
     * @var ?bool
     */
    public ?bool $orderdesc;

    /**
     * Indicates the field to be used for ordering the results.
     *   - 0 = field code
     *   - 1 = field name or description
     *   - 2 = field with the current value
     *   - 3 = field with the previous value
     *   - 4 = field with the difference between current and previous value
     *
     * @var ?int
     */
    public ?int $orderfield;

    /**
     * Indicates the maximum number of results to be returned.
     * if 0, all results are returned.
     *
     * @var int
     */
    public ?int $orderlimit;

    /** @var string */
    public ?string $startdate;

    /** @var bool */
    public ?bool $withdata;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->doctype = self::DOCTYPE_INVOICES;
        $this->idcompany = Tools::settings('default', 'idempresa');
        $this->orderdesc = false;
        $this->orderfield = self::ORDER_CODE;
        $this->orderlimit = 0;
        $this->startdate = Date('01-01-Y');
        $this->enddate = Date('31-12-Y');
        $this->withdata = true;
    }

    /**
     * Return the statistic report assign to a statistic model.
     *
     * @return StatisticReport
     */
    public function getStatisticReport(): StatisticReport
    {
        $statisticReport = new StatisticReport();
        $statisticReport->load($this->idreport);
        return $statisticReport;
    }

    /**
     * Return the table name for the source document.
     *
     * @param bool $forCustomer
     * @return string
     */
    public function getSourceTableName(bool $forCustomer): string
    {
        $suffix = $forCustomer ? 'cli' : 'prov';
        return match ($this->doctype) {
            self::DOCTYPE_DELIVERIES => 'albaranes' . $suffix,
            self::DOCTYPE_ORDERS => 'pedidos' . $suffix,
            self::DOCTYPE_ESTIMATION => 'presupuestos' . $suffix,
            default => 'facturas' . $suffix,
        };
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new StatisticReport();
        return parent::install();
    }

    /**
     * Returns the name of the column that is the model's primary key.
     *
     * @return string
     */
    public static function primaryColumn(): string
    {
        return 'id';
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        if (empty($this->nick) && false === Session::user()->admin) {
            $this->nick = Session::user()->nick;
        }
        return parent::test();
    }
}
