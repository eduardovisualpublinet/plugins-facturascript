# BracketTheme - Tema para FacturaScripts

Tema moderno y elegante basado en el template Bracket, ajustado específicamente para FacturaScripts con colores y logos personalizados de VisualFactura.

## 🎨 Características

### Diseño moderno
- Interfaz limpia y profesional
- Colores actualizados del demo VisualFactura
- Sidebar colapsable con navegación optimizada
- Diseño responsive para móviles y tablets
- **Dropdown de usuario funcional** con menú de logout
- **Modal de recuperación de contraseña** completamente funcional

### Paleta de colores
- **Primario**: #B2A1FE (violeta/morado claro)
- **Secundario**: #B4FB64 (verde lima/amarillo)
- **Fondos claros**: #efecff, #f5f3ff, #ddd6ff
- **Oscuro**: #111736
- **Acentos**: #ed5462, #ff7e5e

### Branding personalizado
- Logo horizontal de VisualFactura (login y header)
- Favicon personalizado de VisualFactura
- Icono para iOS/iPad (apple-icon-180x180.png)
- Sin referencias visuales a FacturaScripts en el frontend

### Compatibilidad
- ✅ **Bootstrap 5** - Totalmente compatible
- ✅ **Bootstrap 4** - Compatible mediante clases legacy
- ✅ FontAwesome 6
- ✅ FacturaScripts 2025+
- ✅ Tablas de permisos con checkboxes funcionales
- ✅ Todos los módulos estándar de FacturaScripts
- ✅ Dropdowns y modales funcionando correctamente

## 📦 Instalación

1. Copiar la carpeta `BracketTheme` a `/Plugins/`
2. Acceder a **Admin > Plugins**
3. Activar el plugin **BracketTheme**
4. Hacer clic en **Reconstruir** (Deploy)
5. El tema se aplicará automáticamente

## 🔧 Características técnicas

### CSS personalizado
El plugin incluye `Assets/CSS/custom.css` con:
- Compatibilidad Bootstrap 5 para checkboxes
- Estilos mejorados para tablas de permisos
- Centrado automático de checkboxes en tablas
- Badges optimizados
- **Posicionamiento correcto del dropdown de usuario**

### JavaScript personalizado
El plugin incluye código en `Assets/JS/bracket.js` para:
- **Toggle del dropdown de usuario** sin interferir con menús del sidebar
- Compatible con el sistema de collapse original de Bracket
- No usa handlers globales que puedan causar conflictos

### Logos incluidos
- `Assets/Images/horizontal-logo.png` - Logo principal de VisualFactura
- `Assets/Images/favicon.ico` - Favicon personalizado (118KB)
- `Assets/Images/apple-icon-180x180.png` - Icono iOS (12KB)

### Sin modificar el Core
Este plugin **NO modifica** archivos del Core de FacturaScripts. Todos los estilos se aplican a través del sistema de plugins estándar.

## 📝 Changelog

Ver [CHANGELOG.md](CHANGELOG.md) para el historial completo de cambios.

## 🆕 Versión actual: 2.3

### Novedades v2.3 (2025-10-30)
- ✨ **Dropdown de usuario funcional** - Menú desplegable funcionando correctamente
- ✨ **Logos personalizados** - Reemplazados todos los logos con los de VisualFactura
- 🔧 **Bootstrap 5 completo** - Modal de login y todos los componentes actualizados
- 🐛 **Bugs corregidos** - Modal no se abría, dropdown no funcionaba
- 📦 JavaScript y CSS optimizados para evitar conflictos

## 🤝 Créditos

- Template original: [Bracket](https://github.com/themepixels/bracket-plus)
- Adaptación: FacturaScripts Community
- Colores: Demo VisualFactura

## 📄 Licencia

Este plugin hereda la licencia de FacturaScripts (LGPL-3.0).
