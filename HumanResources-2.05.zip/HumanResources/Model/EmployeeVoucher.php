<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Asiento;
use FacturaScripts\Dinamic\Model\CuentaEspecial;
use FacturaScripts\Dinamic\Model\Empresa;
use FacturaScripts\Plugins\HumanResources\Lib\Accounting\VoucherToAccounting;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\ModelExtended;

/**
 * List of Employee Voucher
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EmployeeVoucher extends ModelExtended
{
    use ModelTrait;

    /**
     * Total amount
     *
     * @var double
     */
    public $amount;

    /**
     * Statistic Channel.
     *
     * @var int
     */
    public $channel;

    /**
     * Paid Date
     *
     * @var string
     */
    public $enddate;

    /**
     * Link to Company model
     *
     * @var int
     */
    public $idcompany;

    /**
     * Link to Employee model
     *
     * @var int
     */
    public $idemployee;

    /**
     * Link to Asiento model
     *
     * @var int
     */
    public $identry;

    /**
     * Human description for voucher
     *
     * @var string
     */
    public $name;

    /**
     * Indicates if the voucher is paid
     *
     * @var bool
     */
    public $paid;

    /**
     * Creation Date
     *
     * @var string
     */
    public $startdate;

    /**
     * Pending amount
     *
     * @var double
     */
    public $pending;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->amount = 0.00;
        $this->pending = 0.00;
        $this->startdate = date(Tools::DATE_STYLE);
        $this->paid = false;
    }

    /**
     * Remove the model data from the database.
     *
     * @return bool
     */
    public function delete(): bool
    {
        $payments = $this->getPayments();
        $newTransaction = false === self::$dataBase->inTransaction() && self::$dataBase->beginTransaction();
        try {
            if (false === $this->deleteAccountingEntry()
                || false === parent::delete()
            ) {
                return false;
            }

            foreach ($payments as $row) {
                $row->setVoucherUpdate(false);
                if (false === $row->delete()) {
                    return false;
                }
            }
            if ($newTransaction) {
                self::$dataBase->commit();
            }
        } finally {
            if ($newTransaction && self::$dataBase->inTransaction()) {
                self::$dataBase->rollback();
            }
        }
        return true;
    }

    /**
     * Get Company model for employee voucher.
     *
     * @return Empresa
     */
    public function getCompany(): Empresa
    {
        $company = new Empresa();
        $company->load($this->idcompany);
        return $company;
    }

    /**
     * Get Employee model for employee voucher
     *
     * @return Employee
     */
    public function getEmployee(): Employee
    {
        $employee = new Employee();
        $employee->load($this->idemployee);
        return $employee;
    }

    /**
     * Get Payments for an Employee Voucher.
     *
     * @return EmployeeVoucherPaid[]
     */
    public function getPayments(): array
    {
        return EmployeeVoucherPaid::all(
            [ new DataBaseWhere('idvoucher', $this->id) ],
            ['id' => 'ASC']
        );
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new Employee();
        $this->addSpecialAccount(VoucherToAccounting::SPECIAL_PREPAYMENT_ACCOUNT);
        return parent::install();
    }

    /**
     * Returns the name of the column that describes the model, such as name, description...
     *
     * @return string
     */
    public function primaryDescriptionColumn(): string
    {
        return static::primaryColumn();
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'rrhh_employeesvouchers';
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'ListEmployee?activetab=' . $list);
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        if (empty($this->channel)) {
            $this->channel = null;
        }

        if (parent::test()) {
            $this->updatePending();
            $this->setPaidStatus();
            return true;
        }
        return false;
    }

    /**
     * Insert the model data in the database.
     *
     * @return bool
     */
    protected function saveInsert(): bool
    {
        $this->updateAccountingEntry();
        if (parent::saveInsert()) {
            return true;
        }
        return false;
    }

    /**
     * Updates the data of this record in the database.
     *
     * @return bool
     */
    protected function saveUpdate(): bool
    {
        if (empty($this->identry)
            || false === empty($this->getDirty())
        ) {
            if (false === $this->updateAccountingEntry()) {
                return false;
            }
        }
        return parent::saveUpdate();
    }

    /**
     * Add special account if not exists.
     *
     * @param string $code
     */
    private function addSpecialAccount(string $code): void
    {
        $special = new CuentaEspecial();
        if ($special->load($code)) {
            return;
        }

        $special->codcuentaesp = $code;
        $special->descripcion = Tools::lang()->trans($code);
        $special->save();
        Tools::log()->info('add-special-account-anpago');
    }

    /**
     * Delete accounting entry for voucher
     *
     * @return bool
     */
    private function deleteAccountingEntry(): bool
    {
        if (empty($this->identry)) {
            return true;
        }

        $entry = new Asiento();
        if ($entry->load($this->identry)) {
            $entry->editable = true;
            if (false === $entry->delete()) {
                Tools::log()->warning('accounting-entry-delete-error', ['%number%' => $entry->numero]);
                return false;
            }
        }
        return true;
    }

    /**
     * Create accounting entry for voucher
     */
    private function updateAccountingEntry(): bool
    {
        if (false === $this->deleteAccountingEntry()) {
            return false;
        }

        $tool = new VoucherToAccounting();
        $tool->generate($this);
        return false === empty($this->identry);
    }

    /**
     * Set the liquidation status
     */
    private function setPaidStatus(): void
    {
        if ($this->pending < 0.00) {
            $this->pending = 0.00;
        }

        if ($this->pending > $this->amount) {
            $this->pending = $this->amount;
        }

        $this->paid = ($this->pending == 0.00);
        if ($this->paid === false) {
            $this->enddate = null;
            return;
        }

        if (empty($this->enddate)) {
            $this->enddate = date(Tools::DATE_STYLE);
        }
    }

    /**
     * Update pending field from payment list
     */
    private function updatePending(): void
    {
        $totalPaid = 0.00;
        $where = [ new DataBaseWhere('idvoucher', $this->id) ];
        foreach (EmployeeVoucherPaid::all($where) as $row) {
            $totalPaid += $row->amount;
        }

        $this->pending = $this->amount - $totalPaid;
    }
}
