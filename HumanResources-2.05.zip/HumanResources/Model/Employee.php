<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\Base\EmailAndPhonesTrait;
use FacturaScripts\Core\Model\Base\FiscalNumberTrait;
use FacturaScripts\Core\Model\Base\GravatarTrait;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\CodeModel;
use FacturaScripts\Dinamic\Model\Contacto;
use FacturaScripts\Dinamic\Model\User;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\CreateModels;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\EmployeeTools;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\ModelExtended;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\ModelExtendedTrait;


/**
 * Class for management of Employee data.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class Employee extends ModelExtended
{
    use ModelTrait;
    use ModelExtendedTrait;
    use EmailAndPhonesTrait;
    use FiscalNumberTrait;
    use GravatarTrait;

    /**
     * Indicates the gender of employee
     */
    const GENDER_MAN = 1;
    const GENDER_WOMEN = 2;
    const GENDER_OTHER = 3;

    /**
     * Indicates the civil status of employee
     */
    const MARITAL_SINGLE = 1;
    const MARITAL_MARRIED = 2;
    const MARITAL_WIDOWER = 3;
    const MARITAL_DIVORCED = 4;

    /**
     * Employee's bank account for payment transactions
     *
     * @var string
     */
    public $bankaccountid;

    /**
     * Employee's day of birth
     *
     * @var string
     */
    public $birthday;

    /**
     * Internal identification. Used for attendances control
     *
     * @var string
     */
    public $credentialid;

    /**
     * Employee's discharge date
     *
     * @var string
     */
    public $dischargedate;

    /**
     * Employee's discharge reason/note
     *
     * @var string
     */
    public $dischargereason;

    /**
     * Employee date creation.
     * NOTE: This field is not translated for compatibility with previous versions.
     *
     * @var string
     */
    public $fechaalta;

    /**
     * Gender of the employee
     * (1: man, 2: woman, 3: other)
     *
     * @var int
     */
    public $gender;

    /**
     * Link to company model
     *
     * @var int
     */
    public $idcompany;

    /**
     * Lint to contact model.
     * Main address data.
     *
     * @var int
     */
    public $idcontact;

    /**
     * Link to department model
     *
     * @var int
     */
    public $iddepartment;

    /**
     * Identifier of public or private medical insurance
     *
     * @var string
     */
    public $insuranceid;

    /**
     * Employee's civil status
     * (1: single, 2: married, 3: widower, 4: divorced)
     *
     * @var int
     */
    public $marital;

    /**
     * Link to user model
     *
     * @var string
     */
    public $nick;

    /**
     * Employee's name.
     * NOTE: This field is not translated for compatibility with previous versions.
     *
     * @var string
     */
    public $nombre;

    /**
     * Employee's observations.
     * NOTE: This field is not translated for compatibility with previous versions.
     *
     * @var string
     */
    public $observaciones;

    /**
     * Indicates if the contact is being updated
     *
     * @var bool
     */
    private bool $updatingContact = false;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->idcompany = Tools::settings('default', 'idempresa');
        $this->fechaalta = date(Tools::DATE_STYLE);
        $this->gender = self::GENDER_MAN;
        $this->marital = self::MARITAL_SINGLE;
    }

    /**
     * Allows using this model as a source in CodeModel special model.
     *
     * @param string $query
     * @param string $fieldCode
     * @param array  $where
     * @return CodeModel[]
     */
    public function codeModelSearch(string $query, string $fieldCode = '', array $where = []): array
    {
        return EmployeeTools::codeModelSearch($query, $fieldCode, $where);
    }

    /**
     * Get the contact associated with this employee.
     *
     * @return Contacto
     */
    public function getContact(): Contacto
    {
        $contact = new Contacto();
        $contact->load($this->idcontact);
        return $contact;
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        CreateModels::createBaseModels();
        return parent::install();
    }

    /**
     * Returns the name of the column that describes the model, such as name, description...
     *
     * @return string
     */
    public function primaryDescriptionColumn(): string
    {
        return empty($this->nombre) ? $this->primaryColumn() : 'nombre';
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'rrhh_employees';
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        $this->checkNoHtmlFields();
        $maxLength = Tools::settings('rrhh', 'credentialmaxlen', 0);
        if ($maxLength > 0 && strlen($this->credentialid) > $maxLength) {
            Tools::log()->error('credentialid-exceeds-length');
            return false;
        }

        if ($this->duplicatedCredentialId()) {
            Tools::log()->warning('duplicated-credentialid');
            return false;
        }
        return parent::test();
    }

    /**
     * Discharge an employee.
     * Sets discharge date and reason, and disables the user if exists.
     *
     * @param string $date
     * @param string $description
     * @return bool
     */
    public function dischargeEmployee(string $date, string $description):bool
    {
        $this->dischargedate = $date;
        $this->dischargereason = $description;
        if (false === $this->save()) {
            return false;
        }

        $user = new User();
        if (false === $user->load($this->nick)
            || $user->admin
        ) {
            return true;
        }
        $user->enabled = false;
        $user->save();
        return true;
    }

    /**
     * Check if there is another employee with the same credential id.
     *
     * @return bool
     */
    protected function duplicatedCredentialId(): bool
    {
        if (empty($this->credentialid)) {
            return false;
        }

        $where = [ new DataBaseWhere('credentialid', $this->credentialid) ];
        if (false === empty($this->id)) {
            $where[] = new DataBaseWhere('id', $this->id, '<>');
        }
        return false === empty(Employee::all($where, [], 0, 1));
    }

    /**
     * Returns a list of fields to verify that they do not have html code
     *
     * @return array
     */
    protected function noHtmlFields(): array
    {
        return ['nombre', 'observaciones', 'bankaccountid', 'insuranceid'];
    }

    /**
     * Insert the model data in the database.
     *
     * @return bool
     */
    protected function saveInsert(): bool
    {
        if (parent::saveInsert()) {
            $this->updateContact();
            return true;
        }
        return false;
    }

    /**
     * Update the model data in the database.
     *
     * @return bool
     */
    protected function saveUpdate(): bool
    {
        if (parent::saveUpdate()) {
            $this->updateContact();
            return true;
        }
        return false;
    }

    /**
     * Synchronize contact data
     */
    private function updateContact(): void
    {
        if ($this->updatingContact) {
            return;
        }

        $contact = new Contacto();
        if (false === empty($this->idcontact)) {
            $contact->load($this->idcontact);
            $this->idcontact = $contact->idcontacto;    // Force for wrong idcontact
        }

        $contact->cifnif = $this->cifnif;
        $contact->tipoidfiscal = $this->tipoidfiscal;
        $contact->descripcion = $this->nombre;
        $contact->email = $this->email;
        $contact->idemployee = $this->id;
        $contact->nombre = $this->nombre;
        $contact->personafisica = true;
        $contact->telefono1 = $this->telefono1;
        $contact->telefono2 = $this->telefono2;
        $this->updatingContact = true;
        try {
            if ($contact->save() && empty($this->idcontact)) {
                $this->idcontact = $contact->idcontacto;
                $this->save();
            }
        } finally {
            $this->updatingContact = false;
        }
    }
}
