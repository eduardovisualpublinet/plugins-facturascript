/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
"use strict";

document.addEventListener('DOMContentLoaded', () => {
    const multireqtoken = document.getElementById('multireqtoken');
    const credential = document.getElementById('credential');
    const maxLen = credential.dataset.maxlen || 8;
    const circles = Array.from({ length: maxLen }, (_, i) => document.getElementById('digit' + (i + 1)));

    /** =========== Core Functions =========== **/
    /**
     * Update the credential input based on the provided value.
     *
     * @param value
     */
    function handleInput(value) {
        switch (value) {
            case '98': // delete
                credential.value = credential.value.slice(0, -1);
                break;
            case '99': // clear
                credential.value = '';
                break;
            default:
                if (credential.value.length < maxLen) {
                    credential.value += value;
                }
                break;
        }
        updateIndicators();
    }

    /**
     * Send the attendance data to the server.
     *
     * @param {Number} type
     */
    async function sendAttendance(type) {
        if (!credential.value) {
            return;
        }

        const location = await getGeoLocation();
        const formData = new FormData();
        formData.append('action', 'insert-attendance');
        formData.append('multireqtoken', multireqtoken.value);
        formData.append('credencial', credential.value);
        formData.append('location', location);
        formData.append('kind', type.toString());

        fetch(window.location.href, {
            method: 'POST',
            body: formData,
        }).then(function (response) {
            return response.ok ? response.json() : Promise.reject(response);
        }).then(function (result) {
            showStatus(result.error, result.message);
            multireqtoken.value = result.newtoken;
            credential.value = '';
            updateIndicators();
        }).catch(error => console.warn(error));
    }

    /**
     * Show a status message overlay.
     *
     * @param {boolean} error
     * @param {String} message
     */
    function showStatus(error, message) {
        const overlay = document.getElementById('statusMessage');
        const box = document.getElementById('statusBox');

        box.textContent = message;
        box.classList.toggle('error', error);
        overlay.classList.remove('d-none');

        setTimeout(() => {
            overlay.classList.add('d-none');
            box.classList.remove('error');
        }, 2000);
    }

    /**
     * Update the visual indicators based on the current input length.
     */
    function updateIndicators() {
        const len = credential.value.length;
        circles.forEach((el, i) => el.classList.toggle('active', i < len));

        document.querySelectorAll('[data-value]').forEach(btn => {
            const val = btn.dataset.value;
            btn.disabled = len >= maxLen && !['98', '99', 'Input', 'Output'].includes(val);
        });
    }

    /** =========== Event Handlers =========== **/
    /**
     * When a button is clicked, update the credential input accordingly.
     *
     * @param {Event} event
     */
    function onButtonClick(event) {
        const value = event.currentTarget.dataset.value;
        switch (value) {
            case 'Input':
                sendAttendance(1);
                break;

            case 'Output':
                sendAttendance(2);
                break;

            default:
                handleInput(event.currentTarget.dataset.value);
        }
    }

    /**
     * When the user types a key, update the credential input accordingly.
     *
     * @param {Event} event
     */
    function onKeyPress(event) {
        const key = event.key;
        if (/^[0-9]$/.test(key)) {      // digits 0-9
            handleInput(key);
            return;
        }

        switch (key.toLowerCase()) {
            case 'backspace':
                handleInput('98');            // delete
                break;

            case 'escape':
                handleInput('99');            // clear
                break;

            case 'e':
            case 'f1':
                sendAttendance(1);            // input
                break;

            case 's':
            case 'f4':
                sendAttendance(2);            // output
                break;
        }
    }

    /** =========== Initialization =========== **/
    /**
     * Handle special button actions.
     */
    document.querySelectorAll('[data-value]').forEach(btn =>
        btn.addEventListener('click', onButtonClick)
    );

    /**
     * Handle keypress events for input.
     */
    document.addEventListener('keydown', onKeyPress);

    updateIndicators();         // Initial update of indicators
});
