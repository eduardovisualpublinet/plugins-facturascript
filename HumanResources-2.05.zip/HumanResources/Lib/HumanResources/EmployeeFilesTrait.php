<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Lib\HumanResources;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\AssetManager;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Model\AttachedFile;
use FacturaScripts\Dinamic\Model\AttachedFileRelation;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeDocument;

/**
 * Auxiliar Method for documents of the employee.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
trait EmployeeFilesTrait
{
    abstract protected function addHtmlView(string $viewName, string $fileName, string $modelName, string $viewTitle, string $viewIcon = 'fa-brands fa-html5');

    /**
     * Exec the action for files of the employee.
     *
     * @param string $action
     * @return bool
     */
    protected function execFileAction(string $action): bool
    {
        return match ($action) {
            'add-file' => $this->addFileAction(),
            'delete-file' => $this->deleteFileAction(),
            'edit-file' => $this->editFileAction(),
            default => false,
        };
    }

    /**
     * Action for add files to the employee.
     *
     * @return bool
     */
    private function addFileAction(): bool
    {
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        }

        if ($this->multiRequestProtection->tokenExist($this->request->request->get('multireqtoken', ''))) {
            Tools::log()->warning('duplicated-request');
            return true;
        }

        $this->dataBase->beginTransaction();
        try {
            $idEmployeeDoc = $this->createEmployeeDoc();
            $this->createFilesAttached($idEmployeeDoc);
            $this->dataBase->commit();
            Tools::log()->notice('record-updated-correctly');
        } catch (Exception $ex) {
            Tools::log()->warning('fail');
            Tools::log()->error($ex->getMessage());
            $this->dataBase->rollback();
        }
        return true;
    }

    /**
     * Create the files attached to the employee document.
     *
     * @param int $idEmployeeDoc
     * @throws Exception
     */
    private function createFilesAttached(int $idEmployeeDoc): void
    {
        $uploadFiles = $this->request->files->getArray('new-files');
        foreach ($uploadFiles as $uploadFile) {
            if ($uploadFile && $uploadFile->move(Tools::folder('MyFiles'), $uploadFile->getClientOriginalName())) {
                $newFile = new AttachedFile();
                $newFile->path = $uploadFile->getClientOriginalName();
                if (false === $newFile->save()) {
                    throw new Exception();
                }
                $this->createFileRelation($idEmployeeDoc, $newFile->idfile);
            }
        }
    }

    /**
     * Create the employee document.
     *
     * @return int
     * @throws Exception
     */
    private function createEmployeeDoc(): int
    {
        $employeeDoc = new EmployeeDocument();
        $employeeDoc->idemployee = $this->request->query->get('code');
        $employeeDoc->iddoctype = $this->request->request->get('iddoctype');
        $employeeDoc->year_group = $this->request->request->get('year_group', date('Y'));
        $employeeDoc->downloadable = $this->request->request->get('downloadable', 0);
        $employeeDoc->expires = $this->request->request->get('expires');
        $employeeDoc->note = $this->request->request->get('note');
        if (false === $employeeDoc->save()) {
            throw new Exception();
        }
        return $employeeDoc->id;
    }

    /**
     * Create the relation between the employee document and the attached file.
     *
     * @param int $idEmployeeDoc
     * @param int $idfile
     * @throws Exception
     */
    private function createFileRelation(int $idEmployeeDoc, int $idfile): void
    {
        $fileRelation = new AttachedFileRelation();
        $fileRelation->idfile = $idfile;
        $fileRelation->model = 'EmployeeDocument';
        $fileRelation->modelid = $idEmployeeDoc;
        $fileRelation->nick = $this->user->nick;
        if (false === $fileRelation->save()) {
            throw new Exception();
        }
    }

    /**
     * Add the view for files of the employee.
     *
     * @param string $viewName
     */
    private function createViewEmployeeFiles(string $viewName = 'EmployeeFiles'): void
    {
        $this->addHtmlView($viewName, 'Tab/EmployeeFiles', 'Join\EmployeeDocument', 'files', 'fa-solid fa-paperclip');
        AssetManager::add('js', Tools::config('route'). '/Dinamic/Assets/JS/WidgetAutocomplete.js');
    }

    /**
     * Delete the file attached to the employee document.
     *
     * @return bool
     */
    private function deleteFileAction(): bool
    {
        if (false === $this->permissions->allowDelete) {
            Tools::log()->warning('not-allowed-delete');
            return true;
        }

        $id = $this->request->request->get('id');
        $employeeDoc = new EmployeeDocument();
        if (false === $employeeDoc->load($id)) {
            return true;
        }

        $fileRelation = $employeeDoc->getFile();
        $file = $fileRelation->getFile();
        $this->dataBase->beginTransaction();
        try {
            if ($fileRelation->delete()
                && $file->delete()
                && $employeeDoc->delete()
            ) {
                $this->dataBase->commit();
                Tools::log()->notice('record-deleted-correctly');
            }
        } catch (Exception $ex) {
            Tools::log()->error($ex->getMessage());
        } finally {
            if ($this->dataBase->inTransaction()) {
                Tools::log()->warning('fail');
                $this->dataBase->rollback();
            }
        }
        return true;
    }

    /**
     * Edit the employee document.
     *
     * @return bool
     */
    private function editFileAction(): bool
    {
        if (false === $this->permissions->allowUpdate) {
            Tools::log()->warning('not-allowed-modify');
            return true;
        }

        if ($this->multiRequestProtection->tokenExist($this->request->request->get('multireqtoken', ''))) {
            Tools::log()->warning('duplicated-request');
            return true;
        }

        $id = $this->request->request->get('id');
        $employeeDoc = new EmployeeDocument();
        if (false === $employeeDoc->load($id)) {
            return true;
        }

        $employeeDoc->iddoctype = $this->request->request->get('iddoctype');
        $employeeDoc->year_group = $this->request->request->get('year_group', date('Y'));
        $employeeDoc->downloadable = $this->request->request->get('downloadable', 0);
        $employeeDoc->expires = $this->request->request->get('expires');
        $employeeDoc->note = $this->request->request->get('note');
        if ($employeeDoc->save()) {
            Tools::log()->notice('record-updated-correctly');
        }
        return true;
    }

    /**
     * Load the data of the files of the employee.
     *
     * @param BaseView $view
     * @param int $idemployee
     */
    private function loadDataEmployeeFiles($view, int $idemployee): void
    {
        $where = [ new DataBaseWhere('doc.idemployee', $idemployee) ];
        $view->loadData('', $where, ['rel.creationdate' => 'DESC']);
    }
}
