<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Lib\HumanResources;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Dinamic\Model\EmployeeHoliday;
use FacturaScripts\Plugins\HumanResources\Lib\DateTimeTools;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeHolidayMax;

/**
 * Class for management Holidays data of the employee panel
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
final class PanelHoliday
{
    /** @var EmployeeHoliday[] */
    public array $data;

    /** @var int */
    public int $enjoyed;

    /** @var int */
    public int $total;

    /**
     * Maximum days of holidays allowed per year
     *
     * @var int
     */
    public $maxdays = 30;

    /**
     * Constructor and inicializate values
     */
    public function __construct()
    {
        $this->data = [];
        $this->enjoyed = 0;
        $this->total = 0;
        $this->maxdays = 0;
    }

    /**
     * Load holidays data structure for current year.
     *
     * @param int $idemployee
     */
    public function load(int $idemployee): void
    {
        $maxHolidays = new EmployeeHolidayMax();
        $maxHolidays->loadWhere([
            new DataBaseWhere('idemployee', $idemployee),
            new DataBaseWhere('applyto', date('Y')),
        ]);
        $this->maxdays = $maxHolidays->maxdays;

        $where = [
            new DataBaseWhere('idemployee', $idemployee),
            new DataBaseWhere('startdate', date('Y-01-01'), '>='),
        ];
        $order = [ 'startdate' => 'ASC' ];
        foreach (EmployeeHoliday::all($where, $order) as $item) {
            $item->canDelete = DateTimeTools::dateGreaterThan($item->startdate);
            $this->total += $item->totaldays;
            $this->enjoyed += $item->canDelete ? 0 : $item->totaldays;
            $this->data[] = $item;
        }
    }
}
