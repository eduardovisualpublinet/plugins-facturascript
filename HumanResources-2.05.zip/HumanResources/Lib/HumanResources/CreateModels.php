<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Lib\HumanResources;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Dinamic\Model\Department;
use FacturaScripts\Plugins\HumanResources\Model\AbsenceConcept;
use FacturaScripts\Plugins\HumanResources\Model\Attendance;
use FacturaScripts\Plugins\HumanResources\Model\AttendanceAudit;
use FacturaScripts\Plugins\HumanResources\Model\CourseArea;
use FacturaScripts\Plugins\HumanResources\Model\CourseCost;
use FacturaScripts\Plugins\HumanResources\Model\CourseMethod;
use FacturaScripts\Plugins\HumanResources\Model\CourseObjective;
use FacturaScripts\Plugins\HumanResources\Model\CourseTraining;
use FacturaScripts\Plugins\HumanResources\Model\DisciplinaryOffense;
use FacturaScripts\Plugins\HumanResources\Model\DocumentType;
use FacturaScripts\Plugins\HumanResources\Model\Employee;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeHoliday;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeHolidayMax;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeOvertimeClosing;
use FacturaScripts\Plugins\HumanResources\Model\EmployeePayRollSalary;
use FacturaScripts\Plugins\HumanResources\Model\EmployeeWorkPeriod;
use FacturaScripts\Plugins\HumanResources\Model\PayRollAccounting;
use FacturaScripts\Plugins\HumanResources\Model\PublicHoliday;
use FacturaScripts\Plugins\HumanResources\Model\Sanction;

/**
 * Create or check the existence of the models used in the plugin.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class CreateModels
{
    public static function createBaseModels(): void
    {
        new CourseArea();
        new CourseCost();
        new CourseMethod();
        new CourseObjective();
        new DisciplinaryOffense();
        new DocumentType();
        new Sanction();
        new Department();
        new CourseTraining();
        new AbsenceConcept();
        new PublicHoliday();
    }

    public static function checkModels(): void
    {
        self::createBaseModels();
        new Employee();
        new Attendance();
        new AttendanceAudit();

        // EmployeeWorkPeriod:
        //   -> EmployeeWorkShift
        new EmployeeWorkPeriod();

        // EmployeePayRollSalary:
        //   -> EmployeeSalary
        //     -> SalaryConcept
        //   -> EmployeePayRoll
        //     -> PayRoll
        new EmployeePayRollSalary();
        new PayRollAccounting();

        // EmployeeOvertimeClosing:
        //   -> OvertimeClosing
        new EmployeeOvertimeClosing();
    }

    public static function checkAuditFields(): void
    {
        $attendances =  Attendance::tableName();
        $employees = Employee::tableName();
        $sql = 'UPDATE ' . $attendances
            . ' LEFT JOIN ' . $employees . ' ON ' . $employees . '.id = ' . $attendances . '.idemployee'
            . ' SET creation_date = CONCAT(checkdate, \' \', checktime)'
            . ' , last_update = CONCAT(checkdate, \' \', checktime)'
            . ' , last_nick = ' . $employees . '.nick'
            . ' WHERE creation_date IS NULL AND checkdate > \'1990-01-01\'';

        $database = new DataBase();
        $database->connect();
        $database->exec($sql);
    }

    /**
     * Force create the new field applyto in EmployeeHoliday if not exists
     * and fill it with the year of startdate if it is null.
     *
     * @return void
     */
    public static function updateApplyToField(): void
    {
        new EmployeeHoliday();
        $sql = 'UPDATE ' . EmployeeHoliday::tableName()
            . ' SET applyto = YEAR(startdate)'
            . ' WHERE applyto IS NULL';

        $database = new DataBase();
        $database->connect();
        $database->exec($sql);

        new EmployeeHolidayMax();
        $sqlExists = 'SELECT 1 FROM ' . EmployeeHolidayMax::tableName() . ' t3'
            . ' WHERE t3.idemployee = t1.id'
            . ' AND t3.applyto = EXTRACT(YEAR FROM t2.startdate)';

        $sqlSelect = 'SELECT t1.id, EXTRACT(YEAR FROM t2.startdate) as applyto'
            . ' FROM rrhh_employees t1, rrhh_employeesholidays t2'
            . ' WHERE NOT EXISTS (' . $sqlExists . ')'
            . ' GROUP BY 1, 2';

        $sqlInsert = 'INSERT INTO ' . EmployeeHolidayMax::tableName() . ' (idemployee, applyto, maxdays)';
        foreach ($database->select($sqlSelect) as $row) {
            $database->exec(
                $sqlInsert . ' VALUES (' . $row['id'] . ', ' . $row['applyto'] . ', 30)'
            );
        }
    }
}
