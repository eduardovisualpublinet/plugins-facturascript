<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Lib\ExtendedController\DocFilesTrait;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;

/**
 * Controller to edit Contract.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditContract extends EditController
{
    use DocFilesTrait;

    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'Contract';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'contracts';
        $pageData['icon'] = 'fa-solid fa-handshake';
        $pageData['menu'] = 'rrhh';
        return $pageData;
    }

    /**
     * Create views to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewDocFiles('docfiles', 'Tab/PreviewFiles');
        $this->setTabsPosition('bottom');
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'add-file' => $this->addFileAction(),
            'delete-file' => $this->deleteFileAction(),
            'edit-file' => $this->editFileAction(),
            'unlink-file' => $this->unlinkFileAction(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Load view data procedure
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        $mainViewName = $this->getMainViewName();
        if ($viewName === $mainViewName) {
            parent::loadData($viewName, $view);
        } elseif ($viewName == 'docfiles') {
            $this->loadDataDocFiles($view, $this->getModelClassName(), $this->getModel()->id);
        }
    }
}
