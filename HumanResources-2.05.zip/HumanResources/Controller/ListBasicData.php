<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;

/**
 * Controller to agroup RRHH basic data
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ListBasicData extends ListController
{
    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'basic-data';
        $pageData['icon'] = 'fa-solid fa-cogs';
        $pageData['menu'] = 'rrhh';
        $pageData['ordernum'] = 0;
        return $pageData;
    }

    /**
     * Load views
     */
    protected function createViews()
    {
        $this->createViewAbsenceConcept();
        $this->createViewConcept();
        $this->createViewContract();
        $this->createViewDepartment();
        $this->createViewPublicHoliday();
        $this->createViewDocument();
        $this->createViewSanction();
        $this->createViewOffense();
    }

    /**
     * Add and configure absence concept view
     */
    private function createViewAbsenceConcept(): void
    {
        $this->addView('ListAbsenceConcept', 'AbsenceConcept', 'absence-concept', 'fa-solid fa-unlink')
            ->addSearchFields(['name'])
            ->addOrderBy(['name'], 'name');
    }

    /**
     * Add and configure salary concepts view
     */
    private function createViewConcept(): void
    {
        $this->addView('ListSalaryConcept', 'SalaryConcept', 'salary-concepts', 'fa-solid fa-money-bill-alt')
            ->addSearchFields(['name'])
            ->addOrderBy(['name'], 'name')
            ->addOrderBy(['codsubaccount'], 'subaccount');
    }

    /**
     * Add and configure contracts view
     */
    private function createViewContract(): void
    {
        $this->addView('ListContract', 'Contract', 'contracts', 'fa-solid fa-handshake')
            ->addSearchFields(['name', 'id'])
            ->addOrderBy(['name'], 'name');
    }

    /**
     * Add and configure department view
     */
    private function createViewDepartment(): void
    {
        $this->addView('ListDepartment', 'Department', 'departments', 'fa-solid fa-id-card')
            ->addSearchFields(['name'])
            ->addOrderBy(['name'], 'name')
            ->addOrderBy(['idcompany', 'name'], 'company');
    }

    /**
     * Add view Document Types.
     */
    private function createViewDocument():void
    {
        $this->addView('ListDocumentType', 'DocumentType', 'documents-types', 'fa-solid fa-copy')
            ->addSearchFields(['name', 'id'])
            ->addOrderBy(['name'], 'name')
            ->addOrderBy(['id'], 'code');
    }

    /**
     * Add and configure public holidays view
     */
    private function createViewPublicHoliday(): void
    {
        $this->addView('ListPublicHoliday', 'PublicHoliday', 'public-holidays', 'fa-solid fa-calendar-times')
            ->addSearchFields(['name', 'CAST(holiday AS CHAR(30))'])
            ->addOrderBy(['holiday'], 'date', 2)
            ->addOrderBy(['name'], 'desc')
            ->addFilterPeriod('holiday', 'date', 'holiday');
    }

    /**
     * Add view Disciplinary Offenses
     */
    private function createViewOffense(): void
    {
        $this->addView('ListDisciplinaryOffense', 'DisciplinaryOffense', 'disciplinary-offenses', 'fa-solid fa-people-arrows')
            ->addSearchFields(['name', 'id'])
            ->addOrderBy(['name'], 'name');
    }

    /**
     * Add view Disciplinary Sanctions
     */
    private function createViewSanction(): void
    {
        $this->addView('ListSanction', 'Sanction', 'sanctions', 'fa-solid fa-gavel')
            ->addSearchFields(['name', 'id'])
            ->addOrderBy(['name'], 'name');
    }
}
