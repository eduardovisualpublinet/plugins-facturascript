/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C) 2022-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
'use strict';

/**
 * Returns an object with the cash amounts from the settlement inputs.
 *
 * @returns {{ [key: string]: number }}
 */
function getCash() {
    const cash = {};
    const settlements = document.querySelectorAll(".settlement");
    settlements.forEach(function (el) {
        cash[el.getAttribute("name")] = parseFloat(el.value) || 0;
    });

    return cash;
}

/**
 * Returns the total group amount from the input with class 'group-total'.
 *
 * @returns {number}
 */
function getTotalGroup() {
    const total = document.querySelector(".group-total");
    return total ? parseFloat(total.value) || 0 : 0;
}

/**
 * Returns the total diets amount from the input with name 'total_diets'.
 *
 * @returns {number}
 */
function getDiets() {
    const diets = document.querySelector("input[name=total_diets]");
    return diets ? parseFloat(diets.value) || 0 : 0;
}

/**
 * Returns the total checks amount from the input with name 'bankchecks'.
 *
 * @returns {number}
 */
function getChecks() {
    const checks = document.querySelector("input[name=bankchecks]");
    return checks ? parseFloat(checks.value) || 0 : 0;
}

/**
 * Event listener for changes in settlement inputs.
 */
document.addEventListener("DOMContentLoaded", function () {
    const settlements = document.querySelectorAll(".settlement");

    settlements.forEach(function (el) {
        el.addEventListener("change", function () {
            const automatic = document.querySelector("select[name=automatic]");
            const calculate = automatic ? automatic.value : "0";

            if (calculate === "1") {
                const data = new FormData();
                data.append("action", "cash-calculate");
                data.append("cash", JSON.stringify(getCash()));
                data.append("checks", getChecks().toString());
                data.append("diets", getDiets().toString());
                data.append("total", getTotalGroup().toString());

                fetch(window.location.href, {
                    method: "POST",
                    body: data
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(response.status + " " + response.statusText);
                        }
                        return response.json();
                    })
                    .then(result => {
                        const settlementTotal = document.querySelector(".settlement-total");
                        const settlementDifference = document.querySelector(".settlement-difference");

                        if (settlementTotal) settlementTotal.value = result.total;
                        if (settlementDifference) settlementDifference.value = result.difference;
                    })
                    .catch(error => {
                        console.error("cash-calculate error:", error.message);
                    });
            }
        });
    });
});
