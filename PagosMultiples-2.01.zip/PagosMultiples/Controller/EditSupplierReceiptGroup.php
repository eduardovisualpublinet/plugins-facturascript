<?php
/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\PagosMultiples\Controller;

use Exception;
use FacturaScripts\Core\Lib\ExtendedController\ListView;
use FacturaScripts\Plugins\PagosMultiples\Lib\PagosMultiples\EditPaymentReceiptGroup;

/**
 * Controller to list the items in the SupplierReceiptGroup model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditSupplierReceiptGroup extends EditPaymentReceiptGroup
{
    protected const VIEW_ADD = 'ListReciboProveedor-add';
    protected const VIEW_LIST = 'ListReciboProveedor';
    protected const VIEW_NOTE = 'EditCustomerReceiptGroupNote';

    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'SupplierReceiptGroup';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'multiple-payment';
        $pageData['icon'] = 'fa-solid fa-coins';
        $pageData['menu'] = 'purchases';
        return $pageData;
    }

    /**
     * Create the view to display.
     *
     * Disable company column from main view, if there is only one company.
     * Set tabs to bottom position.
     *
     * @throws Exception
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewAccounting();
    }

    /**
     * Add receipts pending list.
     *
     * @return ListView
     * @throws Exception
     */
    protected function createViewReceiptsAdd(): ListView
    {
        return parent::createViewReceiptsAdd()
            ->addOrderBy(['recibos.codproveedor'], 'supplier')
            ->addFilterAutocomplete('codproveedor', 'supplier', 'recibos.codproveedor', 'proveedores', 'codproveedor', 'razonsocial');
    }
}
