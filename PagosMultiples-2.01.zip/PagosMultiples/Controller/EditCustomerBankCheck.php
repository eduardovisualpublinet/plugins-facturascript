<?php
/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 * FacturaScripts  Copyright (C) 2015-2025 Carlos Garcia Gómez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C)  2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\PagosMultiples\Controller;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Model\CustomerBankCheck;
use FacturaScripts\Plugins\PagosMultiples\Lib\Accounting\BankCheckToAccounting;

/**
 * Controller to edit the items in the CustomerBankCheck model
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class EditCustomerBankCheck extends EditController
{
    protected const VIEW_ACCOUNTING = 'ListAccountingDetail';

    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'CustomerBankCheck';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'bank-check';
        $pageData['icon'] = 'fa-solid fa-money-check';
        $pageData['menu'] = 'sales';
        return $pageData;
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action) {
        switch ($action) {
            case 'charged-bankcheck':
                $this->chargedBankCheckAction();
                return true;

            case 'refound-bankcheck':
                $this->refundBankCheckAction();
                return true;

            default:
                return parent::execPreviousAction($action);
        }
    }

    /**
     * Loads the data to display.
     *
     * @param string $viewName
     * @param BaseView $view
     * @throws Exception
     */
    protected function loadData($viewName, $view) {
        $mainViewName = $this->getMainViewName();
        if ($viewName === $mainViewName) {
            parent::loadData($viewName, $view);
            $this->addAccountingActions();
            return;
        }

        if ($viewName == static::VIEW_ACCOUNTING) {
            $this->loadDataAccounting($this->getModel()->identry, $viewName);
        }
    }

    /**
     * Create the view to display.
     * Disable company column from main view, if there is only one company.
     * Set tabs to bottom position.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewAccounting();
        $this->setTabsPosition('bottom');
    }

    /**
     * Add accounting entry view.
     * Load view data.
     */
    protected function createViewAccounting(): void
    {
        $this->addListView(static::VIEW_ACCOUNTING, 'Join\AccountingDetail', 'accounting-entry', 'fa-solid fa-balance-scale')
            ->setSettings('btnDelete', false)
            ->setSettings('btnNew', false);
    }

    /**
     * Create accounting entry.
     *
     * @param ?CustomerBankCheck $bankCheck
     * @param bool $refund
     */
    private function accountingBankCheck(?CustomerBankCheck $bankCheck, bool $refund): void
    {
        $accounting = new BankCheckToAccounting();
        if (false === $accounting->generateAccounting($bankCheck, $refund)) {
            Tools::log()->warning('accounting-entry-error');
            return;
        }

        Tools::log()->notice('record-updated-correctly');
    }

    /**
     * Add Accounting button depending on the status of the bank check.
     *
     * @throws Exception
     */
    private function addAccountingActions(): void
    {
        $mainViewName = $this->getMainViewName();
        $model = $this->views[$mainViewName]->model;
        if (empty($model->idbank) || empty($model->codsubaccount)) {
            return;
        }

        switch ($model->status) {
            case CustomerBankCheck::STATUS_CHARGED:
                $this->addButton($mainViewName, [
                    'action' => 'refound-bankcheck',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-undo',
                    'label' => 'refund',
                    'confirm' => 'true',
                ]);
                break;

            default:
                $this->addButton($mainViewName, [
                    'type' => 'modal',
                    'action' => 'charged-bankcheck',
                    'label' => 'charge',
                    'color' => 'info',
                    'icon' => 'fa-solid fa-check-square',
                ]);
                // set values to modal form
                $model->charged_bank = $model->idbank;
                $model->charged_date = date(Tools::DATE_STYLE);
                break;
        }
    }

    /**
     * Make the accounting entry of the collection.
     */
    private function chargedBankCheckAction(): void
    {
        $bankCheck = null;
        if (false === $this->loadBankCheck($bankCheck)) {
            return;
        }

        if (false === empty($bankCheck->identry)) {
            return;
        }

        $data = $this->request->request->all();
        $bankCheck->charged = $data['charged_date'];
        $bankCheck->idbank = $data['charged_bank'];
        $this->accountingBankCheck($bankCheck, false);
    }

    /**
     * Load customer bank check from request code.
     *
     * @param ?CustomerBankCheck $bankCheck
     * @return bool
     */
    private function loadBankCheck(?CustomerBankCheck &$bankCheck): bool
    {
        $id = $this->request->query->get('code');
        if (empty($id)) {
            return false;
        }

        $bankCheck = new CustomerBankCheck();
        return $bankCheck->load($id);
    }

    /**
     * Load data for accounting tab.
     *
     * @param int $identry
     * @param string $viewName
     */
    private function loadDataAccounting($identry, string $viewName): void
    {
        if (empty($identry)) {
            $this->setSettings($viewName, 'active', false);
            return;
        }

        $where = [new DataBaseWhere('partidas.idasiento', $identry)];
        $this->views[$viewName]->loadData('', $where, ['idpartida' => 'ASC']);
    }

    /**
     * Make the accounting entry of the refund of the collection.
     */
    private function refundBankCheckAction(): void
    {
        $bankCheck = null;
        if (false === $this->loadBankCheck($bankCheck)) {
            return;
        }

         if (empty($bankCheck->identry)) {
            return;
        }

        $bankCheck->charged = date(Tools::DATE_STYLE);
        $this->accountingBankCheck($bankCheck, true);
   }
}
