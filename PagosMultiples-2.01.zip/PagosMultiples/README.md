# FacturaScripts
Software de código abierto de facturación y contabilidad para pequeñas y medianas empresas.
Software ERP de código abierto. Construido sobre PHP, utilizando de componentes Symfony y Bootstrap 4.
Fácil y potente.

# PagosMultiples
Plugin de pagos/cobros multiples de recibos que permite realizar cobros y pagos
de agrupaciones de recibos, de un mismo o varios clientes/proveedores, agrupando
el proceso en un único asiento contable. El sistema permite seleccionar la cuenta
bancaria destino, así como gestionar el cobro en forma de talones bancarios.

Los talones bancarios pueden darse por cobrados o incluir la fecha de vencimiento,
llevando el saldo a las cuentas contables para cartera de efectos pendientes de cobro.
En una nueva opción se muestra el listado de talones junto con su estado, donde
poder controlar los talones que han de ser llevados al cobro. Llegado el momento
podemos generar el asiento del ingreso de manera sencilla, mediante un botón.

También es posible asignar un agente a la agrupación de recibos de clientes de
modo que podamos realizar una liquidación de cobro, de forma similar a un arqueo,
donde indicamos el efectivo entregado por el agente y contibilizando las posibles
diferencias. La liquidación se puede asignar a una cuenta contable de cartera
de efectos. Esto es efectivo cuando los cobros son realizados por agentes
remotos (que operan fuera de la localidad donde se ubica la central administrativa).

<strong>ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU LIBRE DISTRIBUCIÓN.</strong>


## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PagosMultiples**.


## Más información
<ul>
    <li>General info: https://www.facturascripts.com</li>
    <li>Plugin info:  https://www.facturascripts.com/plugins/pagosmultiples</li>
</ul>


## Documentación / Issues / Feedback
https://www.facturascripts.com


## Enlaces de interés
- [Cómo instalar plugins en FacturaScripts](https://facturascripts.com/publicaciones/como-instalar-un-plugin-en-facturascripts)
- [Curso de FacturaScripts](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Cómo instalar FacturaScripts en Windows](https://facturascripts.com/instalar-windows)
