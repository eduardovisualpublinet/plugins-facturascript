<?php
/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C) 2022-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\PagosMultiples\Extension\Controller;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Empresa;

/**
 *  Controller to list the items in the List Invoice controller
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * @property Empresa $empresa
 * @property array $views
 * @method addView(string $viewName, string $model, string $title, string $icon)
 */
class ListFacturaCliente
{
    /**
     * Load views
     */
    public function createViews(): Closure
    {
        return function (): void {
            $this->createViewReceiptGroup();
            $this->createViewBankCheck();
        };
    }

    /**
     * Add and configure Bank Check list view
     */
    public function createViewBankCheck(): Closure
    {
        return function ($viewName = 'ListCustomerBankCheck'): void {
            $this->addView($viewName, 'CustomerBankCheck', 'bank-checks', 'fa-solid fa-money-check')
                ->addFilterAutocomplete('idcustomer', 'customer', 'idcustomer', 'clientes', 'codcliente', 'nombre')
                ->addFilterPeriod('expiration', 'expiration', 'expiration');
        };
    }
    /**
     * Add and configure Receipt Group list view
     */
    public function createViewReceiptGroup(): Closure
    {
        return function($viewName = 'ListCustomerReceiptGroup'): void {
            $this->addView($viewName, 'CustomerReceiptGroup', 'multiple-charges', 'fa-solid fa-coins')
                // Search and Order
                ->addSearchFields(['id', 'concept', 'groupdate', 'total', 'notes'])
                ->addOrderBy(['groupdate'], 'date', 2)
                ->addOrderBy(['total'], 'total')
                ->addOrderBy(['idserie', 'groupdate'], 'serie')
                ->addOrderBy(['id'], 'code')
                // Filters
                ->addFilterAutocomplete('idagent', 'agent', 'idagent', 'agentes', 'codagente', 'nombre')
                ->addFilterAutocomplete('idserie', 'serie', 'idserie', 'series', 'codserie', 'descripcion')
                ->addFilterAutocomplete('idbank', 'bank-account', 'idbank', 'cuentasbanco', 'codcuenta', 'descripcion')
                ->addFilterPeriod('groupdate', 'date', 'groupdate')
                ->addFilterSelectWhere('status', [
                    ['label' => Tools::lang()->trans('all'), 'where' => []],
                    ['label' => Tools::lang()->trans('pending'), 'where' => [new DataBaseWhere('status', 0)]],
                    ['label' => Tools::lang()->trans('approved'), 'where' => [new DataBaseWhere('status', 1)]],
                ]);

            if ($this->empresa->count() < 2) {
                $this->views[$viewName]->disableColumn('company');
            }
        };
    }
}
