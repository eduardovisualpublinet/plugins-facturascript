<?php
/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 *  FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\PagosMultiples\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\CustomerReceiptGroup;

/**
 * Class that manages the data model of the agent settlement.
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class AgentSettlement extends ModelClass
{
    use ModelTrait;

    /**
     * Indicates if the breakdown of the total is entered
     * and should be calculated automatically.
     *
     * @var boolean
     */
    public $automatic;

    /**
     * Indicates if settlement is accepted.
     *
     * @var boolean
     */
    public $accept;

    /**
     * Acumulate import of bank checks.
     *
     * @var double
     */
    public $bankchecks;

    /**
     * Number of 500 bills delivered by the agent.
     *
      * @var int
     */
    public $bills500;

    /**
     * Number of 200 bills delivered by the agent.
     *
      * @var int
     */
    public $bills200;

    /**
     * Number of 100 bills delivered by the agent.
     *
      * @var int
     */
    public $bills100;

    /**
     * Number of 50 bills delivered by the agent.
     *
      * @var int
     */
    public $bills50;

    /**
     * Number of 20 bills delivered by the agent.
     *
      * @var int
     */
    public $bills20;

    /**
     * Number of 10 bills delivered by the agent.
     *
      * @var int
     */
    public $bills10;

    /**
     * Number of 5 bills delivered by the agent.
     *
      * @var int
     */
    public $bills5;

    /**
     * Number of 2 coins delivered by the agent.
     *
      * @var int
     */
    public $coins2;

    /**
     * Number of 1 coins delivered by the agent.
     *
      * @var int
     */
    public $coins1;

    /**
     * Number of 0.50 coins delivered by the agent.
     *
      * @var int
     */
    public $coins050;

    /**
     * Number of 0.20 coins delivered by the agent.
     *
      * @var int
     */
    public $coins020;

    /**
     * Number of 0.10 coins delivered by the agent.
     *
      * @var int
     */
    public $coins010;

    /**
     * Number of 0.05 coins delivered by the agent.
     *
      * @var int
     */
    public $coins005;

    /**
     * Number of 0.02 coins delivered by the agent.
     *
      * @var int
     */
    public $coins002;

    /**
     * Number of 0.01 coins delivered by the agent.
     *
      * @var int
     */
    public $coins001;

    /**
     * Difference between receipts collected and settlement.
     *
     * @var double
     */
    public $difference;

    /**
     * Primary Key of the model.
     * Link to customer receipts group model.
     *
      * @var int
     */
    public $id;

    /**
     * Total amount delivered by the agent.
     *
     * @var double
     */
    public $total;

    /**
     * Amount used in diets by the agent.
     *
     * @var double
     */
    public $total_diets;

    /**
     *
     * @return float
     */
    public function calculateSettlement(): float
    {
        $decimals = Tools::settings('default', 'decimals', 2);
        $result = $this->bills500 * 500;
        $result += $this->bills200 * 200;
        $result += $this->bills100 * 100;
        $result += $this->bills50 * 50;
        $result += $this->bills20 * 20;
        $result += $this->bills10 * 10;
        $result += $this->bills5 * 5;
        $result += $this->coins2 * 2;
        $result += $this->coins1;
        $result += $this->coins050 * 0.50;
        $result += $this->coins020 * 0.20;
        $result += $this->coins010 * 0.10;
        $result += $this->coins005 * 0.05;
        $result += $this->coins002 * 0.01;
        $result += $this->coins001 * 0.01;
        return round($result, $decimals);
    }

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->automatic = true;
        $this->accept = false;
        $this->idpayment = Tools::settings('default', 'codpago');
        $this->total = 0.00;
        $this->total_diets = 0.00;
        $this->difference = 0.00;
        $this->bankchecks = 0.00;
    }

    /**
     * Gets the customer group associated with the settlement.
     *
     * @return CustomerReceiptGroup
     */
    public function getCustomerReceiptGroup()
    {
        $group = new CustomerReceiptGroup();
        $group->load($this->id);
        return $group;
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new CustomerReceiptGroup();
        return parent::install();
    }

    /**
     * Returns the name of the column that is the model's primary key.
     *
     * @return string
     */
    public static function primaryColumn(): string
    {
        return 'id';
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'ppmm_agent_settlement';
    }

    /**
     * Loads the model data from the database using the value of the primary key.
     * If the record is not found, it initializes the model with default values
     * and assigns the value of the primary key to the corresponding property.
     *
     * @param $code
     * @return bool
     */
    public function load($code): bool
    {
        if (false === parent::load($code)) {
            $this->id = $code;
            return false;
        }
        return true;
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        $this->calculate();
        return parent::test();
    }

    /**
     * Calculate total and difference, if its automatic.
     */
    private function calculate(): void
    {
        if (false === $this->automatic) {
            return;
        }
        $group = $this->getCustomerReceiptGroup();
        $this->total = $this->calculateSettlement();
        $this->bankchecks = $this->calculateBankChecks($group);
        $this->difference = ($this->total > 0) ? $this->calculateDifference($group) : 0.00;
    }

    /**
     * Calculate total of bank checks in the customer receipt group.
     *
     * @param CustomerReceiptGroup $group
     * @return float
     */
    private function calculateBankChecks(CustomerReceiptGroup $group): float
    {
        $total = 0.00;
        foreach ($group->getBankChecks() as $bankcheck) {
            $total += $bankcheck->total;
        }
        $decimals = Tools::settings('default', 'decimals', 2);
        return round($total, $decimals);
    }

    /**
     * Calculate the difference between the total collected and the settlement.
     *
     * @param CustomerReceiptGroup $group
     * @return float
     */
    private function calculateDifference(CustomerReceiptGroup $group): float
    {
        $decimals = Tools::settings('default', 'decimals', 2);
        return round(($this->total + $this->total_diets + $this->bankchecks) - $group->total, $decimals);
    }
}
