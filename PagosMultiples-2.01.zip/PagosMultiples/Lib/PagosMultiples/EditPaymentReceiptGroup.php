<?php
/**
 * This file is part of PagosMultiples plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * PagosMultiples Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\PagosMultiples\Lib\PagosMultiples;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Lib\ExtendedController\EditView;
use FacturaScripts\Core\Lib\ExtendedController\ListView;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Model\CodeModel;
use FacturaScripts\Plugins\PagosMultiples\Model\Base\PaymentReceiptGroup;

/**
 * Edit Controller class base for multiple payment of receipts.
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
abstract class EditPaymentReceiptGroup extends EditController
{
    protected const VIEW_ACCOUNTING = 'ListAccountingDetail';

    // defined in child class
    protected const VIEW_ADD = '';
    protected const VIEW_LIST = '';
    protected const VIEW_NOTE = '';

    /**
     * Create the view to display.
     * Disable company column from main view, if there is only one company.
     * Set tabs to bottom position.
     *
     * @throws Exception
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewReceipts();
        $this->createViewReceiptsAdd();
        $this->createViewNotes();
        $this->setTabsPosition('bottom');

        if ($this->empresa->count() < 2) {
            $this->views[$this->getMainViewName()]->disableColumn('company');
        }
    }

    /**
     * Add accounting entry view.
     * Load view data.
     *
     * @return ListView
     * @throws Exception
     */
    protected function createViewAccounting(): ListView
    {
        return $this->addListView(static::VIEW_ACCOUNTING, 'Join\AccountingDetail', 'accounting-entry', 'fa-solid fa-balance-scale')
            ->setSettings('btnDelete', false)
            ->setSettings('btnNew', false);
    }

    /**
     * Add notes view.
     *
     * @return EditView
     */
    protected function createViewNotes(): EditView
    {
        return $this->addEditView(static::VIEW_NOTE, $this->getModelClassName(), 'observations', 'fa-solid fa-sticky-note')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add receipts selected list.
     *
     * @return ListView
     * @throws Exception
     */
    protected function createViewReceipts(): ListView
    {
        return $this->createViewReceiptsAddView(static::VIEW_LIST, 'receipts', 'fa-solid fa-file-invoice-dollar')
            ->setSettings('btnPrint', true)
            ->addSearchFields(['codigofactura', 'observaciones'])
            ->addOrderBy(['codigofactura'], 'code')
            ->addOrderBy(['vencimiento'], 'expiration')
            ->addOrderBy(['fecha'], 'date');
    }

    /**
     * Add receipts pending list.
     *
     * @return ListView
     * @throws Exception
     */
    protected function createViewReceiptsAdd(): ListView
    {
        $view = $this->createViewReceiptsAddView(static::VIEW_ADD, 'add', 'fa-solid fa-folder-plus')
            // Search and order
            ->addSearchFields(['facturas.codigo', 'facturas.observaciones', 'subject.nombre', 'subject.razonsocial'])
            ->addOrderBy(['recibos.fecha'], 'date', 2)
            ->addOrderBy(['recibos.importe'], 'amount')
            ->addOrderBy(['recibos.vencimiento'], 'expiration')
            // Filters
            ->addFilterPeriod('vencimiento', 'expiration', 'recibos.vencimiento')
            ->addFilterNumber('total', 'amount', 'recibos.importe')
            ->addFilterNumber('total2', 'amount', 'recibos.importe', '<=')
            ->addFilterSelect('codpago', 'payment-method', 'recibos.codpago',
                CodeModel::all('formaspago', 'codpago', 'descripcion'));

        $this->addButton(static::VIEW_ADD, [
            'action' => 'add-receipts',
            'color' => 'success',
            'icon' => 'fa-solid fa-folder-plus',
            'label' => 'add'
        ]);

        return $view;
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        switch ($action) {
            case 'add-receipts':
            case 'charged-receipts':
            case 'remove-receipts':
            case 'reopen-receipts':
                $id = $this->request->query->get('code');
                if (empty($id)) {
                    return true;
                }
                $data = $this->request->request->all();
                $data['nick'] = $this->user->nick;
                $paymentActions = new PaymentReceiptGroupActions($this->getModelClassName(), $id, $data);
                $paymentActions->exec($action);
                return true;

            default:
                return parent::execPreviousAction($action);
        }
    }

    /**
     * Load view data procedure
     *
     * @param string $viewName
     * @param BaseView $view
     * @throws Exception
     */
    protected function loadData($viewName, $view)
    {
        $mainViewName = $this->getMainViewName();
        if ($viewName === $mainViewName) {
            parent::loadData($viewName, $view);
            if ($view->count > 0) {
                $this->addActionButton();
            }
            return;
        }

        $mainModel = $this->getModel();
        switch ($viewName) {
            case static::VIEW_ACCOUNTING:
                $this->loadDataAccounting($mainModel->identry, $viewName);
                break;

            case static::VIEW_NOTE:
                $view->loadData($mainModel->id);
                $view->count = empty($view->model->notes) ? -1 : 1;
                break;

            case static::VIEW_LIST:
                $view->loadData('', [new DataBaseWhere('idmultiple', $mainModel->id)]);
                break;

            case static::VIEW_ADD:
                $this->loadDataReceiptAdd(
                    $mainModel->status,
                    $mainModel->idcompany,
                    $mainModel->idcurrency,
                    $mainModel->idserie ?? '',
                    $viewName
                );
                break;
        }
    }

    /**
     * Add action button depending on the state of the grouping.
     *
     * @throws Exception
     */
    private function addActionButton(): void
    {
        $mainViewName = $this->getMainViewName();
        $status = $this->getModel()->status;
        switch ($status) {
            case PaymentReceiptGroup::STATUS_PENDING:
                $this->addButton($mainViewName, [
                    'action' => 'charged-receipts',
                    'color' => 'info',
                    'icon' => 'fa-solid fa-check-square',
                    'label' => 'approve',
                    'confirm' => 'true',
                ]);

                $this->addButton(static::VIEW_LIST, [
                    'action' => 'remove-receipts',
                    'color' => 'danger',
                    'icon' => 'fa-solid fa-folder-minus',
                    'label' => 'remove-from-list'
                ]);
                break;

            case PaymentReceiptGroup::STATUS_CHARGED:
                $this->addButton($mainViewName, [
                    'action' => 'reopen-receipts',
                    'color' => 'warning',
                    'icon' => 'fa-solid fa-undo',
                    'label' => 're-open',
                    'confirm' => 'true',
                ]);
                break;
        }
    }

    /**
     * Create receipts view (list or add).
     *
     * @param string $viewName
     * @param string $title
     * @param string $icon
     * @return ListView
     */
    private function createViewReceiptsAddView(string $viewName, string $title, string $icon): ListView
    {
        $modelClass =  $viewName === static::VIEW_ADD
            ? 'Join\\'. $this->getModel()->getReceipt()->modelClassName() . 'Add'
            : $this->getModel()->getReceipt()->modelClassName();

        return $this->addListView($viewName, $modelClass, $title, $icon)
            ->setSettings('btnDelete', false)
            ->setSettings('btnNew', false);
    }

    /**
     * Load data for accounting tab.
     *
     * @param ?int $identry
     * @param string $viewName
     */
    private function loadDataAccounting(?int $identry, string $viewName): void
    {
        if (empty($identry)) {
            $this->setSettings($viewName, 'active', false);
            return;
        }

        $where = [new DataBaseWhere('partidas.idasiento', $identry)];
        $this->views[$viewName]->loadData('', $where, ['idpartida' => 'ASC']);
    }

    /**
     * Load data for receipts to add tab.
     * Disable tab if the grouping is not pending.
     *
     * @param int $status
     * @param int $idcompany
     * @param string $idcurrency
     * @param string $idserie
     * @param string $viewName
     */
    private function loadDataReceiptAdd(int $status, int $idcompany, string $idcurrency, string $idserie, string $viewName): void
    {
        if ($status != PaymentReceiptGroup::STATUS_PENDING) {
            $this->setSettings($viewName, 'active', false);
            return;
        }

        $where = [
            new DataBaseWhere('recibos.idmultiple', null, 'IS'),
            new DataBaseWhere('recibos.pagado', false),
            new DataBaseWhere('recibos.coddivisa', $idcurrency),
            new DataBaseWhere('recibos.idempresa', $idcompany),
        ];

        if (false === empty($idserie)) {
            $where[] = new DataBaseWhere('facturas.codserie', $idserie);
        }
        $this->views[$viewName]->loadData('', $where);
    }
}
