<?php
namespace FacturaScripts\Plugins\RegistroHorario\Extension\Model;

use Closure;
use DateTime;
use FacturaScripts\Dinamic\Model\LogMessage;

class Fichajes
{
    public function saveBefore(): Closure
    {
        return function () {
            if ($this->entrada && $this->salida && $this->fecha) {
                // Asegurar formato H:i:s
                if (preg_match('/^\d{2}:\d{2}$/', $this->entrada)) {
                    $this->entrada .= ':00';
                }
                if (preg_match('/^\d{2}:\d{2}$/', $this->salida)) {
                    $this->salida .= ':00';
                }

                // Crear DateTime con fecha y hora
                $fechaEntrada = DateTime::createFromFormat('Y-m-d H:i:s', $this->fecha . ' ' . $this->entrada);
                $fechaSalida  = DateTime::createFromFormat('Y-m-d H:i:s', $this->fecha . ' ' . $this->salida);

                // Si la salida es antes que la entrada, asumimos que es al día siguiente
                if ($fechaEntrada && $fechaSalida && $fechaSalida < $fechaEntrada) {
                    $fechaSalida->modify('+1 day');
                }

                if ($fechaEntrada && $fechaSalida) {
                    $segundos = $fechaSalida->getTimestamp() - $fechaEntrada->getTimestamp();
                    $horas = round($segundos / 3600, 2);
                    // Si pasó más de 24h, fuerza a 0 (evita fichajes absurdos)
                    $this->horas = ($segundos > 86400) ? 0 : $horas;
                } else {
                    $this->horas = 0;
                }
            }

            // Captura IP, navegador y URL actual
            $ipAddress = $_SERVER['REMOTE_ADDR']     ?? '';
            $browser   = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $uri       = $_SERVER['REQUEST_URI']     ?? '/';

            // Fecha/hora última actividad (SIN constante inexistente)
            $this->lastactivity = (new DateTime('now'))->format('Y-m-d H:i:s');
            $this->lastip       = $ipAddress;
            $this->lastbrowser  = $browser;

            // Guardamos el log
            $tipo = $this->tipo ?? 'Fichaje';
            $nick = $this->nick ?? '';
            $logMessage = $tipo . " en Registro horario guardado por el usuario $nick.\n";

            $log = new LogMessage();
            $log->channel = 'audit';
            $log->level   = 'info';
            $log->message = $logMessage;
            $log->nick    = $nick;
            $log->uri     = $uri;
            $log->model   = 'RegistroHorario';
            $log->context = json_encode($this);
            $log->ip      = $this->lastip;
            $log->save();

            return true;
        };
    }
}
