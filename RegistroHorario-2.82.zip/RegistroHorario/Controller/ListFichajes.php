<?php
namespace FacturaScripts\Plugins\RegistroHorario\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Plugins\RegistroHorario\Model\Fichajes;

class ListFichajes extends ListController
{
    public function getPageData(): array
    {
        $pageData = parent::getPageData();

        // ✅ QUIERES ESTO ARRIBA EN EL MENÚ SIEMPRE:
        $pageData['menu']  = 'Registro Horario';
        $pageData['title'] = 'Jornada laboral';
        $pageData['icon']  = 'fa-solid fa-calendar-alt';

        // (Opcional) algunos themes usan 'h1' si existe; no afecta al chip.
        $nick = $this->user->nick ?? '';
        if ($nick === '') {
            $nick = (string) ($this->request->cookies->get('fsNick') ?? '');
        }
        $pageData['h1'] = $nick !== '' ? ('Jornada de ' . $nick) : 'Jornada laboral';

        return $pageData;
    }

    protected function createViews(string $viewName = 'ListFichajes')
    {
        $this->addView($viewName, 'Join\Fichajes');
        $this->addOrderBy($viewName, ['fecha', 'entrada'], 'Fecha', 2);
        $this->addFilterPeriod($viewName, 'fecha', 'Fecha', 'fecha');

        if ($this->permissions->onlyOwnerData !== true) {
            $users = $this->codeModel->all('users', 'nick', 'nick');
            $this->addFilterSelect($viewName, 'nick', 'user', 'nick', $users);
        }

        $this->addButton('ListFichajes', [
            'action' => 'entrada',
            'icon'   => 'fa-solid fa-user-clock',
            'label'  => 'ENTRAR',
            'color'  => 'success',
            'type'   => ''
        ]);

        $this->addButton('ListFichajes', [
            'action' => 'salida',
            'icon'   => 'fa-solid fa-sign-out-alt',
            'label'  => 'SALIDA',
            'color'  => 'warning',
            'type'   => ''
        ]);

        $this->disableButtons($viewName);
    }

    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'ListFichajes':
                // ✅ Título dinámico para la lista (y en muchos themes también el H1)
                $nick = $this->user->nick ?? '';
                $dynamicTitle = $nick !== '' ? ('Jornada de ' . $nick) : 'Jornada laboral';

                if (method_exists($view, 'setTitle')) {
                    $view->setTitle($dynamicTitle);
                } elseif (property_exists($view, 'title')) {
                    $view->title = $dynamicTitle;
                }

                if ($this->permissions->onlyOwnerData === true) {
                    $where = [new DataBaseWhere('nick', $this->user->nick, '=')];
                    $view->loadData('', $where);
                } else {
                    $where = [new DataBaseWhere('fecha', null, 'IS NOT')];
                    $view->loadData('', $where);
                }
                break;
        }
    }

    private function disableButtons(string $viewName)
    {
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
        $this->setSettings($viewName, 'checkBoxes', false);
        $this->setSettings($viewName, 'megasearch', false);
        $this->setSettings($viewName, 'active', false);
        if ($this->permissions->allowExport === false) {
            $this->setSettings($viewName, 'btnPrint', false);
        }
    }

    protected function execPreviousAction($action)
    {
        $Fecha = date('d/m/Y');
        $Hora  = date('H:i');

        if ($action === 'entrada') {
            $fichajeData = $this->getFichaje();
            if (!empty($fichajeData) && $fichajeData[0]['idfichajes'] > 0) {
                Tools::log()->warning(
                    'Ya tienes una entrada registrada a las ' . $fichajeData[0]['entrada'] .
                    '.<br> Esta acción no se ha guardado. Realiza primero la Salida para poder informar de la Entrada.'
                );
                return true;
            } else {
                $fichaje = new Fichajes();
                $fichaje->fecha     = date('Y-m-d');
                $fichaje->usuario   = $this->user->nick;
                $fichaje->entrada   = date('H:i');
                $fichaje->nick      = $this->user->nick;
                $fichaje->codagente = $this->user->codagente;
                $fichaje->tipo      = 'Registro Entrada';

                $coordenadas = $this->request->cookies->get('coordenadas');
                $fichaje->coordenadas_entrada = $coordenadas ?: 'No disponibles';

                if (false === $fichaje->save()) {
                    Tools::log()->notice('Error al guardar');
                    return false;
                }

                Tools::log()->notice('Entrada el ' . $Fecha . ' a las ' . $Hora);
                return true;
            }
        } elseif ($action === 'salida') {
            $fichajeData = $this->getFichaje();
            if (!empty($fichajeData) && $fichajeData[0]['idfichajes'] > 0) {
                $fichaje = new Fichajes();

                $rawFecha = $fichajeData[0]['fecha'] ?? '';
                $dateObj  = \DateTime::createFromFormat('d-m-Y', $rawFecha)
                           ?: \DateTime::createFromFormat('d/m/Y', $rawFecha)
                           ?: \DateTime::createFromFormat('Y-m-d', $rawFecha);
                $fichaje->fecha = $dateObj ? $dateObj->format('Y-m-d') : date('Y-m-d');

                $fichaje->idfichajes          = $fichajeData[0]['idfichajes'];
                $fichaje->usuario             = $this->user->nick;
                $fichaje->codagente           = $this->user->codagente;
                $fichaje->salida              = date('H:i');
                $fichaje->entrada             = $fichajeData[0]['entrada'];
                $fichaje->coordenadas_entrada = $fichajeData[0]['coordenadas_entrada'];
                $fichaje->nick                = $this->user->nick;
                $fichaje->tipo                = $fichajeData[0]['tipo'] . ' y Salida';

                $coordenadas = $this->request->cookies->get('coordenadas');
                $fichaje->coordenadas_salida = $coordenadas ?: 'No disponibles';

                if (preg_match('/^\d{2}:\d{2}$/', (string) $fichaje->entrada)) {
                    $fichaje->entrada .= ':00';
                }

                $fechaEntrada = new \DateTime($fichaje->fecha . ' ' . $fichaje->entrada);
                $fechaSalida  = new \DateTime();

                $intervalo = $fechaEntrada->diff($fechaSalida);
                $dias      = (int) $intervalo->format('%a');

                if ($dias > 1) {
                    Tools::log()->warning('La salida no puede registrarse más de un día después de la entrada.');
                    return false;
                }

                $segundos = $fechaSalida->getTimestamp() - $fechaEntrada->getTimestamp();
                $horas    = round($segundos / 3600, 2);

                $fichaje->horas = $horas;

                if (false === $fichaje->save()) {
                    Tools::log()->notice('Error al guardar');
                    return false;
                }

                Tools::log()->notice('Salida el ' . $Fecha . ' a las ' . $Hora);
                return true;
            } else {
                Tools::log()->warning('Primero tienes que registrar una entrada para poder informar de la salida');
                return true;
            }
        }

        return parent::execPreviousAction($action);
    }

    protected function getFichaje(): array
    {
        $data = [];
        $FichajeModel = new Fichajes();

        $hoy  = date('Y-m-d');
        $ayer = date('Y-m-d', strtotime('-1 day'));

        $where = [
            new DataBaseWhere('nick', $this->user->nick),
            new DataBaseWhere('fecha', $hoy, '='),
            new DataBaseWhere('salida', null, 'IS'),
        ];

        $result = $FichajeModel->all($where, ['idfichajes' => 'ASC'], 0, 1);

        if (empty($result) && (int) date('H') < 12) {
            $where = [
                new DataBaseWhere('nick', $this->user->nick),
                new DataBaseWhere('fecha', $ayer, '='),
                new DataBaseWhere('salida', null, 'IS'),
            ];
            $result = $FichajeModel->all($where, ['idfichajes' => 'ASC'], 0, 1);
        }

        foreach ($result as $FichajeAbierto) {
            $data[] = [
                'idfichajes'          => $FichajeAbierto->idfichajes,
                'entrada'             => $FichajeAbierto->entrada,
                'coordenadas_entrada' => $FichajeAbierto->coordenadas_entrada,
                'coordenadas_salida'  => $FichajeAbierto->coordenadas_salida,
                'tipo'                => $FichajeAbierto->tipo,
                'fecha'               => $FichajeAbierto->fecha,
            ];
        }

        return $data;
    }
}
?>
