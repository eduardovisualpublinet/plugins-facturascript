<?php

namespace FacturaScripts\Plugins\RegistroHorario\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;

class EditFichajes extends EditController
{
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'Registro Horario';
        $pageData['title'] = 'Registro Horario';
        $pageData['icon'] = 'fa-solid fa-calendar-alt';
        return $pageData;
    }

    protected function createViews()
    {
        parent::createViews();

        $this->setTabsPosition('start-bottom');
        $this->addHtmlView('Mapa', 'mapa', 'Fichajes', 'Mapa', 'fa-solid fa-code-branch');

        // Ocultar el boton "Nuevo" (en la vista principal y en la pestaña Mapa)
        $this->setSettings($this->getMainViewName(), 'btnNew', false);
        $this->setSettings('Mapa', 'btnNew', false);
    }

    protected function loadData($viewName, $view)
    {
        parent::loadData($viewName, $view);
    }

    public function getModelClassName(): string
    {
        return 'Fichajes';
    }
}
