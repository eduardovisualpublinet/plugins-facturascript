# PlantillaObsTop
Añade la plantilla "PlantillaObsTop" entre las plantillas que usa el plugin PlantillasPDF. Esta plantilla tiene las observaciones de la factura después de los datos del cliente en vez de después de totales.
- https://facturascripts.com/plugins/plantillaobstop

## Requiere
Para funcionar necesita del plugin PlantillasPDF.

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PlantillaObsTop**.