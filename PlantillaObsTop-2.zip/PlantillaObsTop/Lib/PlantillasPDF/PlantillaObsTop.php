<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillaObsTop\Lib\PlantillasPDF;

use FacturaScripts\Core\Model\Base\BusinessDocument;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Template1;

class PlantillaObsTop extends Template1
{
    /**
     * @param BusinessDocument $model
     */
    public function addInvoiceHeader($model): void
    {
        $html = $this->getInvoiceHeaderBilling($model)
            . $this->getInvoiceHeaderShipping($model)
            . $this->getInvoiceHeaderResume($model);
        $this->writeHTML('<table class="table-big table-border"><tr>' . $html . '</tr></table><br/>');

        // Observations
        if (!empty($this->getObservations($model))) {
            $this->writeHTML('<p>' . $this->getObservations($model) . '</p>&nbsp;' . '<br/>');
        }
    }

    /**
     * @param BusinessDocument $model
     */
    public function addInvoiceLines($model): void
    {
        $lines = $model->getLines();
        $this->autoHideLineColumns($lines);

        $html = '<thead><tr>';
        foreach ($this->getInvoiceLineFields() as $field) {
            $html .= '<th align="' . $field['align'] . '">' . $field['title'] . '</th>';
        }
        $html .= '</tr></thead>';

        foreach ($lines as $line) {
            $html .= '<tr>';
            foreach ($this->getInvoiceLineFields() as $field) {
                $html .= '<td align="' . $field['align'] . '" valign="top">' . $this->getInvoiceLineValue($model, $line, $field) . '</td>';
            }
            $html .= '</tr>';
        }

        $this->writeHTML('<div class="table-lines"><table class="table-big table-list">'
            . $html . '</table></div>' . $this->getInvoiceTotals($model));
    }

    /**
     * @param BusinessDocument $model
     *
     * @return string
     */
    protected function getInvoiceTotals($model): string
    {
        if ($this->format->hidetotals) {
            return '';
        }

        $i18n = Tools::lang();
        $trs = '';
        $fields = [
            'netosindto' => $i18n->trans('subtotal'),
            'dtopor1' => $i18n->trans('global-dto'),
            'dtopor2' => $i18n->trans('global-dto-2'),
            'neto' => $i18n->trans('net'),
            'totaliva' => $i18n->trans('taxes'),
            'totalrecargo' => $i18n->trans('re'),
            'totalirpf' => $i18n->trans('irpf'),
            'totalsuplidos' => $i18n->trans('supplied-amount'),
            'total' => $i18n->trans('total')
        ];

        // Hide net and tax total if there is no one
        $lines = empty($lines) ? $model->getLines() : $lines;
        $this->getTotalsModel($model, $lines);
        $taxes = $this->getTaxesRows($model, $lines);
        if (empty($taxes)) {
            unset($fields['neto']);
            unset($fields['totaliva']);
        }

        foreach ($fields as $key => $title) {
            if (empty($model->{$key})) {
                continue;
            }

            switch ($key) {
                case 'dtopor1':
                case 'dtopor2':
                    $trs .= '<tr>'
                        . '<td align="right"><b>' . $title . '</b>:</td>'
                        . '<td align="right">' . Tools::number($model->{$key}) . '%</td>'
                        . '</tr>';
                    break;

                case 'total':
                    $trs .= '<tr>'
                        . '<td class="font-big text-right"><b>' . $title . '</b>:</td>'
                        . '<td class="font-big text-right">' . Tools::money($model->{$key}) . '</td>'
                        . '</tr>';
                    break;

                case 'netosindto':
                    if ($model->netosindto == $model->neto) {
                        break;
                    }
                // no break

                default:
                    $trs .= '<tr>'
                        . '<td align="right"><b>' . $title . '</b>:</td>'
                        . '<td align="right">' . Tools::money($model->{$key}) . '</td>'
                        . '</tr>';
                    break;
            }
        }

        return '<table class="table-big table-border">'
            . '<tr>'
            . '<td>' . $this->getInvoiceTaxes($model, $model->getLines()) . '</td>'
            . '<td align="right" valign="top"><table>' . $trs . '</table></td>'
            . '</tr>'
            . '</table>';
    }
}
