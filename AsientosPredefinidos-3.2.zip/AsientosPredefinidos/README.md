# AsientosPredefinidos
Plugin de FacturaScripts para la generación de asientos desde plantillas de asientos ó asientos predefinidos.
- https://facturascripts.com/plugins/asientospredefinidos

## Issues / Feedback
- https://facturascripts.com/contacto

## Links
- [Cómo hacer un asiento contable](https://facturascripts.com/publicaciones/tu-primer-asiento-463)
- [Curso de FacturaScripts 2023](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
- [Programa de contabilidad gratis para autónomos](https://facturascripts.com/software-contabilidad)
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Programa para hacer presupuestos gratis](https://facturascripts.com/programa-de-presupuestos)