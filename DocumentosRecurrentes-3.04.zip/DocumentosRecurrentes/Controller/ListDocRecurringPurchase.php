<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Controller;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\DocumentosRecurrentes\DocRecurringManager;
use FacturaScripts\Dinamic\Lib\DocumentosRecurrentes\ListDocRecurring;
use FacturaScripts\Core\Lib\ExtendedController\ListView;
use FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes\DocRecurringImport;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringPurchase;

/**
 * Description of ListDocRecurringPurchase
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class ListDocRecurringPurchase extends ListDocRecurring
{
    private const VIEW_RECURRING = 'ListDocRecurringPurchase';
    private const VIEW_EXPIRED = 'ListDocExpiredPurchase';

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'purchases';
        $pageData['title'] = 'recurring';
        $pageData['icon'] = 'fa-solid fa-calendar-plus';
        return $pageData;
    }

    /**
     * @throws Exception
     */
    protected function createViews()
    {
        $this->createViewsRecurring();
        $this->createViewsExpired();
    }

    protected function createViewsExpired(): void
    {
        $this->createViewsDocRecurring(self::VIEW_EXPIRED, 'expired')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false);
    }

    /**
     *
     * @throws Exception
     */
    protected function createViewsRecurring(): void
    {
        $i18n = Tools::lang();
        $this->createViewsDocRecurring(self::VIEW_RECURRING, 'recurring')
            ->addFilterSelectWhere( 'status', [
                ['label' => $i18n->trans('unexpired'), 'where' => [new DataBaseWhere('enddate', date('d-m-Y'), '>'), new DataBaseWhere('enddate', null, 'IS', 'OR')]],
                ['label' => $i18n->trans('expired'), 'where' => [new DataBaseWhere('enddate', date('d-m-Y'), '<=')]],
                ['label' => $i18n->trans('all'), 'where' => []]
            ]);

        $this->addButton(self::VIEW_RECURRING, [
            'action' => 'generate-recurring',
            'color' => 'warning',
            'icon' => 'fa-solid fa-magic',
            'label' => 'generate',
            'type' => 'modal'
        ]);

        $this->addButton(self::VIEW_RECURRING, [
            'action' => 'import-recurring',
            'color' => 'primary',
            'icon' => 'fa-solid fa-file-csv',
            'label' => 'import',
            'type' => 'modal'
        ]);
    }

    /**
     *
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'generate-expired', 'generate-recurring' => $this->generateDocsAction(),
            'import-recurring' => $this->importCSVAction(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Load data for view.
     * if it is the main view it assigns the date of the day to the modal form.
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case self::VIEW_EXPIRED:
                $where = [new DataBaseWhere('enddate', date('d-m-Y'), '<=')];
                $view->loadData('', $where);
                $view->model->untilNextDate = date('d-m-Y');
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    /**
     *
     * @param string $viewName
     * @param string $label
     * @return ListView
     */
    private function createViewsDocRecurring(string $viewName, string $label): ListView
    {
        $view = $this->addView($viewName, 'DocRecurringPurchase', $label, 'fa-solid fa-calendar-plus');
        $this->addCommonSearchFields($viewName);
        $this->addCommonOrderBy($viewName);
        $this->addCommonFilters($viewName);

        $view->addFilterAutocomplete('supplier', 'supplier', 'codproveedor', 'Proveedor');
        return $view;
    }

    /**
     *
     * @return bool
     */
    private function generateDocsAction(): bool
    {
        $where = $this->generateDocsWhere();
        if (empty($where)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        $num = 0;
        $docRecurring = new DocRecurringManager();
        foreach (DocRecurringPurchase::all($where) as $template) {
            if ($docRecurring->generatePurchaseDoc($template->id, ['date' => $template->nextdate])) {
                $num++;
            }
        }

        Tools::log()->notice('generated-documents-quantity', ['%quantity%' => $num]);
        return true;
    }

    /**
     * @return bool
     */
    private function importCSVAction(): bool
    {
        $manager = new DocRecurringImport($this->request, true);
        $manager->import();
        return true;
    }
}
