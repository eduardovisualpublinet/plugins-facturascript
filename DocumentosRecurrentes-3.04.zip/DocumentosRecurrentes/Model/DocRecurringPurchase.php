<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Model;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\DocRecurringPurchaseLine;
use FacturaScripts\Dinamic\Model\Proveedor;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\Base\DocRecurring;

/**
 * Class that manages the data model of the document recurring purchase.
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class DocRecurringPurchase extends DocRecurring
{
    use ModelTrait;

    /**
     * Link with the supplier model
     *
     * @var string
     */
    public $codproveedor;

    /**
     * Returns a new line for the document.
     *
     * @param array $data
     * @param array $exclude
     * @return DocRecurringPurchaseLine
     */
    public function getNewLine(array $data = [], array $exclude = ['id', 'iddoc']): DocRecurringPurchaseLine
    {
        $newLine = new DocRecurringPurchaseLine();
        $newLine->iddoc = $this->id;
        $newLine->loadFromData($data, $exclude);
        return $newLine;
    }

    /**
     * Returns the lines associated with the document.
     *
     * @return DocRecurringPurchaseLine[]
     */
    public function getLines(): array
    {
        return DocRecurringPurchaseLine::all(
            [new DataBaseWhere('iddoc', $this->id)],
            ['id' => 'ASC']
        );
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'docrecurrentes_purchase';
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     * @throws Exception
     */
    public function test(): bool
    {
        if (empty($this->codpago)) {
            $supplier = new Proveedor();
            $this->codpago = $supplier->load($this->codproveedor)
                ? $supplier->codpago
                : Tools::settings('default', 'codpago');
        }
        return parent::test();
    }
}
