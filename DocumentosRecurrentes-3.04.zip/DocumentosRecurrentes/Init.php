<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\EmailNotification;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringPurchase;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringSale;

/**
 * Description of Init
 *
 * @author Jose Antonio Cuello <yopli2000@gmail.com>
 */
class Init extends InitClass
{
    private const NOTIFICATION_ID = 'DocRecurring';

    /**
     * Code to load every time FacturaScripts starts.
     */
    public function init(): void
    {
        $this->loadExtension(new Extension\Controller\EditCliente());
        $this->loadExtension(new Extension\Controller\EditProveedor());
        $this->loadExtension(new Extension\Controller\ListAlbaranCliente());
        $this->loadExtension(new Extension\Controller\ListAlbaranProveedor());
        $this->loadExtension(new Extension\Controller\ListFacturaCliente());
        $this->loadExtension(new Extension\Controller\ListFacturaProveedor());
        $this->loadExtension(new Extension\Controller\ListPedidoCliente());
        $this->loadExtension(new Extension\Controller\ListPedidoProveedor());
    }

    /**
     * When install or update plugin:
     *   - Check and create email notification.
     */
    public function update(): void
    {
        new DocRecurringPurchase();
        new DocRecurringSale();

        $notification = new EmailNotification();
        if (false === $notification->load(self::NOTIFICATION_ID)) {
            $notification->name = self::NOTIFICATION_ID;
            $notification->subject = Tools::lang()->trans('doc-recurring-mail-subject');
            $notification->body = Tools::lang()->trans('doc-recurring-mail-body');
            $notification->enabled = true;
            $notification->save();
        }
    }

    /**
     * Code that is executed when uninstalling a plugin.
     */
    public function uninstall(): void
    {
    }
}
