<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez           <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes;

use Exception;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringPurchase;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringSale;
use ParseCsv\Csv;
use FacturaScripts\Core\Request;

/**
 * Description of DocRecurringGenerator
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class DocRecurringImport
{
    /** @var array */
    private array $docList;

    /** @var DocRecurringPurchase|DocRecurringSale $docRecurring */
    private $docRecurring;

    /** @var bool */
    private bool $isPurchase;

    /** @var Request $request */
    private Request $request;

    /**
     * DocRecurringImport constructor.
     * Determine if the document is a purchase or sale.
     *
     * @param Request $request
     * @param bool $isPurchase
     */
    public function __construct(Request $request, bool $isPurchase)
    {
        $this->request = $request;
        $this->docRecurring = null;
        $this->docList = [];
        $this->isPurchase = $isPurchase;
    }

    /**
     * Import the csv file.
     *
     * @return void
     */
    public function import(): void
    {
        $csv = $this->getFile();
        if (empty($csv)) {
            return;
        }

        $database = new DataBase();
        $database->beginTransaction();
        try {
            foreach ($csv->data as $row) {
                $idDocument = $row['iddocumento'] ?? 0;
                if (empty($idDocument)) {
                    Tools::log()->error('import-file-error');
                    return;
                }

                $idDoc = $this->docList[$idDocument] ?? 0;
                if (false === $this->checkDocumentForImport($idDoc)) {
                    if (false === $this->createDocument($csv->titles, $row)) {
                        Tools::log()->error('import-file-error');
                        return;
                    }
                    $this->docList[$idDocument] = $this->docRecurring->id;
                }

                $newLine = $this->docRecurring->getNewLine();
                foreach ($csv->titles as $field) {
                    $fieldName = $this->getFieldLine($field);
                    $value = $this->getValue($row[$field], $fieldName);
                    if (empty($value)) {
                        continue;
                    }
                    $newLine->{$fieldName} = $value;
                }
                if (false === $newLine->save()) {
                    Tools::log()->error('import-file-error');
                    return;
                }
            }
            $database->commit();
            Tools::log()->notice('import-file-success');
        } catch (Exception $exception) {
            $database->rollback();
            Tools::log()->error('import-file-error');
            Tools::log()->warning($exception->getMessage());
        } finally {
            if ($database->inTransaction()) {
                $database->rollback();
            }
        }
    }

    /**
     * @param int $idDoc
     * @return bool
     */
    private function checkDocumentForImport(int $idDoc): bool
    {
        if (empty($idDoc) || isset($this->docRecurring)) {
            return false;
        }

        if ($idDoc !== $this->docRecurring->id) {
            return $this->docRecurring->load($idDoc);
        }
        return true;
    }

    /**
     * Create a new document.
     *
     * @param array $titles
     * @param array $data
     * @return bool
     */
    private function createDocument(array $titles, array $data): bool
    {
        $this->docRecurring = $this->isPurchase
            ? new DocRecurringPurchase()
            : new DocRecurringSale();

        foreach ($titles as $field) {
            $fieldName = $this->getFieldName($field);
            $value = $this->getValue($data[$field], $fieldName);
            if (empty($value)) {
                continue;
            }
            $this->docRecurring->{$fieldName} = $value;
        }
        return $this->docRecurring->save();
    }

    /**
     * Check if a Csv file is empty or field list is empty
     *
     * @param Csv $csv
     * @return boolean
     */
    private function errorCSVFile(Csv $csv): bool
    {
        $error = false;
        if (empty($csv->data)) {
            Tools::log()->error('import-empty-error');
            $error = true;
        }

        if (empty($csv->titles)) {
            Tools::log()->error('import-fields-error');
            $error = true;
        }

        return $error;
    }

    /**
     * Return the csv file attached.
     *
     * @return Csv|null
     */
    private function getFile(): ?Csv
    {
        $uploadFile = $this->request->files->get('filedata');
        if (empty($uploadFile)) {
            return null;
        }

        $csv = new Csv();
        $csv->use_mb_convert_encoding = true;
        $csv->auto($uploadFile->getPathname());
        if ($this->errorCSVFile($csv)) {
            return null;
        }
        return $csv;
    }

    /**
     * Convert csv title to field name of the document line.
     *
     * @param string $field
     * @return string
     */
    private function getFieldLine(string $field): string
    {
        $field = strtolower($field);
        return match ($field) {
            'cantidad' => 'quantity',
            'descripcion' => 'name',
            'descuento' => 'discount',
            'precio' => 'price',
            'referencia' => 'reference',
            default => '',
        };
    }

    /**
     * Convert csv title to field name of the document.
     *
     * @param string $field
     * @return string
     */
    private function getFieldName(string $field): string
    {
        $field = strtolower($field);
        return match ($field) {
            'codalmacen',
            'codagente',
            'codcliente',
            'coddivisa',
            'codpago',
            'codproveedor',
            'codserie' => $field,

            'documento' => 'name',
            'fechainicio' => 'startdate',
            'fechafin' => 'enddate',
            'fechaprimer' => 'firstdate',
            'generar' => 'generatedoc',
            'numperiodo' => 'termunits',
            'pctprimer' => 'firstpct',
            'periodo' => 'termtype',
            default => '',
        };
    }

    /**
     *
     * @param string $value
     * @param string $fieldName
     * @return string|null
     */
    private function getValue(string $value, string $fieldName): ?string
    {
        if (empty($fieldName) || empty($value)) {
            return null;
        }
        if ($fieldName === 'discount' || $fieldName === 'price' || $fieldName === 'quantity') {
            $value = str_replace(',', '.', $value);
        }
        return in_array($value, ['\N', 'NULL']) ? null : $value;
    }
}
