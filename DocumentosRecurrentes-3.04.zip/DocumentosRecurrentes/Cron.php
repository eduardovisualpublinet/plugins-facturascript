<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez           <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */

namespace FacturaScripts\Plugins\DocumentosRecurrentes;

use Exception;
use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes\DocRecurringManager;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\Base\DocRecurring;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringPurchase;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringSale;

/**
 * Description of Cron
 *
 * @author Jose Antonio Cuello <yopli2000@gmail.com>
 */
class Cron extends CronClass
{
    public const JOB_NAME = 'docrecurring-autogenerate';
    private const JOB_PERIOD = '1 hour';

    /**
     * Main process
     */
    public function run(): void
    {
        $this->job(self::JOB_NAME)
            ->every(self::JOB_PERIOD)
            ->run(function () {
                $this->generatePurchases();
                $this->generateSales();
            });
    }

    /**
     * Generate purchases documents from document recurring.
     *
     * @throws Exception
     */
    private function generatePurchases(): void
    {
        $today = date('d-m-Y');
        $where = [
            new DataBaseWhere('nextdate', $today, '<='),
            new DataBaseWhere('termtype', DocRecurring::TERM_TYPE_MANUAL, '<>')
        ];

        $order = [
            'nextdate' => 'ASC',
            'id' => 'ASC',
        ];
        $docRecurring = new DocRecurringManager();
        foreach (DocRecurringPurchase::all($where, $order, 0, 50) as $template) {
            $docRecurring->generatePurchaseDoc($template->id, ['date' => $template->nextdate]);
        }
    }

    /**
     * Generate sales documents from document recurring.
     *
     * @throws Exception
     */
    private function generateSales(): void
    {
        $today = date('d-m-Y');
        $where = [
            new DataBaseWhere('nextdate', $today, '<='),
            new DataBaseWhere('termtype', DocRecurring::TERM_TYPE_MANUAL, '<>')
        ];

        $order = [
            'nextdate' => 'ASC',
            'id' => 'ASC',
        ];
        $docRecurring = new DocRecurringManager();
        foreach (DocRecurringSale::all($where, $order, 0, 50) as $template) {
            $docRecurring->generateSaleDoc($template->id, ['date' => $template->nextdate]);
        }
    }
}
