# Backup
Plugin de copias de seguridad para FacturaScripts 2022.
- https://facturascripts.com/plugins/backup

## Carpeta
La carpeta debe llamarse igual que el plugin: **Backup**.

## Links
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Programa para hacer presupuestos gratis](https://facturascripts.com/programa-de-presupuestos)
- [Programa de contabilidad gratis para autónomos](https://facturascripts.com/software-contabilidad)
- [Curso de FacturaScripts 2021](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)