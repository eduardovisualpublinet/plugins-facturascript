<?php
namespace FacturaScripts\Plugins\LoginLog;

use FacturaScripts\Core\Tools;


class Init extends \FacturaScripts\Core\Base\InitClass
{
    public function init() {
        /// se ejecutar cada vez que carga FacturaScripts (si este plugin está activado).
    }

    public function update() {
        /// se ejecutar cada vez que se instala o actualiza el plugin
    }
}