<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FacturarDias;

use FacturaScripts\Core\Lib\AjaxForms\PurchasesLineHTML;
use FacturaScripts\Core\Lib\AjaxForms\SalesLineHTML;
use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Template\InitClass;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        // cargamos las extensiones
        $this->loadExtension(new Extension\Model\Base\BusinessDocumentLine());

        // añadimos los mods
        PurchasesLineHTML::addMod(new Mod\PurchasesLineMod());
        SalesLineHTML::addMod(new Mod\SalesLineMod());
        Calculator::addMod(new Mod\CalculatorMod());
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
    }
}
