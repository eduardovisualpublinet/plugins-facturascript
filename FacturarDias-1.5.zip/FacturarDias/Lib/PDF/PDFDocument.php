<?php
/**
 * Copyright (C) 2023 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FacturarDias\Lib\PDF;

use FacturaScripts\Core\Lib\PDF\PDFDocument as ParentPDF;
use FacturaScripts\Core\Tools;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
abstract class PDFDocument extends ParentPDF
{
    protected function getLineHeaders(): array
    {
        $linesHeader = parent::getLineHeaders();
        $this->setCustomLineHeader($linesHeader, 'dias', ['type' => 'number', 'title' => Tools::lang()->trans('days')], 2);
        return $linesHeader;
    }

    function setCustomLineHeader(array &$linesHeader, string $colum, array $dataArray, int $position): void
    {
        if ($position >= count($linesHeader)) {
            $linesHeader[$colum] = $dataArray;
            return;
        }

        if ($position < 0) {
            $position = 0;
        }

        $newArray = [];

        $cont = 0;
        foreach ($linesHeader as $key => $value) {
            if ($cont === $position) {
                $newArray[$colum] = $dataArray;
            }
            $newArray[$key] = $value;
            $cont++;
        }
        $linesHeader = $newArray;
    }
}
