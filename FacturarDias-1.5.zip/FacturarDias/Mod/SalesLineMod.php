<?php
/**
 * Copyright (C) 2023 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FacturarDias\Mod;

use FacturaScripts\Core\Contract\SalesLineModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Translator;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SalesLineMod implements SalesLineModInterface
{
    public function apply(SalesDocument &$model, array &$lines, array $formData): void
    {
    }

    public function applyToLine(array $formData, SalesDocumentLine &$line, string $id): void
    {
        $line->dias = (float)$formData['dias_' . $id];
    }

    public function assets(): void
    {
    }

    public function getFastLine(SalesDocument $model, array $formData): ?SalesDocumentLine
    {
        return null;
    }

    public function map(array $lines, SalesDocument $model): array
    {
        return [];
    }

    public function newModalFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return ['dias'];
    }

    public function newTitles(): array
    {
        return ['dias'];
    }

    public function renderField(string $idlinea, SalesDocumentLine $line, SalesDocument $model, string $field): ?string
    {
        if ($field === 'dias') {
            $i18n = new Translator();
            return $this->diasColumn($i18n, $idlinea, $line, $model);
        }
        return null;
    }

    public function renderTitle(SalesDocument $model, string $field): ?string
    {
        if ($field === 'dias') {
            $i18n = new Translator();
            return $this->diasTitle($i18n);
        }
        return null;
    }

    protected function diasColumn(Translator $i18n, string $idlinea, SalesDocumentLine $line, SalesDocument $model): string
    {
        $attributes = $model->editable ?
            'name="dias_' . $idlinea . '" min="0" onkeyup="return salesFormActionWait(\'recalculate-line\', \'0\', event);"' :
            'disabled=""';
        return '<div class="col-sm col-lg-1 order-3">'
            . '<div class="d-lg-none mt-3 small">' . $i18n->trans('days') . '</div>'
            . '<input type="number" ' . $attributes . ' value="' . $line->dias . '" class="form-control form-control-sm text-lg-end border-0" />'
            . '</div>';
    }

    protected function diasTitle($i18n): string
    {
        return '<div class="col-lg-1 text-end order-3">' . $i18n->trans('days') . '</div>';
    }
}
