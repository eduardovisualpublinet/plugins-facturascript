<?php
/**
 * Copyright (C) 2023 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FacturarDias\Mod;

use FacturaScripts\Core\Contract\PurchasesLineModInterface;
use FacturaScripts\Core\Model\Base\BusinessDocumentLine;
use FacturaScripts\Core\Model\Base\PurchaseDocument;
use FacturaScripts\Core\Translator;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PurchasesLineMod implements PurchasesLineModInterface
{
    public function apply(PurchaseDocument &$model, array &$lines, array $formData): void
    {
    }

    public function applyToLine(array $formData, BusinessDocumentLine &$line, string $id): void
    {
        $line->dias = (float)$formData['dias_' . $id];
    }

    public function assets(): void
    {
    }

    public function getFastLine(PurchaseDocument $model, array $formData): ?BusinessDocumentLine
    {
        return null;
    }

    public function map(array $lines, PurchaseDocument $model): array
    {
        return [];
    }

    public function newFields(): array
    {
        return ['dias'];
    }

    public function newModalFields(): array
    {
        return [];
    }

    public function newTitles(): array
    {
        return ['dias'];
    }

    public function renderField(string $idlinea, BusinessDocumentLine $line, PurchaseDocument $model, string $field): ?string
    {
        if ($field === 'dias') {
            $i18n = new Translator();
            return $this->diasColumn($i18n, $idlinea, $line, $model);
        }
        return null;
    }

    public function renderTitle(PurchaseDocument $model, string $field): ?string
    {
        if ($field === 'dias') {
            $i18n = new Translator();
            return $this->diasTitle($i18n);
        }
        return null;
    }

    protected function diasColumn(Translator $i18n, string $idlinea, BusinessDocumentLine $line, PurchaseDocument $model): string
    {
        $attributes = $model->editable ?
            'name="dias_' . $idlinea . '" min="0" onkeyup="return purchasesFormActionWait(\'recalculate-line\', \'0\', event);"' :
            'disabled=""';
        return '<div class="col-sm col-lg-1 order-3">'
            . '<div class="d-lg-none mt-3 small">' . $i18n->trans('days') . '</div>'
            . '<input type="number" ' . $attributes . ' value="' . $line->dias . '" class="form-control form-control-sm text-lg-end border-0" />'
            . '</div>';
    }

    protected function diasTitle($i18n): string
    {
        return '<div class="col-lg-1 text-end order-3">' . $i18n->trans('days') . '</div>';
    }
}
