<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FacturarDias\Extension\Model\Base;

use Closure;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class BusinessDocumentLine
{
    public function clear(): Closure
    {
        return function () {
            $this->dias = 1;
        };
    }
}
