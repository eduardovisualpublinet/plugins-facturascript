# FacturarDias
Añade la columna días en los documentos de compra y venta, y se usa para calcular el precio de la línea.

- https://facturascripts.com/plugins/facturardias

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Carpeta
El nombre de la carpeta debe ser el mismo que el del plugin. En este caso, **FacturarDias**.