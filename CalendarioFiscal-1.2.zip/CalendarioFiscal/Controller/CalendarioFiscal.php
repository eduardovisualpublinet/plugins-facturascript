<?php
namespace FacturaScripts\Plugins\CalendarioFiscal\Controller;

use FacturaScripts\Core\Base\Controller;

class CalendarioFiscal extends Controller{

    public function getPageData(): array
     {
        $data = Controller::getPageData();
        $data["title"] = "Calendario Fiscal";
        $data["menu"] = "reports";
        $data["icon"] = "fas fa-calendar-alt";
        $data["showonmenu"] = true;
        return $data;
    }
}
