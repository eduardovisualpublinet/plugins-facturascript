<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Controller;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Model\Producto;
use FacturaScripts\Dinamic\Model\ProductPack;
use FacturaScripts\Dinamic\Model\Variante;

/**
 * Controller to list the items in the Product Pack model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditProductPack extends EditController
{
    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'ProductPack';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'pack';
        $pageData['icon'] = 'fa-solid fa-box-open';
        $pageData['menu'] = 'warehouse';
        return $pageData;
    }

    /**
     * Create the view to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->addProductPackLineView();
        $this->addEditView('EditProductPackSettings', 'ProductPack', 'settings', 'fa-solid fa-cogs');
        $this->setTabsPosition('start-bottom');
    }

    protected function execPreviousAction($action)
    {
        if ($action === 'copy-pack') {
            $this->copyPackAction();
            return true;
        }
        return parent::execPreviousAction($action);
    }

    /**
     * Loads the data to display.
     *
     * @param string $viewName
     * @param BaseView $view
     * @throws Exception
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'EditProductPackLine':
                $this->loadDataProductPackLine($view);
                break;

            case 'EditProductPackSettings':
                $view->model = $this->getModel();
                if ($view->model->description === ProductPack::DESC_TYPE_DETAIL) {
                    $view->disableColumn('price-policy', false, 'true');
                }
                break;

            default:
                parent::loadData($viewName, $view);
                if ($viewName === $this->getMainViewName()) {
                    $view->disableColumn('code');  // Force disable PK
                    $view->disableColumn('product-code');  // Force disable Link column with product
                    if ($view->model->exists()) {
                        $this->addButton($viewName, [
                            'action' => 'copy-pack',
                            'color' => 'info',
                            'icon' => 'fa-regular fa-rectangle-list',
                            'label' => 'copy-pack',
                            'type' => 'modal',
                        ]);
                    }

                    // Load product and variant data
                    $this->loadProductData($viewName);
                    $this->loadVariantData($viewName);
                }
                break;
        }
    }

    /**
     * Add product pack detail view
     */
    private function addProductPackLineView(): void
    {
        $this->addEditListView('EditProductPackLine', 'ProductPackLine', 'items', 'fa-solid fa-boxes')
            ->setInLine(true);
    }

    /**
     * Copy product pack detail from another product pack.
     */
    private function copyPackAction(): void
    {
        $data = $this->request->request->all();
        if (empty($data['code'] || empty($data['source_pack']))) {
            Tools::log()->warning('no-data-received-form');
            return;
        }

        if ($data['code'] === $data['source_pack']) {
            Tools::log()->warning('same-code-pack');
            return;
        }

        $pack = new ProductPack();
        if (false === $pack->load($data['source_pack'])) {
            Tools::log()->warning('record-not-found');
            return;
        }

        $count = 0;
        foreach ($pack->getDetail() as $line) {
            $newLine = clone $line;
            $newLine->id = null;
            $newLine->idpack = $data['code'];
            if ($newLine->save()) {
                $count++;
            }
        }

        Tools::log()->info('items-added-correctly', ['%num%' => $count]);
    }

    /**
     * Get an array list for Widget Select of all References of one product
     *
     * @param int $idproduct
     * @return array
     */
    private function getReferencesForProduct(int $idproduct): array
    {
        $where = [ new DataBaseWhere('idproducto', $idproduct) ];
        $order = [ 'referencia' => 'ASC' ];
        $result = [];
        foreach (Variante::all($where, $order) as $row) {
            $description = $row->description(true);
            $title = empty($description)
                ? $row->referencia
                : $row->referencia . ' : ' . $description;

            $result[] = ['value' => $row->referencia, 'title' => $title];
        }
        return $result;
    }

    /**
     * Load data to view with product pack detaill
     *
     * @param BaseView $view
     */
    private function loadDataProductPackLine($view): void
    {
        // Get master data
        $mainViewName = $this->getMainViewName();
        $idpack = $this->getViewModelValue($mainViewName, 'id');

        // Load view data
        $where = [ new DataBaseWhere('idpack', $idpack) ];
        $view->loadData(false, $where, ['sortnum' => 'DESC', 'reference' => 'ASC']);

        // Load description for product pack detail
        foreach ($view->cursor as $line) {
            $line->description = $line->getVariant()->getProducto()->descripcion;
        }
    }

    /**
     * Create product model and load data
     *
     * @param string $viewName
     */
    private function loadProductData(string $viewName): void
    {
        $idproduct = $this->getViewModelValue($viewName, 'idproduct');
        if (empty($idproduct)) {
            return;
        }

        $product = new Producto();
        if ($product->load($idproduct)) {
            // Inject the product values into the main model. Is necessary for the xml view.
            $mainModel = $this->getModel();
            $mainModel->productdescription = $product->descripcion;
        }
    }

    /**
     * Create variant product model and load data
     *
     * @param string $viewName
     */
    private function loadVariantData(string $viewName): void
    {
        $idproduct = $this->getViewModelValue($viewName, 'idproduct');
        if (empty($idproduct)) {
            return;
        }

        // Add variant data to widget select array
        $columnReference = $this->views[$viewName]->columnForName('reference');
        if ($columnReference) {
            $values = $this->getReferencesForProduct($idproduct);
            $columnReference->widget->setValuesFromArray($values);
        }
    }
}
