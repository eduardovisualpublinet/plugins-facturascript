<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\Join\ProductPackLine as ProductPackLineJoin;
use FacturaScripts\Dinamic\Model\Variante;
use FacturaScripts\Plugins\ProductoPack\Model\ProductPackLine as ProductPackLineModel;

/**
 * Product pack for a variant product
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ProductPack extends ModelClass
{
    public const APPLY_TO_ALLWAYS = 0;
    public const APPLY_TO_PURCHASES = 2;
    public const APPLY_TO_SALES = 1;

    public const DESC_TYPE_PACK = 0;
    public const DESC_TYPE_DETAIL = 1;
    public const DESC_TYPE_ALL = 2;

    public const PRICE_POLICY_PRODUCT = 0;
    public const PRICE_POLICY_ITEMS = 1;

    use ModelTrait;

    /**
     * Indicates what type of documents the pack is applied to.
     *
     * @var int
     */
    public $applyto;

    /**
     * Primary key.
     *
     * @var int
     */
    public $id;

    /**
     * Indicates the description calculation for the line order.
     *
     * @var int
     */
    public $description;

    /**
     * Link to the product model.
     *
     * @var int
     */
    public $idproduct;

    /**
     * Indicates whether the pack should be broken down
     * or treated as a box-type product.
     *
     * @var bool
     */
    public $isbox;

    /**
     * Human description for pack
     *
     * @var string
     */
    public $name;

    /**
     * Indicates the minimum porcentage of the products for prepare the pack.
     *
     * @var int
     */
    public $preparemin;

    /**
     * Indicates the price policy to apply.
     *
     * @var int
     */
    public $pricepolicy;

    /**
     * Link to the variant model.
     *
     * @var string
     */
    public $reference;

    /**
     * Returns true if the pack is applied to the specified model.
     *
     * @param string $modelClass
     * @return bool
     */
    public function applyPack(string $modelClass): bool
    {
        if ($this->applyto === self::APPLY_TO_ALLWAYS) {
            return true;
        }

        return match ($modelClass) {
            'LineaPresupuestoCliente',
            'LineaPedidoCliente',
            'LineaAlbaranCliente',
            'LineaFacturaCliente' => $this->applyto === self::APPLY_TO_SALES,

            'LineaPresupuestoProveedor',
            'LineaPedidoProveedor',
            'LineaAlbaranProveedor',
            'LineaFacturaProveedor' => $this->applyto === self::APPLY_TO_PURCHASES,

            default => false,
        };
    }


    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->applyto = self::APPLY_TO_ALLWAYS;
        $this->description = self::DESC_TYPE_PACK;
        $this->isbox = false;
        $this->preparemin = 0;
        $this->pricepolicy = self::PRICE_POLICY_PRODUCT;
    }

    /**
     * Return the product list for a pack.
     *
     * @return ProductPackLineModel[]
     */
    public function getDetail(): array
    {
       $where = [new DataBaseWhere('idpack', $this->id)];
       $detail = new ProductPackLineModel();
       return $detail->all($where, ['sortnum' => 'DESC', 'id' => 'ASC'], 0, 0);
    }

    /**
     * Get the products from a pack.
     *
     * @return ProductPackLineJoin[]
     */
    public function getLines(): array
    {
        $packLine = new ProductPackLineJoin();
        $where = [new DataBaseWhere('plines.idpack', $this->id)];
        return $packLine->all($where, ['plines.sortnum' => 'ASC'], 0, 0);
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new Variante();
        return parent::install();
    }

    /**
     * Returns the name of the column that is the model's primary key.
     *
     * @return string
     */
    public static function primaryColumn(): string
    {
        return 'id';
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'productopack_pack';
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        if (empty($this->applyto)) {
            $this->applyto = self::APPLY_TO_ALLWAYS;
        }

        if (empty($this->description)) {
            $this->description = self::DESC_TYPE_PACK;
        }

        if ((int)$this->description === self::DESC_TYPE_DETAIL) {
            $this->pricepolicy = self::PRICE_POLICY_ITEMS;
        }

        if (empty($this->pricepolicy)) {
            $this->pricepolicy = self::PRICE_POLICY_PRODUCT;
        }

        if (is_null($this->preparemin) || $this->preparemin < 0) {
            $this->preparemin = 0;
        }

        return parent::test();
    }

    /**
     * Stores the model data in the database.
     *
     * @return bool
     */
    public function save(): bool
    {
        if (false === parent::save()) {
            return false;
        }

        if ($this->pricepolicy === self::PRICE_POLICY_ITEMS) {
            $this->recalculatePrices();
        }
        return true;
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        $list = 'EditProducto?code=' . $this->idproduct . '&active=List';
        return parent::url($type, $list);
    }

    /**
     * Recalculate the prices of the variant with the cost of product list.
     *
     * @return void
     */
    private function recalculatePrices(): void
    {
        $sql = 'SELECT t2.precio, t1.quantity, COALESCE(t1.discount, 0.00) as discount'
            . ' FROM productopack_packlines t1'
            . ' INNER JOIN variantes t2 ON t2.referencia = t1.reference'
            . ' WHERE t1.idpack = ' . $this->id;
        $total = 0.00;
        foreach (self::$dataBase->select($sql) as $row) {
            $price = $row['precio'] * (1 - $row['discount'] / 100);
            $total += (float)$price * (float)$row['quantity'];
        }

        $where = [new DataBaseWhere('referencia', $this->reference)];
        $variant = new Variante();
        if ($variant->loadWhere($where)) {
            $variant->precio = $total;
            $variant->save();
        }
    }
}
