<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Model\Join;

use FacturaScripts\Dinamic\Model\Base\JoinModel;

/**
 * List of product pack lines. Model View.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * @property string $reference
 * @property int $idproduct
 * @property float $price
 * @property float $quantity
 */
class ProductPackLine extends JoinModel
{

    /**
     * List of fields or columns to select clausule
     */
    protected function getFields(): array
    {
        return [
            'discount' => 'plines.discount',
            'id' => 'plines.id',
            'idpack' => 'plines.idpack',
            'quantity' => 'plines.quantity',
            'reference' => 'plines.reference',
            'required' => 'plines.required',
            'sortnum' => 'plines.sortnum',
            'idproduct' => 'variantes.idproducto',
            'price' => 'variantes.precio',
            'name' => 'productos.descripcion',
        ];
    }

    /**
     * List of tables related to from clausule
     */
    protected function getSQLFrom(): string
    {
        return 'productopack_packlines plines'
            . ' INNER JOIN variantes ON variantes.referencia = plines.reference'
            . ' INNER JOIN productos ON productos.idproducto = variantes.idproducto';
    }

    /**
     * List of tables required for the execution of the view.
     */
    protected function getTables(): array
    {
        return [];
    }
}
