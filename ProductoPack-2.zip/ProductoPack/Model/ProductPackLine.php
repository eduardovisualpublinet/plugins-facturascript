<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\CodeModel;
use FacturaScripts\Dinamic\Model\Variante;

/**
 * List of product variants includes into a pack
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ProductPackLine extends ModelClass
{
    use ModelTrait;

    /**
     * Discount of the variant child
     *
     * @var double
     */
    public $discount;

    /**
     * Primary key.
     *
     * @var int
     */
    public $id;

    /**
     * Link to the product pack model.
     *
     * @var int
     */
    public $idpack;

    /**
     * Quantity of variant child
     *
     * @var double
     */
    public $quantity;

    /**
     * Link to the variant product model.
     *
     * @var int
     */
    public $reference;

    /**
     * Indicates if the product is mandatory
     *
     * @var boolean
     */
    public $required;

    /**
     * Display or print order
     *
     * @var integer
     */
    public $sortnum;

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->discount = 0.0;
        $this->quantity = 1;
        $this->required = false;
        $this->sortnum = 0;
    }

    /**
     * Remove the model data from the database.
     *
     * @return bool
     */
    public function delete(): bool
    {
        if (false === parent::delete()) {
            return false;
        }

        $this->updateProductPrice();
        return true;
    }

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new ProductPack();
        return parent::install();
    }

    /**
     * Return variant for reference.
     *
     * @return Variante
     */
    public function getVariant(): Variante
    {
        $variant = new Variante();
        $where = [ new DataBaseWhere('referencia', $this->reference) ];
        $variant->loadWhere($where);
        return $variant;
    }

    /**
     * Returns the name of the column that is the model's primary key.
     *
     * @return string
     */
    public static function primaryColumn(): string
    {
        return 'id';
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'productopack_packlines';
    }

    /**
     * Returns true if there are no errors in the values of the model properties.
     * It runs inside the save method.
     *
     * @return bool
     */
    public function test(): bool
    {
        if ($this->reference == $this->parentReference()) {
            Tools::log()->warning('error-same-reference-parent');
            return false;
        }

        if (empty($this->id) && $this->countReference() > 0) {
            Tools::log()->warning('error-reference-exists');
            return false;
        }

        if ($this->quantity == 0) {
            Tools::log()->warning('error-quantity-non-zero');
            return false;
        }

        return parent::test();
    }

    /**
     * Stores the model data in the database.
     *
     * @return bool
     */
    public function save(): bool
    {
        if (false === parent::save()) {
            return false;
        }

        $this->updateProductPrice();
        return true;
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     *
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        $list = 'EditProductPack?code=' . $this->idpack . '&active=List';
        return parent::url($type, $list);
    }

    /**
     * Return count number for reference into pack
     *
     * @return int
     */
    private function countReference(): int
    {
        $where = [
            new DataBaseWhere('idpack', $this->idpack),
            new DataBaseWhere('reference', $this->reference)
        ];
        $data = CodeModel::all(self::tableName(), 'reference', 'reference', false, $where);
        return count($data);
    }

    /**
     * Return product parent reference
     *
     * @return string
     */
    private function parentReference(): string
    {
        $model = new CodeModel();
        return $model->getDescription(
            'productopack_pack',
            'id',
            $this->idpack,
            'reference'
        );
    }

    /**
     * Update pack price
     *
     * @return void
     */
    private function updateProductPrice(): void
    {
        $pack = new ProductPack();
        $pack->load($this->idpack);
        $pack->save();
    }
}
