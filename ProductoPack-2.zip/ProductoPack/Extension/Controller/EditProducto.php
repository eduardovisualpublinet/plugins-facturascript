<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Extension\Controller;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;

/**
 * Class to list the items in the Producto edit view
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * @method addListView(string $viewName, string $model, string $title, string $icon)
 * @method getModel(): Producto
 */
class EditProducto
{
    /**
     * Load views
     */
    public function createViews(): Closure
    {
        return function() {
            $this->addListView('ListProductPack', 'Join\ProductPack', 'packs', 'fa-solid fa-box-open');
        };
    }

    /**
     * Load view data procedure
     */
    public function loadData(): Closure
    {
        return function($viewName, $view) {
            if ($viewName == 'ListProductPack') {
                $this->loadDataProductPack($view, $this->getModel()->idproducto);
            }
        };
    }

    /**
     * Load Product List of Variants Pack
     */
    public function loadDataProductPack(): Closure
    {
        return function($view, $idproduct) {
            $where = [new DataBaseWhere('idproduct', $idproduct)];
            $order = ['productopack_pack.reference' => 'ASC'];
            $view->loadData('', $where, $order);
        };
    }
}
