<?php
/**
 * This file is part of ProductoPack plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * ProductoPack   Copyright (C) 2019-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\ProductoPack\Extension\Model\Base;

use Closure;
use FacturaScripts\Core\Base\Database\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\ProductoPack\Model\Join\ProductPackLine;
use FacturaScripts\Plugins\ProductoPack\Model\ProductPack;
use FacturaScripts\Plugins\ProductoPack\Model\ProductPackPreparation;

/**
 * Description of BusinessDocumentLine
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * @property float $cantidad
 * @method modelClassName(): string
 * @method primaryColumnValue(): mixed
 * @method id(): int
 */
class BusinessDocumentLine
{

    /**
     * Delete the preparation info of the document line.
     */
    public function delete(): Closure
    {
        return function (): bool {
            $where = [
                new DataBaseWhere('iddocline', $this->id()),
                new DataBaseWhere('modelname', $this->modelClassName()),
            ];
            $preparationInfo = new ProductPackPreparation();
            if ($preparationInfo->loadWhere($where)) {
                $preparationInfo->delete();
            }
            return true;
        };
    }

    /**
     * Delete the product line if it is a pack, and the pack is not a box.
     *  If it is a pack, the replacement process has already been carried out
     *  in the saveBeforeInsert.
     *
     * @return Closure
     */
    public function saveInsert(): Closure
    {
        return function () {
            if (empty($this->referencia)) {
                return true;
            }

            $pack = $this->getPack($this->referencia);
            if (empty($pack->id) || false === $pack->applyPack($this->modelClassName())) {
                return true;
            }

            if (false === $pack->isbox && (int)$pack->description === ProductPack::DESC_TYPE_DETAIL) {
                return $this->delete();
            }
            return true;
        };
    }


    /**
     * If it is a pack, carry out the process of replacing the pack product with its components.
     * If it is a box pack, the detail is included in the description of the pack product.
     * If it is not a box pack, the detail is added as new lines to the document.
     *
     * @return Closure
     */
    public function saveInsertBefore(): Closure
    {
        return function () {
            if (empty($this->referencia)) {
                return true;
            }

            $pack = $this->getPack($this->referencia);
            if (empty($pack->id) || false === $pack->applyPack($this->modelClassName())) {
                return true;
            }

            if ($pack->isbox) {
                $this->processBoxPack($pack);
                return true;
            }

            if ($this->processPack($pack)) {
                return true;
            }

            return false;
        };
    }

    protected function addPrepareInfo(): Closure
    {
        return function (ProductPack $pack, ProductPackLine $packLine, string $prepareInfo, $docLine): bool {
            $preparationInfo = new ProductPackPreparation();
            $preparationInfo->modelname = $docLine->modelClassName();
            $preparationInfo->iddocline = $docLine->idlinea;
            $preparationInfo->reference = $docLine->referencia;
            $preparationInfo->idpack = $pack->id;
            $preparationInfo->idpackline = $packLine->id;
            $preparationInfo->required = $packLine->required;
            $preparationInfo->prepareinfo = $prepareInfo;
            $preparationInfo->preparemin = $pack->preparemin;
            return $preparationInfo->save();
        };
    }

    protected function getPack(): Closure
    {
        return function (string $reference): ProductPack {
            $pack = new ProductPack();
            $where = [new DataBaseWhere('reference', $reference)];
            $pack->loadWhere($where);
            return $pack;
        };
    }

    protected function processBoxPack(): Closure
    {
        return function (ProductPack $pack): bool {
            if ((int)$pack->description === ProductPack::DESC_TYPE_PACK) {
                $this->descripcion = $pack->name;
                return true;
            }

            $this->descripcion = '';
            if ((int)$pack->description === ProductPack::DESC_TYPE_ALL) {
                $this->descripcion = $pack->name . $this->getBoxPackHeader();
            }
            foreach ($pack->getLines() as $line) {
                $this->descripcion .= $this->getBoxPackLine($line);
            }
            return true;
        };
    }

    protected function getBoxPackHeader(): Closure
    {
        return function (): string {
            return "\n----------------------------------------------------\n"
                . str_pad(Tools::lang()->trans('reference'), 15) . ' '
                . str_pad(Tools::lang()->trans('quantity-abb'), 6) . ' '
                . substr(Tools::lang()->trans("description"), 0, 20)
                . "\n----------------------------------------------------";
        };
    }

    protected function getBoxPackLine(): Closure
    {
        return function (ProductPackLine $line): string {
            return "\n"
                . str_pad($line->reference, 10) . " . . . "
                . str_pad($line->quantity, 4) . " . . . "
                . mb_substr($line->name, 0, 30);
        };
    }

    protected function processPack(): Closure
    {
        return function (ProductPack $pack): bool {
            switch ((int)$pack->description) {
                case ProductPack::DESC_TYPE_ALL:
                    $this->descripcion = $pack->name;
                    $this->referencia = '';
                    $this->idproducto = null;
                    break;

                case ProductPack::DESC_TYPE_DETAIL:
                    $this->descripcion = $pack->name;
                    break;
            }

            $savePrepareInfo = (bool)Tools::settings('default', 'preparation-info', false) ?? false;
            $prepareInfo = $savePrepareInfo ? uniqid() : null;
            $doc = $this->getDocument();
            foreach ($pack->getLines() as $line) {
                $newLine = $doc->getNewProductLine($line->reference);
                $newLine->cantidad = $this->cantidad * $line->quantity;
                $newLine->orden = $this->orden - 1;
                if ((int)$pack->description !== ProductPack::DESC_TYPE_DETAIL) {
                    $newLine->pvpunitario = 0;
                } elseif (false === empty($line->discount)) {
                    $newLine->dtopor = $line->discount;
                }

                if (false === $newLine->save()) {
                    Tools::log()->warning('error-save-line-product', ['%reference%' => $line->reference]);
                    return false;
                }

                if ($savePrepareInfo && false === $this->addPrepareInfo($pack, $line, $prepareInfo, $newLine)) {
                    Tools::log()->warning('error-save-prepare-info', ['%reference%' => $line->reference]);
                    return false;
                }
            }

            // set quantity to 0 to avoid stock problems with product pack
            if ((int)$pack->description === ProductPack::DESC_TYPE_DETAIL) {
                $this->cantidad = 0;
            }
            return true;
        };
    }
}
