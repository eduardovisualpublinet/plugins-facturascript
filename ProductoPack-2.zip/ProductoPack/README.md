# FacturaScripts
Software de código abierto de facturación y contabilidad para pequeñas y medianas empresas.
Software ERP de código abierto. Construido sobre PHP, utilizando de componentes Symfony y Bootstrap 4.
Fácil y potente.


# ProductoPack
Plugin para FacturaScripts que facilita la adición de múltiples productos a los documentos
de compra y venta según un producto que contiene pack de productos y sus cantidades.

<strong>ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU LIBRE DISTRIBUCIÓN.</strong>


## Más información
<ul>
    <li>General info: https://www.facturascripts.com</li>
    <li>Plugin info:  https://www.facturascripts.com/plugins/productopack</li>
</ul>


## Documentación / Issues / Feedback
https://www.facturascripts.com
