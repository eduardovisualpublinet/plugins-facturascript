<?php
/**
 * Configuración del plugin AyudaVisualFactura
 */

return [
    // Email del usuario autorizado para gestionar plugins y actualizaciones
    'admin_email' => 'produccion@visualpublinet.com',
];
