<?php
namespace FacturaScripts\Plugins\AyudaVisualFactura\Controller;

use FacturaScripts\Core\Lib\ExtendedController\PanelController;

class StartHere extends PanelController
{
    
    public function getPageData(): array
    {
        $page = parent::getPageData();
        
        $page['title'] = 'Empieza aquí';
        $page['menu'] = 'admin';
        $page['icon'] = 'fa-solid fa-play';

        $page['showonmenu'] = true;
        return $page;
    }

    protected function createViews() {
        
        $this->addHtmlView('StartHere', 'StartHere', 'Settings', 'Empieza aquí','fa-solid fa-play');

    }

    protected function loadData($viewName, $view) {
   
            $code = $this->request->get('code');
            $view->loadData($code);
        
    }
}