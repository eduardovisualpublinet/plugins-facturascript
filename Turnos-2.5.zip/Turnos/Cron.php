<?php

namespace FacturaScripts\Plugins\Turnos;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\Turnos\Model\Turno;

class Cron extends CronClass
{
    public function run(): void
    {
        $this->job("Turnos")
            ->every("1 day")
            ->withoutOverlapping()
            ->run(function () {
                $this->nextShifts();
                $this->cancelOldShifts();
            });
    }

    public function nextShifts()
    {
        $turnos = new Turno();
        $where = [
            new DataBaseWhere('status', 'pendiente'),
        ];

        foreach ($turnos->all($where, [], 0, 0) as $turno) {
            $timestampFechaTurno = strtotime($turno->fechaturno);
            $timestampActual = time();
            $diasRestantes = ($timestampFechaTurno - $timestampActual) / 86400;

            if ($diasRestantes > 0 && $diasRestantes <= 3) {
                $turno->status = 'proximo';
                $turno->lastupdate = Tools::dateTime();
                $turno->save();
            }
        }
    }

    public function cancelOldShifts()
    {
        $turnos = new Turno();
        $where = [
            new DataBaseWhere('status', 'pendiente,proximo', 'IN'),
        ];

        foreach ($turnos->all($where, [], 0, 0) as $turno) {
            $timestampFechaTurno = strtotime($turno->fechaturno);
            $timestampActual = time();
            $diasPasados = ($timestampActual - $timestampFechaTurno) / 86400;

            if ($diasPasados > 7) {
                $turno->status = 'cancelado';
                $turno->cancellation_reason = 'Cancelación automática: El turno no fue marcado como completado ni cancelado 7 días después de la fecha programada.';
                $turno->lastupdate = Tools::dateTime();
                $turno->save();
            }
        }
    }
}
