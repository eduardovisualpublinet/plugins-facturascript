<?php

namespace FacturaScripts\Plugins\Turnos;

use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Plugins\Turnos\Model\Turno;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Model\Role;
use FacturaScripts\Core\Model\RoleAccess;

class Init extends InitClass
{
    private const ROLE_NAME = 'Turnos';

    public function init(): void {}

    public function uninstall(): void {}

    public function update(): void
    {
        new Turno();
        $this->createRoleForPlugin();
    }

    private function createRoleForPlugin(): void
    {
        $dataBase = new DataBase();
        $dataBase->beginTransaction();

        $role = new Role();
        if (false === $role->load(self::ROLE_NAME)) {
            $role->codrole = $role->descripcion = self::ROLE_NAME;
            if (false === $role->save()) {
                $dataBase->rollback();
                return;
            }
        }

        $controllerNames = [
            'ListTurno',
            'EditTurno',
        ];

        foreach ($controllerNames as $controllerName) {
            $roleAccess = new RoleAccess();
            $where = [
                new DataBaseWhere('codrole', self::ROLE_NAME),
                new DataBaseWhere('pagename', $controllerName)
            ];
            if ($roleAccess->loadWhere($where)) {
                continue;
            }

            $roleAccess->allowdelete = true;
            $roleAccess->allowupdate = true;
            $roleAccess->codrole = self::ROLE_NAME;
            $roleAccess->pagename = $controllerName;
            $roleAccess->onlyownerdata = false;
            if (false === $roleAccess->save()) {
                $dataBase->rollback();
                return;
            }
        }

        $dataBase->commit();
    }
}
