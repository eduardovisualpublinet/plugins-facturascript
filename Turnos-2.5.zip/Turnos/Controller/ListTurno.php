<?php

namespace FacturaScripts\Plugins\Turnos\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Plugins\Turnos\Model\Turno;

/**
 * Summary of ListTurno
 * @author Facundo Gonzalez <coregf@gmail.com>
 * @copyright (c) 2024
 */
class ListTurno extends ListController
{
    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["title"] = "Turnos";
        $data["menu"] = "Agenda";
        $data["icon"] = "fa-solid fa-clock";
        return $data;
    }

    protected function createViews()
    {
        $this->createViewsTurno();
        $this->addButton("ListTurno", [
            'action' => 'Completar',
            'icon' => 'fa-solid fa-check',
            'label' => 'Mark as completed',
            'color' => 'light',

        ]);
    }

    protected function createViewsTurno(string $viewName = "ListTurno")
    {
        $this->addView($viewName, "Turno", "Turnos", "fa-solid fa-clock")
            ->addOrderBy(["fechaturno"], "Shift Date", 2)
            ->addOrderBy(["id"], "code")
            ->addFilterPeriod('fechaturno', 'period', 'fechaturno', true)
            ->addFilterAutocomplete('codcliente', 'customer', 'codcliente', 'clientes', 'codcliente', 'nombre')
            ->addSearchFields(["id", "name", "observation", "cancellation_reason"]);
        $i18n = Tools::lang();
        $this->addFilterSelectWhere($viewName, 'status', [
            ['label' => $i18n->trans('Pending'), 'where' => [new DataBaseWhere('status', 'pendiente,proximo', 'IN')]],
            ['label' => $i18n->trans('completed'), 'where' => [new DataBaseWhere('status', 'completado')]],
            ['label' => $i18n->trans('cancelled'), 'where' => [new DataBaseWhere('status', 'cancelado')]],
            ['label' => $i18n->trans('all'), 'where' => []],
        ]);
    }

    protected function execPreviousAction($action)
    {
        $data = $this->request->request->all();
        switch ($action) {
            case 'Completar':
                return $this->Completar($data);

            default:
                return parent::execPreviousAction($action);
        }
    }

    public function Completar(array $data)
    {
        if (!empty($data['codes'])) {
            $fallosPorEstado = 0;
            foreach ($data['codes'] as $code) {
                $t = new Turno();
                $t->load($code);
                if ($t->status != 'cancelado' and $t->status != 'completado') {
                    $t->status = 'completado';
                    $t->completed_date = Tools::dateTime();
                    $t->save();
                } else {
                    $fallosPorEstado++;
                }
            }
            Tools::log()->notice("Closed correctly");
            if ($fallosPorEstado > 0) {
                Tools::log()->warning('Some of the selected appointments are already canceled or completed');
            }
        } else {
            Tools::log()->warning('no-selected-item');
        }
        return true;
    }
}
