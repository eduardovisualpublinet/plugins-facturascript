<?php

namespace FacturaScripts\Plugins\Turnos\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;

use FacturaScripts\Plugins\Turnos\Model\Turno;

/**
 * Summary of EditTurno
 * @author Facundo González <coregf@gmail.com>
 * @copyright (c) 2024
 */
class EditTurno extends EditController
{
    public function getModelClassName(): string
    {
        return "Turno";
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["title"] = "Turno";
        $data["icon"] = "fa-solid fa-clock";
        return $data;
    }


    protected function createViews()
    {
        parent::createViews();
        $code = $this->request->query->get('code', '');
        $turno = new Turno();
        $turno->load($code);


        if ($turno->exists() and ($turno->status == 'cancelado' or $turno->status == 'completado')) {


            $this->disableActionsOnInactive('EditTurno');
        }
    }

    protected function disableActionsOnInactive(string $viewName)
    {
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnSave', false);
        $this->setSettings($viewName, 'btnUndo', false);

        $mapping = [
            'customer',
            'order',
            'Shift Date',
            'description',
            'observations',
            'Cancelled date',
            'Cancellation reason',
        ];
        foreach ($mapping as $columnname) {
            $this->views[$viewName]->disableColumn($columnname, false, 'true');
        }
    }
}
