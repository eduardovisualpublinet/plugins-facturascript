<?php

namespace FacturaScripts\Plugins\Turnos\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Model\Cliente;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;

/**
 * Summary of Turno
 * @author Facundo González <coregf@gmail.com>
 * @copyright (c) 2024
 */

class Turno extends ModelClass
{
    use ModelTrait;

    /** @var string */
    public $codcliente;

    /** @var string */
    public $creationdate;

    /** @var string */
    public $fechaturno;

    /** @var int */
    public $id;

    /** @var string */
    public $lastnick;

    /** @var string */
    public $lastupdate;

    /** @var string */
    public $name;

    /** @var string */
    public $nick;

    /** @var string */
    public $observation;
    public $cancellation_reason;
    public $status;
    public $pedido_id;
    public $completed_date;
    public $cancelated_date;

    public function clear(): void
    {
        parent::clear();
        $this->creationdate = Tools::dateTime();
        $this->fechaturno = Tools::dateTime();
        $this->nick = Session::get('user')->nick ?? null;
        $this->status = 'pendiente';
    }

    public static function primaryColumn(): string
    {
        return "id";
    }

    public static function tableName(): string
    {
        return "turnos";
    }
    public function primaryDescriptionColumn(): string
    {
        return 'name';
    }

    public function test(): bool
    {
        if (empty($this->id())) {
            $this->creationdate = Tools::dateTime();
            $this->lastnick = null;
            $this->lastupdate = null;
            $this->nick = Session::user()->nick;
        } else {
            $this->creationdate ??= Tools::dateTime();
            $this->lastnick = Session::user()->nick;
            $this->lastupdate = Tools::dateTime();
            $this->nick ??= Session::user()->nick;
        }

        $this->codcliente = Tools::noHtml($this->codcliente);
        $this->name = Tools::noHtml($this->name);
        $this->observation = Tools::noHtml($this->observation);
        if ($this->cancelated_date) {
            $this->status = 'cancelado';
        }
        return parent::test();
    }

    public function getCustomerName()
    {
        $cliente = new Cliente();
        $cliente->load($this->codcliente);
        return $cliente->nombre ?? $this->codcliente;
    }

    public function install(): string
    {
        return 'CREATE INDEX turnos_status_idx ON turnos (status);';
    }
}
