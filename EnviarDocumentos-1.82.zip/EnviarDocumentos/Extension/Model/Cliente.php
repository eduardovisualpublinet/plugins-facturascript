<?php
/**
 * Copyright (C) 2022-2024 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\EnviarDocumentos\Extension\Model;

use Closure;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Validator;

/**
 * Description of Cliente
 *
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class Cliente
{
    public function testBefore(): Closure
    {
        return function () {
            $this->checkEmail('emailto');
            $this->checkEmail('emailcc');
            $this->checkEmail('emailbcc');
        };
    }

    public function checkEmail(): Closure
    {
        return function ($field) {
            // comprobamos que el campo no este vacío
            if (empty($this->{$field})) {
                return;
            }

            // comprobamos que los emails sean válidos
            $result = [];
            foreach (explode(',', $this->{$field}) as $email) {
                $value = trim($email);
                if (empty($value)) {
                    continue;
                }

                if (Validator::email($value)) {
                    $result[] = $value;
                    continue;
                }

                Tools::log()->warning('not-valid-email', ['%email%' => Tools::noHtml($value)]);
            }

            // guardamos el resultado
            $this->{$field} = empty($result) ? '' : implode(',', $result);
        };
    }
}
