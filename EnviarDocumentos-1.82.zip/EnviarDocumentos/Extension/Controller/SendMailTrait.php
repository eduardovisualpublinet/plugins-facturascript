<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\EnviarDocumentos\Extension\Controller;

use Closure;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
trait SendMailTrait
{
    protected function createViews(): Closure
    {
        return function () {
            $viewName = array_keys($this->views)[0];
            $this->addButton($viewName, [
                'action' => 'mail-docs',
                'color' => 'light',
                'icon' => 'fa-solid fa-envelope',
                'label' => 'send'
            ]);
        };
    }

    protected function execPreviousAction(): Closure
    {
        return function ($action) {
            if ($action === 'mail-docs') {
                $viewName = array_keys($this->views)[0];
                $params = 'doc=' . $this->views[$viewName]->model->modelClassName();

                $codes = $this->request->request->getArray('codes', false);
                if (false === empty($codes)) {
                    $params .= '&ids=' . implode(',', $codes);
                }

                $this->redirect('SendPendingDocs?' . $params);
            }
        };
    }
}
