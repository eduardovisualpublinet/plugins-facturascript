<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\EnviarDocumentos\Controller;

use FacturaScripts\Core\Controller\SendMail as ParentController;
use FacturaScripts\Dinamic\Model\Cliente;

class SendMail extends ParentController
{
    protected function setEmailAddress(): void
    {
        parent::setEmailAddress();

        $className = self::MODEL_NAMESPACE . $this->request->get('modelClassName', '');
        if (false === class_exists($className)) {
            return;
        }

        $model = new $className();
        if (false === $model->loadFromCode($this->request->get('modelCode', ''))) {
            return;
        }

        $cliente = new Cliente();
        if ($model->hasColumn('codcliente') && $cliente->load($model->codcliente)) {
            // añadimos los nuevos campos
            $addresses = explode(',', $cliente->emailto ?? '');
            foreach ($addresses as $address) {
                $this->newMail->to($address);
            }

            $cc_addresses = explode(',', $cliente->emailcc ?? '');
            foreach ($cc_addresses as $address) {
                $this->newMail->cc($address);
            }

            $bcc_addresses = explode(',', $cliente->emailbcc ?? '');
            foreach ($bcc_addresses as $address) {
                $this->newMail->bcc($address);
            }
        }
    }
}
