<?php

namespace FacturaScripts\Plugins\EstadosCuenta\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;


class EstadosCuenta extends ModelClass
{
    use ModelTrait;   

    public $diferencia;

    public static function primaryColumn(): string
    {
        return 'codcliente';
    }

    public static function tableName(): string
    {
        return 'clientes';
    }
    public function primaryDescriptionColumn(): string
    {
        return 'nombre';
    }
}