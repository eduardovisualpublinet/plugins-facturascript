<?php

namespace FacturaScripts\Plugins\EstadosCuenta;

use FacturaScripts\Core\Template\InitClass;


class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Model\ReciboCliente());
    }

    public function uninstall(): void
    {
        // Limpieza de datos o configuraciones al desinstalar el plugin
    }

    public function update(): void
    {
        // Ajustes al instalar o actualizar el plugin
    }
}