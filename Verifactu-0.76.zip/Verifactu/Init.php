<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Verifactu;

use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Controller\ApiRoot;
use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Kernel;
use FacturaScripts\Core\Lib\AjaxForms\SalesLineHTML;
use FacturaScripts\Core\Plugins;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Base\BusinessDocument;
use FacturaScripts\Plugins\Verifactu\Lib\Verifactu\Certificate;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        // cargamos las extensiones
        $this->loadExtension(new Extension\Controller\DocumentStitcher());
        $this->loadExtension(new Extension\Controller\EditEmpresa());
        $this->loadExtension(new Extension\Controller\EditEstadoDocumento());
        $this->loadExtension(new Extension\Controller\EditFacturaCliente());
        $this->loadExtension(new Extension\Controller\ListFacturaCliente());
        $this->loadExtension(new Extension\Lib\PDF\PDFDocument());
        $this->loadExtension(new Extension\Lib\PlantillasPDF\BaseTemplate());
        $this->loadExtension(new Extension\Model\Ejercicio());
        $this->loadExtension(new Extension\Model\Empresa());
        $this->loadExtension(new Extension\Model\FacturaCliente());
        $this->loadExtension(new Extension\Model\LineaAlbaranCliente());
        $this->loadExtension(new Extension\Model\LineaFacturaCliente());
        $this->loadExtension(new Extension\Model\LineaPedidoCliente());
        $this->loadExtension(new Extension\Model\LineaPresupuestoCliente());

        // cargamos los Mods
        SalesLineHTML::addMod(new Mod\SalesLineMod());

        // evitamos copiar estás columnas de la factura al copiar, duplicar o rectificar la factura
        BusinessDocument::dontCopyField('vf_intents_alta');
        BusinessDocument::dontCopyField('vf_intents_anulacion');
        BusinessDocument::dontCopyField('vf_intents_subsanacion');
        BusinessDocument::dontCopyField('vf_manual_alta');
        BusinessDocument::dontCopyField('vf_manual_anulacion');
        BusinessDocument::dontCopyField('vf_sent');

        // cargamos los endpoints de la API
        Kernel::addRoute('/api/3/verifactu', 'ApiControllerVerifactu', -1);
        ApiRoot::addCustomResource('verifactu');

        // Tickets
        if (Plugins::isEnabled('Tickets')) {
            $this->loadExtension(new Extension\Lib\Tickets\Gift());
            $this->loadExtension(new Extension\Lib\Tickets\Normal());
        }
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
        $this->checkCertificate();
        $this->removeAbsolutePathRecords();
    }

    // TODO: eliminar en la versión 1.0
    private function checkCertificate(): void
    {
        foreach (Empresas::all() as $company) {
            Certificate::checkCertificate($company);
        }
    }

    private function moveDirectoryContents(string $source, string $destination): void
    {
        if (!is_dir($source)) {
            return;
        }

        Tools::folderCheckOrCreate($destination);
        $files = scandir($source);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $sourcePath = $source . '/' . $file;
            $destPath = $destination . '/' . $file;

            if (is_dir($sourcePath)) {
                // mover recursivamente subdirectorios
                $this->moveDirectoryContents($sourcePath, $destPath);
            } else {
                // mover archivos
                rename($sourcePath, $destPath);
            }
        }
    }

    private function removeAbsolutePathRecords(): void
    {
        // eliminamos rutas absolutas de los ficheros almacenados en la base de datos
        $db = new DataBase();
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET file_json = SUBSTRING(file_json, LOCATE('MyFiles', file_json))"
            . " WHERE file_json LIKE '%MyFiles%'");
        $db->exec("UPDATE verifactu_registros_eventos"
            . " SET file_json = SUBSTRING(file_json, LOCATE('MyFiles', file_json))"
            . " WHERE file_json LIKE '%MyFiles%'");
        $db->exec("UPDATE empresas"
            . " SET vf_certificate = SUBSTRING(vf_certificate, LOCATE('MyFiles', vf_certificate))"
            . " WHERE vf_certificate LIKE '%MyFiles%'");

        // además, buscamos cualquier ruta parecida a MyFiles/Verifactu1/ y la corregimos
        // debemos buscarla con expresiones regulares
        $db->exec("UPDATE verifactu_registros_facturas"
            . " SET file_json = REGEXP_REPLACE(file_json, 'MyFiles/Verifactu[0-9]+/', 'MyFiles/Verifactu/')"
            . " WHERE file_json REGEXP 'MyFiles/Verifactu[0-9]+/'");
        $db->exec("UPDATE verifactu_registros_eventos"
            . " SET file_json = REGEXP_REPLACE(file_json, 'MyFiles/Verifactu[0-9]+/', 'MyFiles/Verifactu/')"
            . " WHERE file_json REGEXP 'MyFiles/Verifactu[0-9]+/'");
        $db->exec("UPDATE empresas"
            . " SET vf_certificate = REGEXP_REPLACE(vf_certificate, 'MyFiles/Verifactu[0-9]+/', 'MyFiles/Verifactu/')"
            ." WHERE vf_certificate REGEXP 'MyFiles/Verifactu[0-9]+/'");

        // por otro lado si existe la carpeta MyFiles/Verifactu1/ la renombramos a MyFiles/Verifactu/1/
        foreach (Empresas::all() as $company) {
            $basePath = 'MyFiles/Verifactu';
            $oldPath = $basePath . $company->idempresa;
            if (!is_dir($oldPath)) {
                continue;
            }

            $newPath = $basePath . '/' . $company->idempresa;

            // crear el directorio base si no existe
            Tools::folderCheckOrCreate($basePath);

            // si el nuevo path no existe, simplemente renombramos
            if (!is_dir($newPath)) {
                rename($oldPath, $newPath);
                continue;
            }

            // si ambos existen, movemos recursivamente el contenido
            $this->moveDirectoryContents($oldPath, $newPath);

            // eliminar el directorio antiguo recursivamente
            $this->removeDirectory($oldPath);
        }
    }

    private function removeDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $files = scandir($directory);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $path = $directory . '/' . $file;
            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }

        rmdir($directory);
    }
}
