# CRM
Permite gestionar contactos, listas, notas y oportunidades de negocio. Perfecto para llevar la adquisición de clientes junto al resto de gestiones de la empresa con FacturaScripts.
- https://facturascripts.com/plugins/crm

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **CRM**.
